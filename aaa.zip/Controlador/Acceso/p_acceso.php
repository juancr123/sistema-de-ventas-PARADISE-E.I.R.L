<?php
require '../../Modelo/conexion.php';
session_start();
$usuario=$_GET['usuario'];
$clave=$_GET['clave'];
$xml="";
$result=new query("call SPRValidarUsuario($usuario,'$clave')");
if($result->n>0)
{
foreach($result->v as $fila)
{
$_SESSION["id_personal"]=$fila->id_personal;
$_SESSION["clave"]=$fila->clave;
}
$xml.="1";
}
else
{
$xml.="0";

}
echo $xml;
?>



