<?php
require '../../../Modelo/Venta/CMVenta.php';
$arregloBoleta=$_GET['arregloBoleta'];
$arregloProducto=$_GET['arregloProducto'];
$arregloCantidad=$_GET['arregloCantidad'];
$arregloCosto=$_GET['arregloCosto'];
$arregloBoleta2 = explode(',',$arregloBoleta); 
$arregloProducto2 = explode(',',$arregloProducto);
$arregloCantidad2 = explode(',',$arregloCantidad);
$arregloCosto2 = explode(',',$arregloCosto);
$registroVenta=CMVenta::RegistrarVenta($arregloBoleta2,$arregloProducto2,$arregloCantidad2,$arregloCosto2);
$xml="<?xml version='1.0' encoding='ISO-8859-1'?>";
if($registroVenta)
{
/*header("Location: VentaParadise.php?resultado=OPERACION EXITOSA");*/
$xml.="<resultado><![CDATA[1]]></resultado>";
}
else
{
#header("Location: VentaParadise.php?resultado=OPERACION FALLIDA");*/
$xml.="<resultado><![CDATA[0]]></resultado>"; 
}
header("Content-type: text/xml");
echo $xml;
?>