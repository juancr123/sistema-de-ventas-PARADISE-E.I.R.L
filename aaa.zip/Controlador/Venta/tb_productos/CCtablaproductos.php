<?php
require '../../../Modelo/Mantenimiento/Producto/CMProducto.php';
require '../../../Vista/Venta/tablaproductos.php';
?>