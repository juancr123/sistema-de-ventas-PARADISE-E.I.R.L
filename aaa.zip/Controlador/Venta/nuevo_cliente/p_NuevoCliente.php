<?php
require '../../../Modelo/Mantenimiento/Cliente/CMCliente.php';
$dni=$_GET["dni"];
$ruc=$_GET["ruc"];
$nombres=$_GET["nombres"];
$apellidos=$_GET["apellidos"];
$id_distrito=$_GET["id_distrito"];
$direccion=$_GET["direccion"];
$telefono=$_GET["telefono"];
$celular=$_GET["celular"];
$result=CMCliente::ABMCliente(1,1,$dni,$ruc,$nombres,$apellidos,$id_distrito,$direccion,$telefono,$celular);
if($result!="")
{
echo $result;
}
else
{
echo "0";
}
?>
