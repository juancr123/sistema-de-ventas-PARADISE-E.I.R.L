<?php
require '../../../Modelo/Mantenimiento/Cliente/CMCliente.php';
require '../../../Vista/Venta/tablaclientes.php';
?>

