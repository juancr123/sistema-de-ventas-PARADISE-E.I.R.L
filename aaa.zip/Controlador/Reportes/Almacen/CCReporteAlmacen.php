<?php
require '../../../Modelo/Mantenimiento/Linea/CMLinea.php';
require '../../../Modelo/Mantenimiento/Categoria/CMCategoria.php';
require '../../../Vista/Reportes/Almacen/ReporteAlmacen.php';
?>