<?php
require '../../../Modelo/Almacen/CMCompras.php';
$opcion=$_GET["opcion"];
$dato=$_GET["dato"];
$string2=json_encode(CMCompras::ReportesAlmacen($opcion,$dato));
header("Location: ../../../Vista/Mantenimiento/Exportar/PDF.php?arrays=$string2");
?>
