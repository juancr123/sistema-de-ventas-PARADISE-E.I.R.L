<?php
require '../../../Modelo/Venta/CMVenta.php';
require '../../../fusionChart/funciones_php/graficar.php';
?>
<center>
<?php
$anio=$_REQUEST['anio'];
$mes=$_REQUEST['mes'];
$opcion=$_REQUEST['opcion'];
$opcionReporte=$_REQUEST['opcionReporte'];
if($opcionReporte==1)
{
$result=CMVenta::SPRCNSVentas($anio,$mes,$opcion);
if($result)
{
$i=0;
foreach($result as $fila)
{
$arregloLabel[$i]=$fila['Mes'];
$arregloValues[$i]=$fila['Cantidad'];
$i++;
}
}
}
else if($opcionReporte==2)
{
$result=CMVenta::SPRCNSVentasxLinea($anio,$mes,$opcion);
if($result)
{
$i=0;
foreach($result as $fila)
{
$arregloLabel[$i]=$fila['Linea'];
$arregloValues[$i]=$fila['Cantidad'];
$i++;
}
}
}
else if($opcionReporte==3)
{
$result=CMVenta::SPRCNSVentasxMarca($anio,$mes,$opcion);
if($result)
{
$i=0;
foreach($result as $fila)
{
$arregloLabel[$i]=$fila['Marca'];
$arregloValues[$i]=$fila['Cantidad'];
$i++;
}
}
}
else if($opcionReporte==4)
{
$result=CMVenta::SPRCNSVentasxCategoria($anio,$mes,$opcion);
if($result)
{
$i=0;
foreach($result as $fila)
{
$arregloLabel[$i]=$fila['Categoria'];
$arregloValues[$i]=$fila['Cantidad'];
$i++;
}
}
}
if(isset($arregloLabel)&&isset($arregloValues))
{
graficar::graficoEstadistico("Column3D",$arregloLabel,$arregloValues);
}
else
{
echo "No hay datos";
}
?></center>
