<?php
require '../../../Modelo/Almacen/CMCompras.php';
require '../../../Vista/Almacen/OC/tablaCompras.php';
?>