<?php
require '../../../Modelo/Mantenimiento/Proveedor/CMProveedorProducto.php';
require '../../../Vista/Almacen/OC/tablaproductoxProveedor.php';

?>