<?php
require '../../../Modelo/Almacen/CMCompras.php';
require '../../../Modelo/Almacen/CMDetalleCompras.php';
$opcion=$_GET["opcion"];
$id_compra=$_GET["id_compra"];
$id_proveedor=$_GET["id_proveedor"];
$fecha_compra=$_GET["fecha_compra"];
$estado=$_GET["estado"];
$subtotal=$_GET["subtotal"];
$igv=$_GET["igv"];
$total=$_GET["total"];
$arregloProducto=$_GET['arregloProducto'];
$arregloCantidad=$_GET['arregloCantidad'];
$arregloCosto=$_GET['arregloCosto'];

$arregloProducto2 = explode(',',$arregloProducto);
$arregloCantidad2 = explode(',',$arregloCantidad);
$arregloCosto2 = explode(',',$arregloCosto);

if($opcion==1)/*Insertar*/
{
$result=CMCompras::ABMCompras($opcion,$id_compra,$id_proveedor,$fecha_compra,$estado,$subtotal,$igv,$total);
$id_compra=CMCompras::GET_ID_COMPRA();
/*INSERTANDO DETALLEBOLETA*/
for($i=0;$i<count($arregloProducto2);$i++)
{
$result2=CMDetalleCompras::ABMDetalle_Compras($opcion,1,$id_compra,$arregloProducto2[$i],$arregloCantidad2[$i],$arregloCosto2[$i]);
}
}
else if($opcion==2)/*Modificar*/
{
$result3=CMDetalleCompras::get_ID_DETALLE_COMPRA($id_compra);
$result=CMCompras::ABMCompras(2,$id_compra,$id_proveedor,$fecha_compra,$estado,$subtotal,$igv,$total);
for($i=0;$i<count($result3);$i++)
{
$result=CMDetalleCompras::ABMDetalle_Compras(3,$result3[$i],$id_compra,$arregloProducto2[$i],$arregloCantidad2[$i],$arregloCosto2[$i]);
}
for($j=0;$j<count($arregloProducto2);$j++)
{
$result2=CMDetalleCompras::ABMDetalle_Compras(1,1,$id_compra,$arregloProducto2[$j],$arregloCantidad2[$j],$arregloCosto2[$j]);
}
}
else /*Eliminar*/
{
/*Eliminando detalle*/
$result3=CMDetalleCompras::GET_ID_DETALLE_COMPRA($id_compra);
for($i=0;$i<count($result3);$i++)
{
$result2=CMDetalleCompras::ABMDetalle_Compras($opcion,$result3[$i],$id_compra,$arregloProducto2[$i],$arregloCantidad2[$i],$arregloCosto2[$i]);
}
/*Eliminando compra*/
$result=CMCompras::ABMCompras($opcion,$id_compra,$id_proveedor,$fecha_compra,$estado,$subtotal,$igv,$total);
}
if($result==true&&$result2==true)
{
header("Location: CCOC.php?resultado=Operacion Exitosa&opcionFormulario=$opcion");
}
else
{
header("Location: CCOC.php?resultado=Operacion Fallida&opcionFormulario=$opcion");
}
?>
