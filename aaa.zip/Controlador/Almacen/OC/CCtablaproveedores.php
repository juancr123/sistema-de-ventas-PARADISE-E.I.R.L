<?php
require '../../../Modelo/Mantenimiento/Proveedor/CMProveedor.php';
require '../../../Vista/Almacen/OC/tablaproveedores.php';
?>
