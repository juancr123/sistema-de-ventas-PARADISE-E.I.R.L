<?php
require '../../../Modelo/Mantenimiento/Marca/CMMarca.php';
$opcion=$_POST['opcion'];
$id_marca=$_POST['id_marca'];
$nombre_marca=$_POST['txtMarca'];
$result=CMMarca::ABMMarca($opcion,$id_marca,$nombre_marca);
if($result)
{
header("Location: CCMarca.php?resultado=OPERACION EXITOSA");
}
else
{
header("Location: CCMarca.php?resultado=OPERACION FALLIDA");
}
?>

