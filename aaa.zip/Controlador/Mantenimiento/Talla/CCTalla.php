<?php
require '../../../Modelo/Mantenimiento/Talla/CMTalla.php';
require '../../../Modelo/Mantenimiento/Categoria/CMCategoria.php';
require '../../../Vista/Mantenimiento/Talla/MantenimientoTalla.php';
?>
