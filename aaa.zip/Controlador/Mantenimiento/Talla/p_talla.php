<?php
require '../../../Modelo/Mantenimiento/Talla/CMTalla.php';
$opcion=$_POST['opcion'];
$id_talla=$_POST['id_talla'];
$nombre=$_POST['txtTalla'];
$id_linea=$_POST['cmbCategoria'];
$result=CMTalla::ABMTalla($opcion,$id_talla,$nombre,$id_linea);
if($result)
{
header("Location: CCTalla.php?resultado=OPERACION EXITOSA");
}
else
{
header("Location: CCTalla.php?resultado=OPERACION FALLIDA");
}
?>

