<?php
require '../../../Modelo/util/CMProvinciaDistrito.php'; 
require '../../../Modelo/Mantenimiento/Personal/CMPersonal.php';  
require '../../../Modelo/util/CMTipo.php';  
require '../../../Vista/Mantenimiento/Personal/MantenimientoPersonal.php';
?>
