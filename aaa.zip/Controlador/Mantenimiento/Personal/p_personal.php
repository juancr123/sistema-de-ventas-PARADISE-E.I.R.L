<?php
require '../../../Modelo/Mantenimiento/Personal/CMPersonal.php';
$opcion=$_POST["opcion"];
$id_personal=$_POST["dni"];
$nombres=$_POST["nombres"];
$apellidos=$_POST["apellidos"];
$direccion=$_POST["direccion"];
$id_distrito=$_POST["distrito"];
$sexo=$_POST["sexo"];
$telefono=$_POST["telefono"];
$celular=$_POST["celular"];
$email=$_POST["email"];
$clave=$_POST["clave"];
$id_tipo_personal=$_POST["tipo"];
$registroPersonal=
CMPersonal::ABMPersonal
($opcion,$id_personal,$nombres,$apellidos,$id_distrito,$direccion,$sexo,$email,$telefono,$clave,$celular,$id_tipo_personal);
if($registroPersonal)
{
header("Location: CCPersonal.php?resultado=Operacion Exitosa");
}
else
{
header("Location: CCPersonal.php?resultado=Operacion Fallida");
}
?>
