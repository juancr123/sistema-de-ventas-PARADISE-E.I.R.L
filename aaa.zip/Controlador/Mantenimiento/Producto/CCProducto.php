<?php
require '../../../Modelo/Mantenimiento/Marca/CMMarca.php';
require '../../../Modelo/Mantenimiento/Categoria/CMCategoria.php';
require '../../../Modelo/Mantenimiento/Modelo/CMModelo.php';
require '../../../Modelo/Mantenimiento/Color/CMColor.php';
require '../../../Modelo/Mantenimiento/Talla/CMTalla.php';
require '../../../Modelo/Mantenimiento/Unidad/CMUnidad.php';
require '../../../Modelo/Mantenimiento/Producto/CMProducto.php';
require '../../../Vista/Mantenimiento/Producto/MantenimientoProducto.php';
?>