<?php
require '../../../Modelo/Mantenimiento/Producto/CMProducto.php';
$opcion=$_POST['opcion'];
$id_producto=$_POST['id_producto'];
$id_marca=$_POST['marca'];
$id_color=$_POST['color'];
$id_talla=$_POST['talla'];
$precio=$_POST['precio_venta'];
$stock=$_POST['stock'];
$id_categoria=$_POST['categoria'];
$id_modelo=$_POST['modelo'];
$id_unidad=$_POST['unidad'];
$ruta=$_FILES['imagen']["tmp_name"];
$extension=$_FILES['imagen']['name'];
if($opcion!=1) /*Eliminar o Editar*/
{
$foto_antigua=CMProducto::getImagenProducto($id_producto);
if($ruta!="")
{
if($foto_antigua!="")
{
unlink("../../../images/zapatillas/".$foto_antigua);
}
$nombre_foto=$extension;
}
else
{
if($opcion==3)
{
unlink("../../../images/zapatillas/".$foto_antigua);
}
$nombre_foto=$foto_antigua;
}
}
else
{
if($ruta!="")
{
$nombre_foto=$extension;
}
else
{
$nombre_foto="";
}
}
$result=CMProducto::ABMProducto($opcion,$id_producto ,$id_marca ,$id_color ,$id_talla ,$precio ,$stock ,$id_categoria,$id_modelo,$id_unidad,$nombre_foto);
if($result && $ruta!="")
{
move_uploaded_file($ruta,"../../../images/zapatillas/".$nombre_foto);
}
if($result)
{
header("Location: CCProducto.php?resultado=OPERACION EXITOSA");
}
else
{
header("Location: CCProducto.php?resultado=OPERACION FALLIDA");
}
?>
