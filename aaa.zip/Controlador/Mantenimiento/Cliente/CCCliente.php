<?php
require '../../../Modelo/util/CMProvinciaDistrito.php'; 
require '../../../Modelo/Mantenimiento/Cliente/CMCliente.php'; 
require '../../../Vista/Mantenimiento/Cliente/Cliente.php';
?>