<?php
require '../../../Modelo/Mantenimiento/Cliente/CMCliente.php';
$opcion=$_POST['opcion'];
$id_cliente=$_POST['id_cliente'];
$ruc=$_POST["ruc"];
$result=CMCliente::ABMCliente($opcion,$id_cliente,$_POST["dni"],$ruc,$_POST["nombres"],$_POST["apellidos"],$_POST["distrito"],$_POST["direccion"],$_POST["telefono"],$_POST["celular"]);
if($result!="")
{
header("Location: CCCliente.php?resultado=OPERACION EXITOSA");
}
else
{
header("Location: CCCliente.php?resultado=OPERACION FALLIDA");
}
?>

