<?php
require '../../../Modelo/Mantenimiento/Modelo/CMModelo.php';
$opcion=$_POST['opcion'];
$id_modelo=$_POST['id_modelo'];
$nombre_modelo=$_POST['nombre_modelo'];
$id_categoria=$_POST['cmbCategoria'];

echo $id_modelo."<br>";
echo $nombre_modelo."<br>";
echo $id_categoria."<br>";
$result=CMModelo::ABMModelo($opcion,$id_modelo,$nombre_modelo,$id_categoria);
if($result)
{
header("Location: CCModelo.php?resultado=OPERACION EXITOSA");
}
else
{
header("Location: CCModelo.php?resultado=OPERACION FALLIDA");
}
?>

