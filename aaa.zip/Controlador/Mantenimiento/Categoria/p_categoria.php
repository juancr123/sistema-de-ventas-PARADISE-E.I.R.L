<?php
require '../../../Modelo/Mantenimiento/Categoria/CMCategoria.php';
$opcion=$_POST['opcion'];
$id_categoria=$_POST['id_categoria'];
$nombre=$_POST['txtCategoria'];
$id_linea=$_POST['cmbLinea'];
echo $opcion;
echo $id_categoria;
echo $nombre;
echo $id_linea;
$result=CMCategoria::ABMCategoria($opcion,$id_categoria,$nombre,$id_linea);
if($result)
{
header("Location: CCategoria.php?resultado=OPERACION EXITOSA");
}
else
{
header("Location: CCategoria.php?resultado=OPERACION FALLIDA");
}
?>

