<?php
require '../../../Modelo/Mantenimiento/Linea/CMLinea.php';
$opcion=$_POST['opcion'];
$id_linea=$_POST['id_linea'];
$nombre_linea=$_POST['txtLinea'];
$result=CMLinea::ABMLinea($opcion,$id_linea,$nombre_linea);
if($result)
{
header("Location: CCLinea.php?resultado=OPERACION EXITOSA");
}
else
{
header("Location: CCLinea.php?resultado=OPERACION FALLIDA");
}
?>
