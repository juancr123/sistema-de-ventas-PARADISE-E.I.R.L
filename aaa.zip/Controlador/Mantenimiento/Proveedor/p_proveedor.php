<?php
require '../../../Modelo/Mantenimiento/Proveedor/CMProveedor.php';
$opcion=$_POST["opcion"];
$id_proveedor=$_POST["id_proveedor"];
$nombres=$_POST["nombres"];
$apellidos=$_POST["apellidos"];
$ruc=$_POST["ruc"];
$id_distrito=$_POST["cmbDistrito"];
$razon_social=$_POST["razon_social"];
$direccion=$_POST["direccion"];
$telefono=$_POST["telefono"];
$celular=$_POST["celular"];
$rpm=$_POST["rpm"];
$email=$_POST["email"];
$fax=$_POST["fax"];

$result=CMProveedor::ABMProveedor($opcion,$id_proveedor,$nombres,$apellidos,$ruc,$id_distrito,$razon_social,$direccion,$telefono,$celular,$rpm,$email,$fax,1);

if($result)
{
header("Location: CCProveedor.php?resultado=Operacion Exitosa");
}
else
{
header("Location: CCProveedor.php?resultado=Operacion Fallida");
}
?>