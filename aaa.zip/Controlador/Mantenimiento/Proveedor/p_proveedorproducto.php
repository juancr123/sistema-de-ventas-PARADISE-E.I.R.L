<?php
require '../../../Modelo/Mantenimiento/Proveedor/CMProveedorProducto.php';
$opcion=$_GET["opcion"];
$id_proveedorproducto=$_GET["id_proveedorproducto"];
$id_proveedor=$_GET["id_proveedor"];
$id_producto=$_GET["id_producto"];
$precio_compra=$_GET["precio_compra"];

$result=CMProveedorProducto::ABMProveedorProducto($opcion,$id_proveedorproducto,$id_proveedor,$id_producto,$precio_compra);
if($result)
{
echo "1";
}
else
{
echo "0";
}
?>
