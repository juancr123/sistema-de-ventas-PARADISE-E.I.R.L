<?php
require '../../../Modelo/Mantenimiento/Color/CMColor.php';
$opcion=$_POST['opcion'];
$id_color=$_POST['id_color'];
$nombre=$_POST['txtColor'];
$result=CMColor::ABMColor($opcion,$id_color,$nombre);
if($result)
{
header("Location: CCColor.php?resultado=OPERACION EXITOSA");
}
else
{
header("Location: CCColor.php?resultado=OPERACION FALLIDA");
}
?>

