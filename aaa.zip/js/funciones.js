var $=jQuery.noConflict();
$.fx.speeds._default = 1000;
var urlAcceso="Controlador/Acceso/CCAcceso.php"
var iframeAcceso= $('<iframe src="'+ urlAcceso +'" style="border:none;"/>');
var urlVenta="Controlador/Venta/RegistrarVenta/CCVenta.php";
var iframeVenta=$('<iframe src="'+ urlVenta +'"/>');

var urlMantenimientoProducto="Controlador/Mantenimiento/Producto/CCProducto.php";
var iframeMantenimientoProducto=$('<iframe src="'+ urlMantenimientoProducto +'" />');

var urlMantenimientoCliente="Controlador/Mantenimiento/Cliente/CCCliente.php";
var iframeMantenimientoCliente=$('<iframe src="'+ urlMantenimientoCliente +'" />');

var urlCambiarClave="Vista/Acceso/Cambiar/CambiarClave.php";
var iframeCambiarclave=$('<iframe src="'+ urlCambiarClave +'" />');

var urlMantenimientoProveedor="Controlador/Mantenimiento/Proveedor/CCProveedor.php";
var iframeMantenimientoProveedor=$('<iframe src="'+ urlMantenimientoProveedor +'" />');

var urlMantenimientoMarca="Controlador/Mantenimiento/Marca/CCMarca.php";
var iframeMantenimientoMarca=$('<iframe src="'+ urlMantenimientoMarca +'" />');

var urlMantenimientoModelo="Controlador/Mantenimiento/Modelo/CCModelo.php";
var iframeMantenimientoModelo=$('<iframe src="'+ urlMantenimientoModelo +'" />');

var urlMantenimientoCategoria="Controlador/Mantenimiento/Categoria/CCategoria.php";
var iframeMantenimientoCategoria=$('<iframe src="'+ urlMantenimientoCategoria +'" />');

var urlMantenimientoLinea="Controlador/Mantenimiento/Linea/CCLinea.php";
var iframeMantenimientoLinea=$('<iframe src="'+ urlMantenimientoLinea +'" />');

var urlMantenimientoTalla="Controlador/Mantenimiento/Talla/CCTalla.php";
var iframeMantenimientoTalla=$('<iframe src="'+ urlMantenimientoTalla +'" />');

var urlMantenimientoColor="Controlador/Mantenimiento/Color/CCColor.php";
var iframeMantenimientoColor=$('<iframe src="'+ urlMantenimientoColor +'" />');


var urlReporteAlmacen="Controlador/Reportes/Almacen/CCReporteAlmacen.php";
var iframeReporteAlmacen=$('<iframe src="'+ urlReporteAlmacen +'" />');

var urlMPersonal="Controlador/Mantenimiento/Personal/CCPersonal.php";
var iframeMPersonal=$('<iframe src="'+ urlMPersonal +'" />');


var urlOrdendeCompra="Controlador/Almacen/OC/CCOC.php?opcionFormulario=1";
var iframeOrdendeCompra=$('<iframe src="'+ urlOrdendeCompra +'" />');

var urlEliminarOrdendeCompra="Controlador/Almacen/OC/CCOC.php?opcionFormulario=3";
var iframeEliminarOrdendeCompra=$('<iframe src="'+ urlEliminarOrdendeCompra +'" />');

var urlModificarOrdendeCompra="Controlador/Almacen/OC/CCOC.php?opcionFormulario=2";
var iframeModificarOrdendeCompra=$('<iframe src="'+ urlModificarOrdendeCompra +'" />');

var urlCreditos="Vista/Creditos/Creditos.html";
var iframeCreditos=$('<iframe src="'+ urlCreditos +'" />');

$(document).ready(function(){
	 
iframeAcceso.dialog({
modal:true,
autoOpen:true,
bgiframe : true,
title: "Acceso al Sistema Web",
open:function(event,ui){$(".ui-dialog-titlebar-close").hide();},
width:290,
height:145,
resizable : false,
closeOnEscape: false
}).width(270).height(125);
$('#Boleta_Factura').click(function(e){
iframeVenta.dialog({
                            autoOpen:true,
							modal:true,
							title: "Venta de Productos Paradise E.I.R.L.",
 width : 940,
 height : 640,
 position : 'top',
resizable : false,
							autoResize: true,
							//dragable:true,
                           close:function(event,ui)
            {
                          }
 
       }).width(920).height(630);
									});

$('#ReporteVentas').click(function(e){
var urlReporteVenta="Controlador/Reportes/Venta/CCReporteVenta.php";
var iframeReporteVenta=$('<iframe src="'+ urlReporteVenta +'" />');
iframeReporteVenta.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Reporte de Ventas",
 width : 630,
 height : 690,
 position : 'top',
resizable : false,
							autoResize: true,
                           close:function(event,ui)
            {
                          }
 
       }).width(610).height(670);
									});

$('#ReporteAlmacen').click(function(e){
iframeReporteAlmacen.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Reporte de Almacen",
 width : 600,
 height : 155,
 position : 'top',
resizable : true,
							autoResize: true,
                           close:function(event,ui)
            {
                          }
 
       }).width(580).height(135);
									});

$('#cambiar_clave').click(function(e){
iframeCambiarclave.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Cambiar Clave",
							
 width : 350,
 height : 190,
 position : 'top',
resizable : false,
							autoResize: true,
                           close:function(event,ui)
            {
                          }
 
       }).width(330).height(170);
									});

$('#AgregarOC').click(function(e){
iframeOrdendeCompra.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Agregar Orden de Compra",
 width : 880,
 height : 530,
 position : 'top',
resizable : false,
							autoResize: true,
                           close:function(event,ui)
            {
                          }
 
       }).width(860).height(520);
									});

$("#ModificarOC").click(function(e)
								 {
								
iframeModificarOrdendeCompra.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Modificar Orden de Compra - E.I.R.L.",
 width : 880,
 height : 540,
 position : 'top',
resizable : false,
							autoResize: true,
                           close:function(event,ui)
            {
                          }
 
       }).width(860).height(530);
								 });
$('#EliminarOC').click(function(e){
iframeEliminarOrdendeCompra.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Eliminar Orden de Compra - E.I.R.L.",
 width : 880,
 height : 530,
 position : 'top',
resizable : false,
							autoResize: true,
                           close:function(event,ui)
            {
                          }
 
       }).width(860).height(520);
									});

$('#Marca').click(function(e){
iframeMantenimientoMarca.dialog({
							autoOpen:true,
							modal:true,
							title: "Mantenimiento Marca",
 width : 520,
 height : 570,
 position : 'top',
resizable : false,


						
                           close:function(event,ui)
            {
                          }
 
       }).width(500).height(560);
						   });

$('#Producto').click(function(e){
iframeMantenimientoProducto.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Mantenimiento Producto",
 width : 1040,
 height : 680,
 position : 'top',
resizable : false,


						
                           close:function(event,ui)
            {
                          }
 
       }).width(1020).height(690);
						   });

$('#Cliente').click(function(e){
iframeMantenimientoCliente.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Mantenimiento Cliente",
 width : 850,
 height : 640,
 show:"fade",

 hide :"fade",
 position : 'top',
resizable : false,


						
                           close:function(event,ui)
            {
                          }
 
       }).width(830).height(620);
						   });

$('#Proveedor').click(function(e){
iframeMantenimientoProveedor.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Mantenimiento Proveedor",
 width : 1010,
 height : 600,
 position : 'top',
resizable : false,


						
                           close:function(event,ui)
            {
                          }
 
       }).width(1000).height(600);
						   });

$('#Personal').click(function(e){
iframeMPersonal.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Mantenimiento Personal",
 width : 1000,
 height : 600,
 position : 'top',
  show:"slide",

 hide :"slide",
resizable : false,


						
                           close:function(event,ui)
            {
                          }
 
       }).width(980).height(600);
						   });


$('#Modelo').click(function(e){
iframeMantenimientoModelo.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Mantenimiento Modelo",
 width : 520,
 height : 520,
 position : 'top',
   show:"slide",

 hide :"slide",
resizable : false,


						
                           close:function(event,ui)
            {
                          }
 
       }).width(500).height(500);
						   });

$('#Categoria').click(function(e){
iframeMantenimientoCategoria.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Mantenimiento Categoria",
 width : 520,
 height : 520,
   show:"slide",

 hide :"slide",
 position : 'top',
resizable : false,


						
                           close:function(event,ui)
            {
                          }
 
       }).width(500).height(500);
						   });

$('#Talla').click(function(e){
iframeMantenimientoTalla.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Mantenimiento Talla",
 width : 520,
 height : 520,
 position : 'top',
  show:"fade",

 hide :"fade",
resizable : false,


						
                           close:function(event,ui)
            {
                          }
 
       }).width(500).height(500);
						   });

$('#Linea').click(function(e){
iframeMantenimientoLinea.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Mantenimiento Linea",
 width : 520,
 height : 520,
 position : 'top',
  show:"fade",

 hide :"fade",
resizable : false,


						
                           close:function(event,ui)
            {
                          }
 
       }).width(500).height(500);
						   });

$('#Color').click(function(e){
iframeMantenimientoColor.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Mantenimiento Color",
 width : 520,
 height : 520,
 position : 'top',
  show:"fade",

 hide :"fade",
resizable : false,


						
                           close:function(event,ui)
            {
                          }
 
       }).width(500).height(500);
						   });

$('#Creditos').click(function(e){
iframeCreditos.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Creditos",
 width : 350,
 height : 280,
 position : 'center',
  show:"fade",

 hide :"fade",
resizable : false,


						
                           close:function(event,ui)
            {
                          }
 
       }).width(330).height(260);
						   });

$('#Salir').click(function(e){
						 
						   });

									});	
function cerrarDialogAcceso()
{
window.parent.iframeAcceso.dialog("close");
}
function cerrarDialogMantMarca()
{
window.parent.iframeMantenimientoMarca.dialog("close");
}
                 