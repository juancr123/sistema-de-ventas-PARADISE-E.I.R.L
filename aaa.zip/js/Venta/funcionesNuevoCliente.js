$(document).ready(function()
						   {
							   $('#nuevo_cliente').validationEngine();
							   $('#dni').numeric();
							   $('#ruc').numeric();
							   $('#btnGuardarCliente').click(function(e){
															if(jQuery.fn.ValidarDatos())
															{
										var nombres2=$('#nombres').val();
										var apellidos2=$('#apellidos').val();
										var id_distrito2=$('#cmbDistrito').val();
										var direccion2=$('#direccion').val();
										var dni2=$('#dni').val();
										var ruc2=$('#ruc').val();
										var telefono2=$('#telefono').val();
										var celular2=$('#celular').val();
																	  
																	  /*location.href="p_nuevoCliente.php?dni="+dni2+"&ruc="+ruc2+"&direccion="+direccion2+"&telefono="+telefono2+"&celular="+celular2+"&id_distrito="+id_distrito2+"&nombres="+nombres2+"&apellidos="+apellidos2;*/
										$.get("p_nuevoCliente.php",{
																			dni:dni2,
																			ruc:ruc2,
																			direccion:direccion2,
																			telefono:telefono2,
																			celular:celular2,
																			id_distrito:id_distrito2,
																			nombres:nombres2,
																			apellidos:apellidos2
																			},function(data)
																			{
																			if(data!="0")
																			{
																				window.parent.$('#idb').val(data);
																				window.parent.$('#nombresb').val(nombres2+" "+apellidos2);
																				window.parent.$('#direccionb').val(direccion2);
																				window.parent.$('#dnib').val(dni2);
																				window.parent.$('#telefonob').val(telefono2);
																				window.parent.$('#rucb').val(telefono2);
																				window.parent.iframeRegistrarClientes.dialog("close");
																				$('#nombres').val("");
																				$('#apellidos').val("");
																				$('#direccion').val("");
																				$('#dni').val("");
																				$('#ruc').val("");
																				$('#telefono').val("");
																				$('#celular').val("");
																			window.parent.$('#botonagregar').attr("disabled",false);
																			window.parent.$('#botoneliminar').attr("disabled",false);
																			}
																			else
																			{
																			
																			}
																			});
															}
															else
															{
															window.parent.jAlert('Faltan llenar algunos campos','Atencion!');
															}
																	  
																	  });
							   
							   jQuery.fn.ValidarDatos=function(){
							   if($('#nombres').val()!="" && $('#apellidos').val()!="" && $('#dni').val()!="")
							   {
															   return true;
							   
							   }
							   else
							   {
							   return false;
							   }
							   };
						   });