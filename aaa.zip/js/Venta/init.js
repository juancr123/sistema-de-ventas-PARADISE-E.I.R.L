/*var $=jQuery.noConflict();
$.fx.speeds._default = 1000;*/
var urlRegistrarClientes="../nuevo_cliente/CCNuevoCliente.php"
var iframeRegistrarClientes= $('<iframe src="'+ urlRegistrarClientes +'"/>');
var iframeClientes;
var iframe;
var ruta;
var idcliente="";
var ruc;
var nombres;
var direccion;
var dni;
var telefono;
$(document).ready(function()
    {
		
		 		oTable_Clientes=$('#Clientes').dataTable({
					"bJQueryUI": true,
'bPaginate': true,
'bLengthChange':false,
'iDisplayLength': 5,

"sPaginationType": "full_numbers"
				});
				
				$('#Clientes tbody tr').live('click',function(event){
											 $(oTable_Clientes.fnSettings().aoData).each(function (){
            $(this.nTr).removeClass('row_selected');
				            });
            $(event.target.parentNode).addClass('row_selected');
		var celdas=oTable_Clientes.fnGetData(this);
		
		idcliente=celdas[0];
		ruc=celdas[6];
		nombres=celdas[1]+" "+celdas[2];
		direccion=celdas[4];
		dni=celdas[5];
		telefono=celdas[7];
											 });
				
	$('#aceptarcliente').click(function(e){
	 if(idcliente!=undefined)
	{
window.parent.$('#idb').val(idcliente);
window.parent.$('#rucb').val(ruc);
window.parent.$('#nombresb').val(nombres);
window.parent.$('#telefonob').val(telefono);
window.parent.$('#direccionb').val(direccion);
window.parent.$('#dnib').val(dni);
cerrarcajaBuscarCliente();
window.parent.document.getElementById("botonagregar").disabled=false;
window.parent.document.getElementById("botoneliminar").disabled=false;
	}
	else
	{
	window.parent.jAlert('Selecciona un cliente','Dialogo Alert');
	}
													});
		
			
		  
	/*DataTable Clientes*/
			
	/*DataTable DetalleVenta*/
oTable = $('#scrollTable1').dataTable({
					"bJQueryUI": true,
										'bPaginate': true,
					'bLengthChange':false,
"sScrollY": "39%",
"sPaginationType": "full_numbers"
				});
	
			$("#scrollTable1 tbody").click(function(event) {
					$(oTable.fnSettings().aoData).each(function (){
						$(this.nTr).removeClass('row_selected');
					});
					$(event.target.parentNode).addClass('row_selected');
				});
				
				/* Add a click handler for the delete row */
				$('#botoneliminar').click( function() {
					
				var anSelected = fnGetSelected( oTable );
					if(anSelected[0]!=null)
			    {
					oTable.fnDeleteRow( anSelected[0] );
document.getElementById("subtotal").value=jQuery.fn.CalcularSubtotal(2);
document.getElementById("igv").value=jQuery.fn.CalcularIGV(2);
document.getElementById("total").value=jQuery.fn.CalcularTotal(2);
				}
				else {
				alert("SELECCIONA UNA FILA");
				}
				
				} );



$('#botonagregar').click(function(e){
var url = "../tb_productos/CCtablaproductos.php"
iframe = $('<iframe src="'+ url +'"/>');
if(validarControles()!=false)
{
iframe.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Buscar Producto",
                            width:890,
                            height:440,
							resizable : false,
							autoResize: true,

                           
                         
            close:function(event,ui)
            {
                          }
 
       }).width(870).height(430);
}
else
{
alert("LLENE CORRECTAMENTE LOS CAMPOS ANTERIORES");
}
});
$('#nuevo').click(function(e){

 
        iframeRegistrarClientes.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Registrar Cliente",
                            width:380,
                            height:320,
						resizable : false,
                           position : 'top',
                         autoResize: true,
            close:function(event,ui)
            {
            }
 
       }).width(360).height(300);
		});
$('#buscar').click(function(e)
{
var urlClientes="../tb_cliente/CCtablaclientes.php"
iframeClientes= $('<iframe src="'+ urlClientes +'"/>');
iframeClientes.dialog({
                            autoOpen:true,
							bgiframe : true,
                            modal:true,
							title: "Buscar Cliente",
                            width:785,
                            height:400,
							autoResize: true,
							resizable : false,
						   position : 'top',
						   
             

                         
            close:function(event,ui)
            {
                          }
 
 }).width(750).height(380);	
								
							});
jQuery.fn.ProductoRepetido=function(idproducto)
{
var tabla = document.getElementById("scrollTable1");
var fila="";
for (var i=1; i<tabla.rows.length; i++)
{
	
	if(idproducto==tabla.rows[i].cells[0].innerHTML)
	{
fila=i;
	}
}
return fila;
};
jQuery.fn.LimpiarTabla=function()
{
oTable.fnClearTable();
};
jQuery.fn.CalcularSubtotal=function(opcion)
{
var oTableAlmacen2;
if(opcion==1)
{
oTableAlmacen2=window.parent.$("#scrollTable1").dataTable();
}
else
{
oTableAlmacen2=$("#scrollTable1").dataTable();
}
var subtotal=0.00;
$.each( oTableAlmacen2.fnGetData(), function(i, row){
											 
								subtotal+=parseFloat(row[4]);	   
									   
									   });


return subtotal;
};

jQuery.fn.CalcularIGV=function(opcion)
{
var igv=0.18*jQuery.fn.CalcularSubtotal(opcion);
return igv;
}
jQuery.fn.CalcularTotal=function(opcion)
{
	var subtotal;
	var igv;
if(opcion==1)
{
subtotal=parseFloat(window.parent.document.getElementById("subtotal").value);
igv=parseFloat(window.parent.document.getElementById("igv").value);
}
else
{
subtotal=parseFloat(document.getElementById("subtotal").value);
igv=parseFloat(document.getElementById("igv").value);
}
};
function fnGetSelected( oTableLocal )
			{
				var aReturn = new Array();
				var aTrs = oTableLocal.fnGetNodes();
				for ( var i=0 ; i<aTrs.length ; i++ )
				{
					if ( $(aTrs[i]).hasClass('row_selected') )
					{
						aReturn.push( aTrs[i] );
					}
				}
				return aReturn;
			}
			
	});
function cerrarcajaRegistrarCliente()
{
window.parent.iframeRegistrarClientes.dialog("close");
}
function cerrarcajaBuscarCliente()
{
window.parent.iframeClientes.dialog("close");
}
