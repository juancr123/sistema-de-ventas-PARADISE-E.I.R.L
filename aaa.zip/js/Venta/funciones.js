var idproducto;
var categoria;
var modelo;
var nombre;
var marca;
var color;
var talla;
var precio;

var stock;

var aProducto;
var aCantidad;
var aCosto;

var i=1;

function getXMLHttpRequest(){
	var xmlhttp=false;
	try {
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	} catch (e) {
		try {
		   xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		} catch (E) {
			xmlhttp = false;
  		}
	}

	if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
		xmlhttp = new XMLHttpRequest();
	}
	return xmlhttp;
}

function calcularSubTotal()
{
var subtotal=0.00;
var tabla = window.parent.document.getElementById("scrollTable1");

for (var i=2; i<tabla.rows.length; i++)
{
subtotal+=parseFloat(tabla.rows[i].cells[4].innerHTML);
}

return subtotal;
}

function calcularIGV()
{
var igv=0.18*calcularSubTotal();
return igv;
}

function calcularTotal()
{
var subtotal=parseFloat(window.parent.document.getElementById("subtotal").value);
var igv=parseFloat(window.parent.document.getElementById("igv").value);
var total=subtotal+igv;
return total;
}

function llenarBoleta()
{
var aBoleta=new Array();
aBoleta[0]=document.getElementById("numboleta").value;
aBoleta[1]=document.getElementById("idb").value;
aBoleta[2]=document.getElementById("id_personal").value;
aBoleta[3]="1";
aBoleta[4]=document.getElementById("fVentab").value;
aBoleta[5]=document.getElementById("fEntregab").value;
aBoleta[6]=document.getElementById("subtotal").value;
aBoleta[7]=document.getElementById("igv").value;
aBoleta[8]=document.getElementById("total").value;
aBoleta[9]="1";
return aBoleta;
}

function llenarDetalleBoleta()
{
	aProducto= new Array();
	aCantidad= new Array();
	aCosto= new Array();
$.each( oTable.fnGetData(), function(i, row){				
aProducto[i]=parseInt(row[0]);
aCantidad[i]=parseInt(row[3]);
aCosto[i]=parseFloat(row[4]);
});
}
function MandarRegistroBoleta()
{
	if(document.getElementById("nuevoyguardar").value=="GUARDAR")
	{
		if(validacionGeneral())
		{
llenarDetalleBoleta();
ajax=getXMLHttpRequest();
	ajax.open("GET","p_registrarventa.php?"+"arregloBoleta="+llenarBoleta()+"&arregloProducto="+aProducto+"&arregloCantidad="+aCantidad+"&arregloCosto="+aCosto);
	ajax.setRequestHeader("Content-Type", "application/x-www-form-urlencoded"); 
	ajax.onreadystatechange=function()
	{
	if(ajax.readyState==1)
		{
			
		}
		else{
			if(ajax.readyState==4)
			{
			var respuesta=ajax.responseXML; 
			ValidarRegistroVenta(respuesta.getElementsByTagName("resultado")[0].childNodes[0].data);
			}
			}
	}
	ajax.send(null);
	resetComponentes();
EstadoComponentes(true);
		}
		else
		{
		window.parent.jAlert('Falta rellenar algunos campos!', 'Dialogo Alert');
		}
}
else
{
document.getElementById("nuevoyguardar").value="GUARDAR";
EstadoComponentes(false);
}
}
function LoadVentaParadise()
{
EstadoComponentes(true)
}
function EstadoComponentes(estado)
{
document.getElementById("numboleta").disabled=estado;
document.getElementById("rucb").disabled=estado;
document.getElementById("idb").disabled=estado;
document.getElementById("nombresb").disabled=estado;
document.getElementById("direccionb").disabled=estado;
document.getElementById("telefonob").disabled=estado;
document.getElementById("dnib").disabled=estado;
document.getElementById("fVentab").disabled=estado;
document.getElementById("fEntregab").disabled=estado;
document.getElementById("buscar").disabled=estado;
document.getElementById("nuevo").disabled=estado;
}
function resetComponentes()
{
document.getElementById("numboleta").value="";
document.getElementById("rucb").value="";
document.getElementById("idb").value="";
document.getElementById("nombresb").value="";
document.getElementById("direccionb").value="";
document.getElementById("telefonob").value="";
document.getElementById("dnib").value="";
document.getElementById("fVentab").value="";
document.getElementById("fEntregab").value="";
document.getElementById("subtotal").value="";
document.getElementById("igv").value="";
document.getElementById("total").value="";
document.getElementById("nuevoyguardar").value="NUEVO";
jQuery.fn.LimpiarTabla();
}
function ValidarRegistroVenta(respuesta2)
{
if(respuesta2=="1")
{
window.parent.jAlert('Operacion Exitosa!', 'Dialogo Alert');
document.getElementById("botonagregar").disabled=true;
document.getElementById("botoneliminar").disabled=true;
}
else
{
window.parent.jAlert('Operacion Fallida!', 'Dialogo Alert');
}
}
function validarControles()
{
var validacion=true;
if(document.getElementById("numboleta").value==""||document.getElementById("idb").value==""||document.getElementById("nombresb").value==""||document.getElementById("direccionb").value==""||document.getElementById("dnib").value==""||document.getElementById("telefonob").value==""||document.getElementById("fVentab").value==""||document.getElementById("fEntregab").value=="")
{
validacion=false;
}
else
{
document.getElementById("botonagregar").disabled=false;
}
return validacion;
}
function validacionGeneral()
{
var validacionGeneral=true;
var validacionCliente=validarControles();
var tabla = document.getElementById("scrollTable1");
var numFilas=$('#scrollTable1').dataTable().fnGetNodes().length;
if(numFilas<1 && validacionCliente)
{
validacionGeneral=false;
}
return validacionGeneral;
}
