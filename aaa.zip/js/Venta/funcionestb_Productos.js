var idproducto;
var categoria;
var modelo;
var marca;
var color;
var talla;
var precio;
var stock;
var ruta="";
$(document).ready(function(){
						   $('#cantidad').numeric();
						   	oTable=$('#example').dataTable({
					"bJQueryUI": true,
"sPaginationType": "full_numbers",
'bPaginate': true,
					'bLengthChange':false, /*Sirve para mostrar al lado superior izquierdo la opcion Show 10 entries*/
'iDisplayLength': 4 /*Para cambiar el tama�o de paginacion*/
				});
							
							$('#example tbody tr').live('click',function(event){
											 $(oTable.fnSettings().aoData).each(function (){
            $(this.nTr).removeClass('row_selected');
				            });
            $(event.target.parentNode).addClass('row_selected');
		var celdas=oTable.fnGetData(this);
		
idproducto=celdas[0];
categoria=celdas[1];
modelo=celdas[3];
marca=celdas[2];
color=celdas[4];
talla=celdas[5];
precio=celdas[7];
stock=celdas[8];
var value2=String(celdas[9]);
ruta=value2.split(" ")[1].split("=")[1];
											 });
							
					
						$('#addproducto').click(function(e){
														 if(stock!=undefined)
														 {
														 if($('#cantidad').val()!="")
														 {
															 if(parseInt($('#cantidad').val())<stock)
															 {
														 var cantidad=$('#cantidad').val();
														 var costo=$('#cantidad').val()*precio;
														 
	var fila_repetido=window.parent.jQuery.fn.ProductoRepetido(idproducto);
									if(fila_repetido!="")
									{
window.parent.$('#scrollTable1').dataTable().fnUpdate(idproducto,fila_repetido-1,0);

window.parent.$('#scrollTable1').dataTable().fnUpdate(categoria+" "+marca+" "+modelo+" "+color+" "+talla,fila_repetido-1,1);

window.parent.$('#scrollTable1').dataTable().fnUpdate(String(precio),fila_repetido-1,2);

window.parent.$('#scrollTable1').dataTable().fnUpdate(String(parseInt(window.parent.$('#scrollTable1').dataTable().fnGetData(fila_repetido-1)[3])+parseInt(cantidad)),fila_repetido-1,3);
							
window.parent.$('#scrollTable1').dataTable().fnUpdate(String(parseFloat(window.parent.$('#scrollTable1').dataTable().fnGetData(fila_repetido-1)[4])+parseFloat(costo)),fila_repetido-1,4);
									}
									else
									{
														 window.parent.$('#scrollTable1').dataTable().fnAddData([idproducto,categoria+" "+marca+" "+modelo+" "+color+" "+talla,String(precio),String(cantidad),String(costo)]);
										
									}
window.parent.document.getElementById("subtotal").value=jQuery.fn.CalcularSubtotal(2);
window.parent.document.getElementById("igv").value=jQuery.fn.CalcularIGV(2);
window.parent.document.getElementById("total").value=jQuery.fn.CalcularTotal(2);
									window.parent.document.getElementById("nuevoyguardar").disabled=false;
									 window.parent.iframe.dialog("close");
														 }
														 else
														 {
														 
														 window.parent.jAlert('No hay suficiente stock','Dialogo Alert');
														 }
														 }
														 

														 else
														 {
													window.parent.jAlert('Digita una cantidad','Dialogo Alert');
														 }
														 }
														 else
														 {
														 window.parent.jAlert('Selecciona un Producto','Dialogo Alert');
														 }
														 });
							


jQuery.fn.VistaPrevia=function()
{
var urlfoto_grande="../../../Vista/Mantenimiento/Producto/foto_grande.php?url_foto="+ruta.split('"')[1];
var iframeFoto_Grande=$('<iframe src="'+urlfoto_grande+'" />');
			iframeFoto_Grande.dialog({
							autoOpen:true,
							modal:true,
						    title: "Vista Previa",
 width : 400,
 height :300,
 position : 'top',
resizable : false,


						
                           close:function(event,ui)
            {
                          
						  
						  }
 
       }).width(380).height(240);
}

jQuery.fn.CalcularSubtotal=function()
{
	var subtotal=0.00;
var tabla = window.parent.document.getElementById("scrollTable1");
for (var i=1; i<tabla.rows.length;i++)
{
subtotal+=parseFloat(tabla.rows[i].cells[4].innerHTML);
}
return subtotal;
};

jQuery.fn.CalcularIGV=function()
{
var igv=0.18*jQuery.fn.CalcularSubtotal();
return igv;
}
jQuery.fn.CalcularTotal=function()
{
var subtotal=parseFloat(window.parent.document.getElementById("subtotal").value);
var igv=parseFloat(window.parent.document.getElementById("igv").value);
var total=subtotal+igv;
return total;
}
						   
						   });