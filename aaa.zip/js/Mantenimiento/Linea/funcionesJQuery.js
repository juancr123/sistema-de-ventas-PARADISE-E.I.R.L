$(document).ready(function()
 {
$('#linea').dataTable({
	"bJQueryUI": true,
					'bPaginate': true,
					'bLengthChange':false, /*Sirve para mostrar al lado superior izquierdo la opcion Show 10 entries*/
					 "sPaginationType": "full_numbers",
					'iDisplayLength': 10 /*Para cambiar el tama�o de paginacion*/
				});
			
		});

