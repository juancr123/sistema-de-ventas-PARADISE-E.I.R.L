// JavaScript Document
var idLinea=0;
var operacionABM=1;
function pulsar2(obj,e)
{
resetearcolortabla();
obj.style.backgroundColor = '#E2E4FF';
if(!e)e=window.event;
if(!e.target) e.target=e.srcElement;
// e.target ahora simboliza la celda en la que hemos hecho click
// subimos de nivel hasta encontrar un tr
var TR=e.target;
if(!(TR.nodeName=="INPUT"))
{
while( TR.nodeType==1 && TR.tagName.toUpperCase()!="TR" )
TR=TR.parentNode;
var celdas=TR.getElementsByTagName("TD");
// cogemos la primera celda TD del tr (si existe)
if( celdas.length!=0 )
    {
	document.getElementById("txtLinea").value=celdas[1].innerHTML;
	document.getElementById("id_linea").value=celdas[0].innerHTML;
 ControlBotones(false,true,false,true,false,false);
}
}
}

function EstadoCajas(estado)
{
document.getElementById("txtLinea").disabled=estado;

}
function LimpiarCajas()
{
document.getElementById("txtLinea").value="";

resetearcolortabla();
}
function ControlBotones(estado,estado2,estado3,estado4,estado5,estado6)
{
document.getElementById("btnNuevo").disabled=estado;
document.getElementById("btnGuardar").disabled=estado2;
document.getElementById("btnEditar").disabled=estado3;
document.getElementById("btnCancelar").disabled=estado4;
document.getElementById("btnEliminar").disabled=estado5;
}

function resetearcolortabla()
{
var tabla=document.getElementById("linea");
for (var i=1; i<tabla.rows.length; i++)
{
tabla.rows[i].style.backgroundColor='white';
}
}
function TransaccionNormal(opcion)
{
nombre_Linea=document.getElementById('txtLinea').value;
location.href="Controlador/Mantenimiento/Linea/p_linea.php?opcion="+opcion+"&id_linea="+idLinea+"&nombre_linea="+nombre_Linea;
}
function validarTransaccion(respuesta2)
{
if(respuesta2=="1")
{
window.parent.jAlert('Operacion Exitosa!', 'Dialogo Alert');
}
else if(respuesta2=="0")
 {
 window.parent.jAlert('Operacion Fallida!', 'Dialogo Alert');
 }
 else
 {
 window.parent.jAlert('Ocurrio un Error!', 'Dialogo Alert');
 }
}
function body_onLoad()
{
ControlEventos(0);
}
function ControlEventos(operacion)
{
switch(operacion)
{
case 0 :
EstadoCajas(true);
ControlBotones(false,true,true,true,true,false);
break;
case 1 :
LimpiarCajas();
                EstadoCajas(false);
              ControlBotones(true,false,true,false,true,true);

break;
case 2 :
 if(operacionABM==1)
                {
window.parent.jConfirm('Esta seguro de agregar un nuevo Registro?', 'Confirmation Dialog', function(r) {
if(r)
{
/*Transaccion(1);*/
TransaccionNormal(1);
}
else
{
window.parent.jAlert('Se Cancelo la Operacion!', 'Dialogo Alert');
}
	});
				}
				else
				{
				window.parent.jConfirm('Estado seguro de modificar el Registro ?', 'Confirmation Dialog', function(r) {
				if(r)
				{
				/*Transaccion(2);*/
				TransaccionNormal(2);
}
				else
				{
				window.parent.jAlert('Se Cancelo la Operacion!', 'Dialogo Alert');
				}
				
			 });
				}


break;
case 3 :
EstadoCajas(false);
ControlBotones(true,false,true,false,true,true);
break;
case 4 :
EstadoCajas(true);
                ControlBotones(false,true,true,true,true,false);
                LimpiarCajas();

break;
case 5 :
	window.parent.jConfirm('Estado seguro de eliminar el Registro ?', 'Confirmation Dialog', function(r) {
	if(r)
				{
				/*Transaccion(3);*/
				TransaccionNormal(3);
}
				else
				{
				window.parent.jAlert('Se Cancelo la Operacion!', 'Dialogo Alert');
				}
			
});
break;
}

}
function btnNuevo_onClick()
{
//operacionABM=1;
document.getElementById("opcion").value=1;
ControlEventos(1);
}
function btnGuardar_onClick()
{
//ControlEventos(2);
}
function btnEditar_onClick()
{
//operacionABM=2;
document.getElementById("opcion").value=2;
ControlEventos(3);
}
function btnCancelar_onClick()
{
ControlEventos(4);
}
function btnEliminar_onClick()
{
EstadoCajas(false);
document.getElementById("opcion").value=3;
ControlEventos(5);
}
