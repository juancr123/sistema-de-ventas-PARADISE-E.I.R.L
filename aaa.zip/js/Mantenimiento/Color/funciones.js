$(document).ready(function(){
						   	   oTable=$('#color').dataTable({
					"bJQueryUI": true,
					'bPaginate': true,
					'bLengthChange':false, /*Sirve para mostrar al lado superior izquierdo la opcion Show 10 entries*/
					 "sPaginationType": "full_numbers",
					'iDisplayLength': 10 /*Para cambiar el tama�o de paginacion*/
					});
							   
							   $('#color tbody tr').live('click',function(event){
											 $(oTable.fnSettings().aoData).each(function (){
            $(this.nTr).removeClass('row_selected');
				            });
            $(event.target.parentNode).addClass('row_selected');
jQuery.fn.ControlBotones(false,true,false,true,false,false);
jQuery.fn.Estado(true);
		var celdas=oTable.fnGetData(this);
		
		$('#id_color').val(celdas[0]);
		$('#txtColor').val(celdas[1]);
		
											 });

							   
							     
						   
						   $('#btnNuevo').click(function(e){
														 $('#opcion').val(1);
														 jQuery.fn.Estado(false);
											jQuery.fn.Limpiar();
											jQuery.fn.ControlBotones(true,false,true,false,true,true);
														 });
						    $('#btnEditar').click(function(e){
														 $('#opcion').val("2");
														 jQuery.fn.Estado(false);	
											jQuery.fn.ControlBotones(true,false,true,false,true,true);		
														 });
																		$('#btnCancelar').click(function(e){
										    jQuery.fn.Estado(true);	
											jQuery.fn.Limpiar();
											jQuery.fn.ControlBotones(false,true,true,true,true,false);								 });
							 $('#btnEliminar').click(function(e){
														 $('#opcion').val(3);
														  jQuery.fn.Estado(false);
														 });
						   
						   
						   
jQuery.fn.Estado=function(state)
{
$('#txtColor').attr("disabled",state);
};			   
						   
jQuery.fn.Limpiar=function()
{
$('#txtColor').val("");
};
jQuery.fn.ControlBotones=function(state1,state2,state3,state4,state5,state6)
{
$('#btnNuevo').attr("disabled",state1);
$('#btnGuardar').attr("disabled",state2);
$('#btnEditar').attr("disabled",state3);
$('#btnCancelar').attr("disabled",state4);
$('#btnEliminar').attr("disabled",state5);
};

jQuery.fn.Estado(true);
	jQuery.fn.ControlBotones(false,true,true,true,true,false);
						   
						   });