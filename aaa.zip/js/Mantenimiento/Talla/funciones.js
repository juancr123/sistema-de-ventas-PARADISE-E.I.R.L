var id_talla;
$(document).ready(function(){
						   	   oTable=$('#talla').dataTable({
					"bJQueryUI": true,
					'bPaginate': true,
					'bLengthChange':false, /*Sirve para mostrar al lado superior izquierdo la opcion Show 10 entries*/
					 "sPaginationType": "full_numbers",
					'iDisplayLength': 10 /*Para cambiar el tama�o de paginacion*/
					});
	
			$('#talla tbody tr').live('click',function(event){
											 $(oTable.fnSettings().aoData).each(function (){
            $(this.nTr).removeClass('row_selected');
				            });
            $(event.target.parentNode).addClass('row_selected');
jQuery.fn.ControlBotones(false,true,false,true,false,false);
jQuery.fn.Estado(true);
		var celdas=oTable.fnGetData(this);
		
$('#id_talla').val(celdas[0]);
	$('#txtTalla').val(celdas[1]);
	$('#cmbCategoria').val($("#cmbCategoria option:contains('"+celdas[2]+"')").val());
											 });

			  
						   $('#btnNuevo').click(function(e){
														 $('#opcion').val(1);
														 jQuery.fn.Estado(false);
											jQuery.fn.Limpiar();
											jQuery.fn.ControlBotones(true,false,true,false,true,true);
														 });
						    $('#btnEditar').click(function(e){
														 $('#opcion').val("2");
														 jQuery.fn.Estado(false);	
											jQuery.fn.ControlBotones(true,false,true,false,true,true);		
														 });
																		$('#btnCancelar').click(function(e){
										    jQuery.fn.Estado(true);	
											jQuery.fn.Limpiar();
											jQuery.fn.ControlBotones(false,true,true,true,true,false);								 });
							 $('#btnEliminar').click(function(e){
														 $('#opcion').val(3);
														  jQuery.fn.Estado(false);
														 });
						   
						   
						   
jQuery.fn.Estado=function(state)
{
$('#txtTalla').attr("disabled",state);
$('#cmbCategoria').attr("disabled",state);
};			   
						   
jQuery.fn.Limpiar=function()
{
$('#txtTalla').val("");
$('#cmbCategoria').val("0");
};
jQuery.fn.ControlBotones=function(state1,state2,state3,state4,state5,state6)
{
$('#btnNuevo').attr("disabled",state1);
$('#btnGuardar').attr("disabled",state2);
$('#btnEditar').attr("disabled",state3);
$('#btnCancelar').attr("disabled",state4);
$('#btnEliminar').attr("disabled",state5);
};
jQuery.fn.Estado(true);
	jQuery.fn.ControlBotones(false,true,true,true,true,false);
						   });