var distrito;
$(document).ready(function(e){
						   
						   oTable=$('#mantenimiento_clientes').dataTable({
					"bJQueryUI": true, /*para utilizar el estilo smothness*/
					'bPaginate': true, /*para paginacion*/
					'bFilter': true, /*para realizar busqueda de datos */
					'bInfo' : true,/*Para mostrar cantidad de resultados mostrados*/
					'bLengthChange':false, /*Sirve para mostrar al lado superior izquierdo la opcion Show 10 entries*/
					 "sPaginationType": "full_numbers",
					'iDisplayLength': 5 /*Para cambiar el tama�o de paginacion*/
					});
						   
			$('#mantenimiento_clientes tbody tr').live('click',function(event){
											 $(oTable.fnSettings().aoData).each(function (){
            $(this.nTr).removeClass('row_selected');
				            });
            $(event.target.parentNode).addClass('row_selected');
jQuery.fn.ControlBotones(false,true,false,true,false,false);
jQuery.fn.Estado(true);
		var celdas=oTable.fnGetData(this);
		
	$('#id_cliente').val(celdas[0]);
    $('#dni').val(celdas[1]);
	$('#ruc').val(celdas[2]);
	$('#nombres').val(celdas[3]);
	$('#apellidos').val(celdas[4]);
	$('#provincia').val($("#provincia option:contains('"+celdas[5]+"')").val());
	distrito=celdas[6];
	$('#direccion').val(celdas[7]);
	$('#telefono').val(celdas[8]);
	$('#celular').val(celdas[9]);
	
	$.post("../../../Vista/Mantenimiento/Personal/cmbdistrito.php",
																				   {
																				   id_provincia:$('#provincia').val()
																				   },
																				   function(data){
																					 
																					   																					   $('#distrito').html(data);
										
																				   
																				   });
	
											 
											 
											 });

						   
						   
						    $('#provincia').change(function(e){
			$.post("../../../Vista/Mantenimiento/Personal/cmbdistrito.php",
																				   {
																				   id_provincia:$('#provincia').val()
																				   },
																				   function(data){
																					  
																					   																					   $('#distrito').html(data);
																				   });
														   });
						   
						   $('#btnNuevo').click(function(e){
											
											$('#opcion').val("1");
											jQuery.fn.Estado(false);
											jQuery.fn.Limpiar();
											jQuery.fn.ControlBotones(true,false,true,false,true,true);
																		  });
											
											$('#btnEditar').click(function(e){
										    //operacionABM=2;
											$('#opcion').val("2");
											jQuery.fn.Estado(false);	
											jQuery.fn.ControlBotones(true,false,true,false,true,true);	
											$('#distrito').val($("#distrito option:contains('"+distrito+"')").val());
																		   });
											$('#btnCancelar').click(function(e){
										    jQuery.fn.Estado(true);	
											jQuery.fn.Limpiar();
											jQuery.fn.ControlBotones(false,true,true,true,true,false);								 });
											$('#btnEliminar').click(function(e){
											jQuery.fn.Estado(false);
											$('#opcion').val("3");
																		 });
						   
						   
						   
						   
						   
						   
						   
						   
						   jQuery.fn.Estado=function(state)
{
$('#dni').attr("disabled",state);
$('#ruc').attr("disabled",state);
$('#nombres').attr("disabled",state);
$('#apellidos').attr("disabled",state);
$('#distrito').attr("disabled",state);
$('#provincia').attr("disabled",state);
$('#direccion').attr("disabled",state);
$('#telefono').attr("disabled",state);
$('#celular').attr("disabled",state);
};

jQuery.fn.Limpiar=function()
{
        $('#nombre').val("");
$('#dni').val("");
$('#ruc').val("");
$('#nombres').val("");
$('#apellidos').val("");
$('#distrito').val("");
$('#provincia').val("");
$('#direccion').val("");
$('#telefono').val("");
$('#celular').val("");
};
jQuery.fn.ControlBotones=function(state1,state2,state3,state4,state5,state6)
{
$('#btnNuevo').attr("disabled",state1);
$('#btnGuardar').attr("disabled",state2);
$('#btnEditar').attr("disabled",state3);
$('#btnCancelar').attr("disabled",state4);
$('#btnEliminar').attr("disabled",state5);
};

	jQuery.fn.Estado(true);
	jQuery.fn.ControlBotones(false,true,true,true,true,false);
						   
						   $('#btnEWord').click(function(e){
							  

	var string2=$('#btnEWord').attr("data");
	
	$(location).attr('href','../../../Vista/Mantenimiento/Exportar/Word.php?arrays='+string2);

							  });

$('#btnEExcel').click(function(e){
							  

	var string2=$('#btnEExcel').attr("data");
	
	$(location).attr('href','../../../Vista/Mantenimiento/Exportar/Excel.php?arrays='+string2);

							  });

$('#btnEPdf').click(function(e){
							  

		var string2=$('#btnEPdf').attr("data");
	
	$(location).attr('href','../../../Vista/Mantenimiento/Exportar/Pdf.php?arrays='+string2);

							  });
						   });