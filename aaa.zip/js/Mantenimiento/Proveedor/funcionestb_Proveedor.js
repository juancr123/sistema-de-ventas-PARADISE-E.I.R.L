var id_proveedor2;
var ruc;
var razon_social;
var nombres;
$(document).ready(function()
 {
	 oTable=$('#proveedores').dataTable({
					"bJQueryUI": true,
					'bPaginate': true,
					'bLengthChange':false, /*Sirve para mostrar al lado superior izquierdo la opcion Show 10 entries*/
//"sScrollY": "39%",
"sPaginationType": "full_numbers",
'iDisplayLength': 5 /*Para cambiar el tama�o de paginacion*/
				});
	 
	 $('#proveedores tbody tr').live('click',function(event){
											 $(oTable.fnSettings().aoData).each(function (){
            $(this.nTr).removeClass('row_selected');
				            });
            $(event.target.parentNode).addClass('row_selected');

		var celdas=oTable.fnGetData(this);
		
	id_proveedor2=celdas[0];
	
razon_social=celdas[2];
nombres=celdas[3]+" "+celdas[4];
ruc=celdas[1];
											 });

	 
	 $('#btnAgregarProveedor').click(function(e){
											
											  window.parent.$('#id_proveedor2').val(id_proveedor2);
											  window.parent.$('#ruc2').val(ruc);
											  window.parent.$('#nombres2').val(nombres);
											  window.parent.$('#razon_social2').val(razon_social);
											  $.post("tablaproductoproveedor.php",{
													id_proveedor:id_proveedor2
													
													},function(data){
													window.parent.$('#pp tbody').html(data);	
													});
											 window.parent.iframeBuscarProveedor.dialog("close");
											  
											

											  });
	 
 });