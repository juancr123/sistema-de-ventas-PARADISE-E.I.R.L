var distrito;
$(document).ready(function(e){
						   $('#nuevo_proveedor').validationEngine();
						   $('#ruc').numeric();
						   $('#telefono').numeric();
						   oTable=$('#proveedor').dataTable({
					"bJQueryUI": true,
					'bPaginate': true,
					'bLengthChange':false, /*Sirve para mostrar al lado superior izquierdo la opcion Show 10 entries*/
					 "sPaginationType": "full_numbers",
					 "sScrollX": "928px",/*tiende a llevar distintos valores cuando se trabaja con ventana flotante este parametro */                   
					'iDisplayLength': 4 /*Para cambiar el tama�o de paginacion*/
					});
						   
						   
						   $('#proveedor tbody tr').live('click',function(event){
											 $(oTable.fnSettings().aoData).each(function (){
            $(this.nTr).removeClass('row_selected');
				            });
            $(event.target.parentNode).addClass('row_selected');
jQuery.fn.ControlBotones(false,true,false,true,false,false);
jQuery.fn.Estado(true);
		var celdas=oTable.fnGetData(this);
		
$('#id_proveedor').val(celdas[0]);
	$('#nombres').val(celdas[3]);
	$('#apellidos').val(celdas[4]);
	$('#ruc').val(celdas[1]);
	$('#razon_social').val(celdas[2]);
	$('#direccion').val(celdas[5]);
	
	$('#cmbProvincia').val($("#cmbProvincia option:contains('"+celdas[6]+"')").val());
	distrito=celdas[7];
	$('#telefono').val(celdas[8]);
	$('#celular').val(celdas[9]);
	$('#rpm').val(celdas[10]);
	$('#email').val(celdas[11]);
	$('#fax').val(celdas[12]);
	$.post("../../../Vista/Mantenimiento/Personal/cmbdistrito.php",
																				   {
																				   id_provincia:$('#cmbProvincia').val()
																				   },
																				   function(data){
																					 
																					   																					   $('#cmbDistrito').html(data);
										
																				   });
											 });

						   $('#btnNuevo').click(function(e){
														 $('#opcion').val(1);
														 jQuery.fn.Estado(false);
											jQuery.fn.Limpiar();
											jQuery.fn.ControlBotones(true,false,true,false,true,true);
														 });
						    $('#btnEditar').click(function(e){
														 $('#opcion').val("2");
											jQuery.fn.Estado(false);	
											jQuery.fn.ControlBotones(true,false,true,false,true,true);
											$('#cmbDistrito').val($("#cmbDistrito option:contains('"+distrito+"')").val());
														 });
							$('#btnCancelar').click(function(e){
										    jQuery.fn.Estado(true);	
											jQuery.fn.Limpiar();
											jQuery.fn.ControlBotones(false,true,true,true,true,false);	
											jQuery.fn.ResetearColorTabla("proveedor");
											});
							 $('#btnEliminar').click(function(e){
														 $('#opcion').val(3);
														  jQuery.fn.Estado(false);
														 });
						   

jQuery.fn.Estado=function(state)
{
$('#nombres').attr("disabled",state);
$('#apellidos').attr("disabled",state);
$('#ruc').attr("disabled",state);
$('#razon_social').attr("disabled",state);
$('#direccion').attr("disabled",state);
$('#cmbDistrito').attr("disabled",state);
$('#cmbProvincia').attr("disabled",state);
$('#telefono').attr("disabled",state);
$('#celular').attr("disabled",state);
$('#rpm').attr("disabled",state);
$('#email').attr("disabled",state);
$('#fax').attr("disabled",state);
};
jQuery.fn.Limpiar=function()
{
$('#nombres').val("");
$('#apellidos').val("");
$('#ruc').val("");
$('#razon_social').val("");
$('#direccion').val("");
$('#cmbProvincia').val(187);
$.post("../../../Vista/Mantenimiento/Personal/cmbdistrito.php",
																				   {
																				   id_provincia:$('#cmbProvincia').val()
																				   },
																				   function(data){
																					 
																					   																					   $('#cmbDistrito').html(data);
										
																				   });
$('#telefono').val("");
$('#celular').val("");
$('#rpm').val("");
$('#email').val("");
$('#fax').val("");
};
jQuery.fn.ControlBotones=function(state1,state2,state3,state4,state5,state6)
{
$('#btnNuevo').attr("disabled",state1);
$('#btnGuardar').attr("disabled",state2);
$('#btnEditar').attr("disabled",state3);
$('#btnCancelar').attr("disabled",state4);
$('#btnEliminar').attr("disabled",state5);
};

jQuery.fn.Estado(true);
	jQuery.fn.ControlBotones(false,true,true,true,true,false);
	
	$('#cmbProvincia').change(function(e)
									{
										$.post("../../../Vista/Mantenimiento/Personal/cmbdistrito.php",
																				   {
																				   id_provincia:$('#cmbProvincia').val()
																				   },
																				   function(data){
																					 
																					   																					   $('#cmbDistrito').html(data);
																					 
																					  
																					
																					
																					
																					
																				   });	
									});
	
	/*$('#btnEWord').click(function(e){
							  

	var string2=$('#btnEWord').attr("data");
	
	$(location).attr('href','../../../Vista/Mantenimiento/Exportar/Word.php?arrays='+string2);

							  });

$('#btnEExcel').click(function(e){
							  

	var string2=$('#btnEExcel').attr("data");
	
	$(location).attr('href','../../../Vista/Mantenimiento/Exportar/Excel.php?arrays='+string2);

							  });

$('#btnEPdf').click(function(e){
							  

		var string2=$('#btnEPdf').attr("data");
	
	$(location).attr('href','../../../Vista/Mantenimiento/Exportar/Pdf.php?arrays='+string2);

							  });*/

	$.post("../../../Vista/Mantenimiento/Personal/cmbdistrito.php",
																				   {
																				   id_provincia:$('#cmbProvincia').val()
																				   },
																				   function(data){
																					 
																					   																					   $('#cmbDistrito').html(data);
																					 
																					  
																					
																					
																					
																					
																				   });
						   
						   });