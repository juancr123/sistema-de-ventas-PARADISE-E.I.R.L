$(document).ready(function(e){
					$('#tabs').tabs();	   
						   });
						   