var id_producto;
var descripcion;
$(document).ready(function(e){
						   
						      oTable=$('#productos').dataTable({
					"bJQueryUI": true,
					'bPaginate': true,
					'bLengthChange':false, /*Sirve para mostrar al lado superior izquierdo la opcion Show 10 entries*/
					 "sPaginationType": "full_numbers",
					 //"sScrollX": "928px",/*tiende a llevar distintos valores cuando se trabaja con ventana flotante este parametro */                   
					'iDisplayLength': 5 /*Para cambiar el tama�o de paginacion*/
					});
							  
				$('#productos tbody tr').live('click',function(event){
											 $(oTable.fnSettings().aoData).each(function (){
            $(this.nTr).removeClass('row_selected');
				            });
            $(event.target.parentNode).addClass('row_selected');
		var celdas=oTable.fnGetData(this);
		
	id_producto=celdas[0];
	descripcion=celdas[1]+" "+celdas[3]+" "+celdas[4]+" "+celdas[5]+" "+celdas[6];
											 });

							  
							  $('#btnAceptar').click(function(e){
															  window.parent.$('#id_producto').val(id_producto);
															  window.parent.$('#descripcion').val(descripcion);
															  window.parent.iframeBuscarProducto.dialog("close");
															  });
							  
						   });