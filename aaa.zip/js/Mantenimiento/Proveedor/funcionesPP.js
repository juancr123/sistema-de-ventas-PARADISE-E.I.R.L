var iframeBuscarProveedor;
var iframeBuscarProducto;
$(document).ready(function(e){
						   oTable=$('#pp').dataTable({
					"bJQueryUI": true,
					'bPaginate': true,
					'bLengthChange':false, /*Sirve para mostrar al lado superior izquierdo la opcion Show 10 entries*/
					 "sPaginationType": "full_numbers",
					'iDisplayLength': 5 /*Para cambiar el tama�o de paginacion*/
					});
						   
	$('#btnBuscarProveedor').click(function(e){
	var url="../../../Vista/Mantenimiento/Proveedor/tablaproveedores.php";
    iframeBuscarProveedor=$('<iframe src="'+ url +'" />'); 
			iframeBuscarProveedor.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Lista de Proveedores",
 width : 780,
 height : 300,
 bgiframe:true,
 position : 'top',
resizable : false,
							autoResize: true,
                           close:function(event,ui)
            {
                          }
 
       }).width(780).height(330);	
											});
			
			  $('#btnBuscarProducto').click(function(e){
	var url2="../../../Vista/Mantenimiento/Proveedor/tablaproductos.php";
    iframeBuscarProducto=$('<iframe src="'+ url2 +'" />'); 
			iframeBuscarProducto.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Lista de Productos",
 width : 880,
 height : 450,
 bgiframe:true,
 position : 'top',
resizable : false,
							autoResize: true,
                           close:function(event,ui)
            {
                          }
 
       }).width(860).height(430);			
																   
																   });
						   $('#btnNuevo2').click(function(e){
														 $('#opcion').val(1);
														 jQuery.fn.Estado(false);
											jQuery.fn.Limpiar();
											jQuery.fn.ControlBotones(true,false,true,false,true,true);
														 });
						   $('#btnGuardar2').click(function(e){
												   /*$(location).attr('href','p_proveedorproducto.php?opcion='+$('#opcion').val()+'&id_proveedorproducto='+$('#id_productoproveedor').val()+'&id_proveedor='+$('#id_proveedor2').val()+'&id_producto='+$('#id_producto').val()+'&precio_compra='+$('#precio_compra').val());*/
												   $.get("p_proveedorproducto.php",{
												   opcion:$('#opcion').val(),
												   id_proveedorproducto:$('#id_productoproveedor').val(),
												   id_proveedor:$('#id_proveedor2').val(),
												   id_producto:$('#id_producto').val(),
												   precio_compra:$('#precio_compra').val()
												   
												   
												   
												   },function(data){
																		if(data=="1")
																		{
																		jAlert('Operacion Exitosa', 'Dialogo Alert');
													$.post("../../../Vista/Mantenimiento/Proveedor/tablaproductoproveedor.php",{
													id_proveedor:$('#id_proveedor2').val()
													
													},function(data){
													$('#pp tbody').html(data);
													jQuery.fn.ControlBotones(false,true,true,true,true,false);
													});
																		
																		}
																		else
																		{
																		jAlert('Operacion Fallida', 'Dialogo Alert');
																		}
																						 
																						 });
															});
						    $('#btnEditar2').click(function(e){
											$('#opcion').val("2");
											jQuery.fn.Estado(false);	
											jQuery.fn.ControlBotones(true,false,true,false,true,true);
																					
														 });
							$('#btnCancelar2').click(function(e){
										    jQuery.fn.Estado(true);	
											jQuery.fn.Limpiar();
											jQuery.fn.ControlBotones(false,true,true,true,true,false);	
											jQuery.fn.ResetearColorTabla("pp");
											});
							 $('#btnEliminar2').click(function(e){
														 $('#opcion').val(3);
														 
														  $.get("p_proveedorproducto.php",{
												   opcion:$('#opcion').val(),
												   id_proveedorproducto:$('#id_productoproveedor').val(),
												   id_proveedor:$('#id_proveedor2').val(),
												   id_producto:$('#id_producto').val(),
												   precio_compra:$('#precio_compra').val()
												   
												   
												   
												   },function(data){
																		if(data=="1")
																		{
																		jAlert('Operacion Exitosa', 'Dialogo Alert');
													$.post("../../../Vista/Mantenimiento/Proveedor/tablaproductoproveedor.php",{
													id_proveedor:$('#id_proveedor2').val()
													
													},function(data){
													$('#pp tbody').html(data);	
													});
																		
																		}
																		else
																		{
																		jAlert('Operacion Fallida', 'Dialogo Alert');
																		}
																						 
																						 });
														 });
						   
			jQuery.fn.Pulsar=function(obj,e)
{
jQuery.fn.ControlBotones(false,true,false,true,false,false);
jQuery.fn.Estado(true);
jQuery.fn.ResetearColorTabla("pp");
obj.style.backgroundColor = '#E2E4FF';
if(!e)e=window.event;
if(!e.target) e.target=e.srcElement;
// e.target ahora simboliza la celda en la que hemos hecho click
// subimos de nivel hasta encontrar un tr
var TR=e.target;
if(!(TR.nodeName=="INPUT"))
{
while( TR.nodeType==1 && TR.tagName.toUpperCase()!="TR" )
TR=TR.parentNode;
var celdas=TR.getElementsByTagName("TD");
// cogemos la primera celda TD del tr (si existe)
if( celdas.length!=0 )
    {
	$('#id_productoproveedor').val(celdas[0].innerHTML);
	$('#id_producto').val(celdas[1].innerHTML);
$('#descripcion').val(celdas[2].innerHTML);
$('#precio_compra').val(celdas[4].innerHTML);
	
	
}
}
};
jQuery.fn.Estado=function(state)
{
$('#descripcion').attr("disabled",state);
$('#precio_compra').attr("disabled",state);
$('#btnBuscarProducto').attr("disabled",state);
};
jQuery.fn.ControlBotones=function(state1,state2,state3,state4,state5,state6)
{
$('#btnNuevo2').attr("disabled",state1);
$('#btnGuardar2').attr("disabled",state2);
$('#btnEditar2').attr("disabled",state3);
$('#btnCancelar2').attr("disabled",state4);
$('#btnEliminar2').attr("disabled",state5);
};
jQuery.fn.Limpiar=function()
{
$('#id_producto').val("");
$('#descripcion').val("");
$('#precio_compra').val("");
};
jQuery.fn.ResetearColorTabla=function(tabla)
{
var tabla2 = document.getElementById(tabla);
for (var i=1; i<tabla2.rows.length; i++)
{
tabla2.rows[i].style.backgroundColor='white';
}
};
						   jQuery.fn.Estado(true);
	jQuery.fn.ControlBotones(false,true,true,true,true,false);
						   });