var distrito;

$(document).ready(function(){

						   oTable=$('#personal').dataTable({
					"bJQueryUI": true,
					'bPaginate': true,
					'bLengthChange':false, /*Sirve para mostrar al lado superior izquierdo la opcion Show 10 entries*/
					 "sPaginationType": "full_numbers",
					  "sScrollX": "965px",
					'iDisplayLength': 5 /*Para cambiar el tama�o de paginacion*/
					});
						   $('#personal tbody tr').live('click',function(event){
		 $(oTable.fnSettings().aoData).each(function (){
            $(this.nTr).removeClass('row_selected');
			
					            });
            $(event.target.parentNode).addClass('row_selected');
																	
		jQuery.fn.ControlBotones(false,true,false,true,false,false);
		jQuery.fn.Estado(true);			
		
		var celdas=oTable.fnGetData(this);
		$('#dni').val(celdas[0]);
		distrito=celdas[4];
$('#nombres').val(celdas[1]);
$('#apellidos').val(celdas[2]);
$('#direccion').val(celdas[5]);
$('#telefono').val(celdas[7]);
if(celdas[6].innerHTML=="M")
{
$('#sexo1').attr("checked",true);
}
else
{
$('#sexo2').attr("checked",true);
}
$('#celular').val(celdas[8]);
$('#email').val(celdas[9]);
$('#provincia').val($("#provincia option:contains('"+celdas[3]+"')").val());
$('#clave').val(celdas[10]);
$('#tipo').val($("#tipo option:contains('"+celdas[11]+"')").val());
$.post("../../../Vista/Mantenimiento/Personal/cmbdistrito.php",
																				   {
																				   id_provincia:$('#provincia').val()
																				   },
																				   function(data){
																					 
																					   																					   $('#distrito').html(data);
										
																				   });
																	});
						    
			$('#provincia').change(function(e){
			$.post("../../../Vista/Mantenimiento/Personal/cmbdistrito.php",
																				   {
																				   id_provincia:$('#provincia').val()
																				   },
																				   function(data){
																					  
																					   																					   $('#distrito').html(data);
																				   });
														   });
						   
						   $('#btnNuevo').click(function(e){
											$('#provincia').val(187);
											$.post("../../../Vista/Mantenimiento/Personal/cmbdistrito.php",
																				   {
																				   id_provincia:$('#provincia').val()
																				   },
																				   function(data){
																					 
																					   																					   $('#distrito').html(data);
										
																				   });
											operacionABM=1;
											$('#opcion').val("1");
											jQuery.fn.Estado(false);
											jQuery.fn.Limpiar();
											jQuery.fn.ControlBotones(true,false,true,false,true,true);
											
																		  });
						   
						   $('#btnEditar').click(function(e){
										    //operacionABM=2;
											$('#opcion').val("2");
											jQuery.fn.Estado(false);	
											jQuery.fn.ControlBotones(true,false,true,false,true,true);
											$('#distrito').val($("#distrito option:contains('"+distrito+"')").val());
																		   });
											$('#btnCancelar').click(function(e){
											jQuery.fn.ResetearColorTabla("personal");
										    jQuery.fn.Estado(true);	
											jQuery.fn.Limpiar();
											jQuery.fn.ControlBotones(false,true,true,true,true,false);								 });
											/*$('#btnEliminar').click(function(e){
											 jQuery.fn.Estado(false);
											$('#opcion').val(3);
								            
											
											
																			 });*/
			jQuery.fn.Estado=function(state)
{
	$('#sexo1').attr("disabled",state);
$('#sexo2').attr("disabled",state);
$('#nombres').attr("disabled",state);
$('#apellidos').attr("disabled",state);
$('#direccion').attr("disabled",state);
$('#telefono').attr("disabled",state);
$('#celular').attr("disabled",state);
$('#email').attr("disabled",state);

$('#dni').attr("disabled",state);
$('#distrito').attr("disabled",state);
$('#provincia').attr("disabled",state);
$('#clave').attr("disabled",state);
$('#tipo').attr("disabled",state);

$('#btnMarca').attr("disabled",state);
$('#btnCategoria').attr("disabled",state);
$('#btnColor').attr("disabled",state);
$('#btnTalla').attr("disabled",state);
$('#btnUnidad').attr("disabled",state);
$('#btnModelo').attr("disabled",state);
};			   
						   
						   jQuery.fn.Limpiar=function()
{
$('#nombres').val("");
$('#apellidos').val("");
$('#direccion').val("");
$('#telefono').val("");
$('#celular').val("");
$('#email').val("");
$('#sexo1').attr("checked",true);
$('#dni').val("");
$('#clave').val("");
$('#tipo').val("1");
};
jQuery.fn.ControlBotones=function(state1,state2,state3,state4,state5,state6)
{
$('#btnNuevo').attr("disabled",state1);
$('#btnGuardar').attr("disabled",state2);
$('#btnEditar').attr("disabled",state3);
$('#btnCancelar').attr("disabled",state4);
$('#btnEliminar').attr("disabled",state5);
$('#btnSalir').attr("disabled",state6);
};

jQuery.fn.Estado(true);
	jQuery.fn.ControlBotones(false,true,true,true,true,false);
						   
						   
						   
						   	$.post("../../../Vista/Mantenimiento/Personal/cmbdistrito.php",
																				   {
																				   id_provincia:$('#provincia').val()
																				   },
																				   function(data){
																					 
																					   																					   $('#distrito').html(data);
																					 
																					  
																					
																					
																					
																					
																				   });
						   
						   });