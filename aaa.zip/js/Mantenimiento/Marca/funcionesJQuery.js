$(document).ready(function()
 {
oTable=$('#example').dataTable({
					"bJQueryUI": true,
"sScrollY": "39%",
"sPaginationType": "full_numbers"
				});

$('#example tbody tr').live('click',function(event){
											 $(oTable.fnSettings().aoData).each(function (){
            $(this.nTr).removeClass('row_selected');
				            });
            $(event.target.parentNode).addClass('row_selected');
											 
		jQuery.fn.ControlBotones(false,true,false,true,false,false);
		jQuery.fn.Estado(true);
							var celdas=oTable.fnGetData(this);				 
	$('#id_marca').val(celdas[0]);
	$('#txtMarca').val(celdas[1]);
											 });

    
						   $('#btnNuevo').click(function(e){
														 $('#opcion').val(1);
														 jQuery.fn.Estado(false);
											jQuery.fn.Limpiar();
											jQuery.fn.ControlBotones(true,false,true,false,true,true);
														 });
						    $('#btnEditar').click(function(e){
														 $('#opcion').val("2");
														 jQuery.fn.Estado(false);	
											jQuery.fn.ControlBotones(true,false,true,false,true,true);		
														 });
																		$('#btnCancelar').click(function(e){
										    jQuery.fn.Estado(true);	
											jQuery.fn.Limpiar();
											jQuery.fn.ControlBotones(false,true,true,true,true,false);								 });
							 $('#btnEliminar').click(function(e){
														 $('#opcion').val(3);
														  jQuery.fn.Estado(false);
														 });
						   
						   
						   
						   	jQuery.fn.Estado=function(state)
{
$('#txtMarca').attr("disabled",state);
};			   
						   
						   jQuery.fn.Limpiar=function()
{
$('#txtMarca').val("");
};
jQuery.fn.ControlBotones=function(state1,state2,state3,state4,state5,state6)
{
$('#btnNuevo').attr("disabled",state1);
$('#btnGuardar').attr("disabled",state2);
$('#btnEditar').attr("disabled",state3);
$('#btnCancelar').attr("disabled",state4);
$('#btnEliminar').attr("disabled",state5);
};
jQuery.fn.Estado(true);
	jQuery.fn.ControlBotones(false,true,true,true,true,false);

$('#btnEWord').click(function(e){
							  

	var string2=$('#btnEWord').attr("data");
	
	$(location).attr('href','../../../Vista/Mantenimiento/Exportar/Word.php?arrays='+string2);

							  });

$('#btnEExcel').click(function(e){
							  

	var string2=$('#btnEExcel').attr("data");
	
	$(location).attr('href','../../../Vista/Mantenimiento/Exportar/Excel.php?arrays='+string2);

							  });

$('#btnEPdf').click(function(e){
							  

		var string2=$('#btnEPdf').attr("data");
	
	$(location).attr('href','../../../Vista/Mantenimiento/Exportar/Pdf.php?arrays='+string2);

							  });

			
		});

