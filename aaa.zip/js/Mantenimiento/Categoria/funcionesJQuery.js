$(document).ready(function()
 {
oTable=$('#example').dataTable({
					"bJQueryUI": true,
					'bPaginate': true,
					'bLengthChange':false, /*Sirve para mostrar al lado superior izquierdo la opcion Show 10 entries*/
//"sScrollY": "39%",
"sPaginationType": "full_numbers",
'iDisplayLength': 10 /*Para cambiar el tama�o de paginacion*/
				});

$('#example tbody tr').live('click',function(event){
											 $(oTable.fnSettings().aoData).each(function (){
            $(this.nTr).removeClass('row_selected');
				            });
            $(event.target.parentNode).addClass('row_selected');
jQuery.fn.ControlBotones(false,true,false,true,false,false);
jQuery.fn.Estado(true);
		var celdas=oTable.fnGetData(this);
		
		$('#txtCategoria').val(celdas[1]);
		$('#cmbLinea').val(celdas[2]);
		$('#id_categoria').val(celdas[0]);
											 });


jQuery.fn.Estado=function(state)
{
$('#txt_Cateogoria').attr("disabled",state);
$('#cmbLinea').attr("disabled",state);
};			   
						   
/*jQuery.fn.Limpiar=function()
{
$('#txt_Categoria').val("");
$('#cmbLinea').val("0");
};*/
jQuery.fn.ControlBotones=function(state1,state2,state3,state4,state5,state6)
{
$('#btnNuevo').attr("disabled",state1);
$('#btnGuardar').attr("disabled",state2);
$('#btnEditar').attr("disabled",state3);
$('#btnCancelar').attr("disabled",state4);
$('#btnEliminar').attr("disabled",state5);
};
			
		});

