// JavaScript Document
var idCategoria=0;
var operacionABM=1;
function EstadoCajas(estado)
{
document.getElementById("txtCategoria").disabled=estado;
document.getElementById("cmbLinea").disabled=estado;
}
function LimpiarCajas()
{
document.getElementById("txtCategoria").value="";
document.getElementById("cmbLinea").value=0;
resetearcolortabla();
}
function ControlBotones(estado,estado2,estado3,estado4,estado5,estado6)
{
document.getElementById("btnNuevo").disabled=estado;
document.getElementById("btnGuardar").disabled=estado2;
document.getElementById("btnEditar").disabled=estado3;
document.getElementById("btnCancelar").disabled=estado4;
document.getElementById("btnEliminar").disabled=estado5;
}
function TransaccionNormal(opcion)
{
nombre_Categoria=document.getElementById('txtCategoria').value;
idLinea=document.getElementById('cmbLinea').value;
location.href="Mantenimiento/Categoria/CDCategoria.php?opcion="+opcion+"&id_categoria="+idCategoria+"&nombre_categoria="+nombre_Categoria+"&id_linea="+idLinea;
}
function validarTransaccion(respuesta2)
{
if(respuesta2=="1")
{
window.parent.jAlert('Operacion Exitosa!', 'Dialogo Alert');
}
else if(respuesta2=="0")
 {
 window.parent.jAlert('Operacion Fallida!', 'Dialogo Alert');
 }
 else
 {
 window.parent.jAlert('Ocurrio un Error!', 'Dialogo Alert');
 }
}
function body_onLoad()
{
/*LlenarTabla();*/
ControlEventos(0);
}
function ControlEventos(operacion)
{
switch(operacion)
{
case 0 :
EstadoCajas(true);
ControlBotones(false,true,true,true,true,false);
break;
case 1 :
LimpiarCajas();
                EstadoCajas(false);
              ControlBotones(true,false,true,false,true,true);

break;
case 2 :
 if(operacionABM==1)
                {
window.parent.jConfirm('Esta seguro de agregar un nuevo Registro?', 'Confirmation Dialog', function(r) {
if(r)
{
/*Transaccion(1);*/
TransaccionNormal(1);
}
else
{
window.parent.jAlert('Se Cancelo la Operacion!', 'Dialogo Alert');
}
	});
				}
				else
				{
				window.parent.jConfirm('Estado seguro de modificar el Registro ?', 'Confirmation Dialog', function(r) {
				if(r)
				{
				/*Transaccion(2);*/
				TransaccionNormal(2);
}
				else
				{
				window.parent.jAlert('Se Cancelo la Operacion!', 'Dialogo Alert');
				}
				
			 });
				}


break;
case 3 :
EstadoCajas(false);
ControlBotones(true,false,true,false,true,true);
break;
case 4 :
EstadoCajas(true);
                ControlBotones(false,true,true,true,true,false);
                LimpiarCajas();

break;
case 5 :
	window.parent.jConfirm('Estado seguro de eliminar el Registro ?', 'Confirmation Dialog', function(r) {
	if(r)
				{
				/*Transaccion(3);*/
				TransaccionNormal(3);
}
				else
				{
				window.parent.jAlert('Se Cancelo la Operacion!', 'Dialogo Alert');
				}
			
});
break;
}
}
function btnNuevo_onClick()
{
//operacionABM=1;
document.getElementById("opcion").value=1;
ControlEventos(1);
}
function btnGuardar_onClick()
{
//ControlEventos(2);
}
function btnEditar_onClick()
{
//operacionABM=2;
document.getElementById("opcion").value=2;
ControlEventos(3);
}
function btnCancelar_onClick()
{
ControlEventos(4);
}
function btnEliminar_onClick()
{
	EstadoCajas(false);
document.getElementById("opcion").value=3;
//ControlEventos(5);
}


