$(document).ready(function(){
						   $('#btnaddCategoria').click(function(e){
																 if($('#nombre').val()!="")
														 {
														var nombre=$('#nombre').val();	
														var id_linea=$('#linea').val();
														 $.get("p_addCategoria.php",{
															   nombre_categoria:nombre,
															   linea:id_linea
															   },function(data){
																			  if(data=="1")
																			  {
																			  $.get("cmbCategoria.php",{
																							nombre2:nombre														},function(data){
																						window.parent.$('#categoria').html(data);
																																										});
																			  

																			  }
																			  else
																			  {
																			  jAlert('Operacion Fallida', 'Dialogo Alert');
																			  }
																			  																			  });
window.parent.$('#modelo').html("");
				
			window.parent.iframeMCategoria.dialog("close");
		
														 $('#nombre').val("");
														 }
														 else
														 {
														  jAlert('Faltan llenar campos', 'Dialogo Alert');
														
														 }
																});
						   });