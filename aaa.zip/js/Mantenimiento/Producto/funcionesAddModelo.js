$(document).ready(function(){
						   $('#btnaddModelo').click(function(e){
														if($('#nombre_modelo').val()!="")
														 {
														var nombre=$('#nombre_modelo').val();	
														var id_categoria2=$('#categoria').val();
														 $.get("p_addModelo.php",{
															   nombre_modelo:nombre,
															   id_categoria:id_categoria2
															   },function(data){
																			  if(data=="1")
																			  {
																			  $.get("cmbModelo.php",{
																					    id_categoria:id_categoria2,
																						nombre_modelo:nombre														},function(data){
																						window.parent.$('#modelo').html(data);
																																										});
																			  

																			  }
																			  else
																			  {
																			  jAlert('Operacion Fallida', 'Dialogo Alert');
																			  }
																			  																			  });
				
			window.parent.iframeMModelo.dialog("close");
		
														 $('#nombre').val("");
														 }
														 else
														 {
														  jAlert('Faltan llenar campos', 'Dialogo Alert');
														
														 }
																});
						   });