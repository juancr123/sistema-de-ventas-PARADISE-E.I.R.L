$(document).ready(function(){
						   $('#btnaddColor').click(function(e){
														if($('#nombre_color').val()!="")
														 {
														var nombre=$('#nombre_color').val();	
														
														 $.get("p_addColor.php",{
															   nombre_color:nombre,
															  
															   },function(data){
																			  if(data=="1")
																			  {
																			  $.get("cmbColor.php",{
																					    
																						nombre_color:nombre														},function(data){
																						window.parent.$('#color').html(data);
																																										});
																			  

																			  }
																			  else
																			  {
																			  jAlert('Operacion Fallida', 'Dialogo Alert');
																			  }
																			  																			  });
				
			window.parent.iframeMColor.dialog("close");
		
														 $('#nombre_color').val("");
														 }
														 else
														 {
														  jAlert('Faltan llenar campos', 'Dialogo Alert');
														
														 }
																});
						   });