var id_producto=0;
var operacionABM=1;
var ruta;
var modelo;
var iframeMMarca;
var iframeMCategoria;
var iframeMModelo;
var iframeMColor;
var iframeMTalla;
var urlMantenimientoCategoria="../../../Mantenimiento/Categoria/MantenimientoCategoria.php";
var iframeMantenimientoCategoria=$('<iframe src="'+ urlMantenimientoCategoria +'" />');

var urlMantenimientoColor="../../../Mantenimiento/Color/MantenimientoColor.php";
var iframeMantenimientoColor=$('<iframe src="'+ urlMantenimientoColor +'" />');

var urlMantenimientoModelo="../../../Mantenimiento/Modelo/MantenimientoModelo.php";
var iframeMantenimientoModelo=$('<iframe src="'+ urlMantenimientoModelo +'" />');

var urlMantenimientoTalla="../../../Mantenimiento/Talla/MantenimientoTalla.php";
var iframeMantenimientoTalla=$('<iframe src="'+ urlMantenimientoTalla +'" />');
$(document).ready(function(){
oTable=$('#productos').dataTable({
					"bJQueryUI": true,
					'bPaginate': true,
					'bLengthChange':false, /*Sirve para mostrar al lado superior izquierdo la opcion Show 10 entries*/
			
					 "sPaginationType": "full_numbers",
					 
					'iDisplayLength': 5
								 });
/*para pintar seleccion*/
/*$('#productos tbody').click(function(event)
									 {
				 
				$(oTable.fnSettings().aoData).each(function (){
                $(this.nTr).removeClass('row_selected');
				            });
            $(event.target.parentNode).addClass('row_selected');
												 });*/
/*para obtener datos de seleccion y ala vez pintar seleccion*/
$('#productos tbody tr').live('click',function(event){
			$(oTable.fnSettings().aoData).each(function (){
            $(this.nTr).removeClass('row_selected');
				            });
            $(event.target.parentNode).addClass('row_selected');
			
jQuery.fn.ControlBotones(false,true,false,true,false,false);
jQuery.fn.Estado(true);
var celdas=oTable.fnGetData(this);
		
				
		$('#modelo').attr("disabled",true);
		$('#talla').attr("disabled",true);
	id_producto=celdas[0];
			$('#id_producto').val(id_producto);
              
			  ruta=String(celdas[9]).split(" ")[1].split("=")[1];
			 
			 var id_marca=$("#marca option:contains('"+celdas[2]+"')").val();
			 modelo=celdas[3];
			 var id_categoria=$("#categoria option:contains('"+celdas[1]+"')").val();
			 var id_color=$("#color option:contains('"+celdas[4]+"')").val();
			 var id_talla=$("#talla option:contains('"+celdas[5]+"')").val();
			 var id_unidad=$("#unidad option:contains('"+celdas[6]+"')").val(); 
			  $('#marca').val(id_marca);
			  $('#categoria').val(id_categoria);
			  $('#color').val(id_color);
			  $('#talla').val(id_talla);
			  $('#unidad').val(id_unidad);
			  $('#precio_venta').val(celdas[7]);
			  $('#stock').val(celdas[8]);
			  $.get("../../../Vista/Mantenimiento/Producto/cmbModelo.php",
																				   {id_categoria:$('#categoria').val(),
																				   nombre_modelo:""},
																				   function(data){
																					   $('#modelo').html(data);
																				   });
			  
			  $.get("../../../Vista/Mantenimiento/Producto/cmbTalla.php",
																				   {id_categoria:$('#categoria').val(),
																				   nombre_talla:""},
																				   function(data){
																					   $('#talla').html(data);
																				   });
											   
											   });

jQuery.fn.VistaPrevia=function()
{
var urlfoto_grande="../../../Vista/Mantenimiento/Producto/foto_grande.php?url_foto="+ruta.split('"')[1];
var iframeFoto_Grande=$('<iframe src="'+urlfoto_grande+'" />');
			iframeFoto_Grande.dialog({
							autoOpen:true,
							modal:true,
						    title: "Vista Previa",
 width : 400,
 height :300,
 position : 'top',
resizable : false,


						
                           close:function(event,ui)
            {
                          
						  
						  }
 
       }).width(380).height(240);
}    
	
$('#btnMarca').click(function(event){
var urlMantenimientoMarca="../../../Vista/Mantenimiento/Producto/addMarca.php";
iframeMMarca=$('<iframe src="'+ urlMantenimientoMarca +'" />');	
iframeMMarca.dialog({
							autoOpen:true,
							modal:true,
						    title: "Agregar Marca",
 width : 280,
 height : 100,
 position : 'top',
resizable : true,


						
                           close:function(event,ui)
            {
                          }
 
       }).width(260).height(80);
											  });


				
		
									 
				$('#btnCategoria').click(function(event){
var url="../../../Vista/Mantenimiento/Producto/addCategoria.php";
iframeMCategoria=$('<iframe src="'+ url +'" />');	
iframeMCategoria.dialog({
							autoOpen:true,
							modal:true,
						    title: "Mantenimiento Categoria",
 width : 350,
 height : 120,
 position : 'top',
resizable : false,


						
                           close:function(event,ui)
            {
                          }
 
       }).width(330).height(100);
												  
												  });
				
				$('#btnModelo').click(function(event){
var url="../../../Vista/Mantenimiento/Producto/addModelo.php?id_categoria="+$('#categoria').val();
iframeMModelo=$('<iframe src="'+ url +'" />');	
iframeMModelo.dialog({
							autoOpen:true,
							modal:true,
						    title: "Mantenimiento Modelo",
 width : 350,
 height : 120,
 position : 'top',
resizable : true,


						
                           close:function(event,ui)
            {
                          }
 
       }).width(330).height(100);
												  
												  });
$('#btnColor').click(function(event){
var url="../../../Vista/Mantenimiento/Producto/addColor.php";
iframeMColor=$('<iframe src="'+ url +'" />');	
										  
iframeMColor.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Mantenimiento Color",
 width : 280,
 height : 120,
 position : 'top',
resizable : false,


						
                           close:function(event,ui)
            {
                          }
 
       }).width(260).height(100);
											  });
				$('#btnTalla').click(function(event){
var url="../../../Vista/Mantenimiento/Producto/addTalla.php?id_categoria="+$('#categoria').val();
iframeMTalla=$('<iframe src="'+ url +'" />');												
iframeMTalla.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Mantenimiento Talla",
 width : 350,
 height : 120,
 position : 'top',
resizable : false,

close:function(event,ui)
            {
                          }
 
       }).width(330).height(100);  
											  
											  });
											
	 $('#categoria').change(function(e){
									 if($('#categoria').val()!=0)
									 {
									 $('#modelo').attr("disabled",false);
									 $('#talla').attr("disabled",false);
									 $('#btnTalla').attr("disabled",false);
									 $('#btnModelo').attr("disabled",false);
									 }
									 else
									 {
									 $('#modelo').attr("disabled",true);
									 $('#talla').attr("disabled",true);
									 }
	$.get("../../../Vista/Mantenimiento/Producto/cmbModelo.php",
																				   {id_categoria:$('#categoria').val(),
																				   nombre_modelo:""},
																				   function(data){
																					   $('#modelo').html(data);
																				   });
	
		$.get("../../../Vista/Mantenimiento/Producto/cmbTalla.php",
																				   {id_categoria:$('#categoria').val(),
																				   nombre_talla:""},
																				   function(data){
																					   $('#talla').html(data);
																				   });
																			
																			});
											$('#imagen').change(function(e){
								var valor=$('#imagen').val();
								valor=valor.split(".");	
								if(jQuery.fn.ValidarFoto(valor[1]))
															{
															//alert("archivo no valido");
															jAlert('Archivo no valido!', 'Dialogo Alert');
															$('#imagen').val("");
															}
													 });
											
											$('#btnNuevo').click(function(e){
											
											operacionABM=1;
											$('#opcion').val("1");
											jQuery.fn.Estado(false);
											jQuery.fn.Limpiar();
											jQuery.fn.ControlBotones(true,false,true,false,true,true);
																		  });
																					
											$('#btnEditar').click(function(e){
											//$('#modificar_imagen').val(1);
										    //operacionABM=2;
											$('#opcion').val("2");
											jQuery.fn.Estado(false);
											$('#modelo').attr("disabled",false);
											$('#talla').attr("disabled",false);
											$('#modelo').val($("#modelo option:contains('"+modelo+"')").val());
											jQuery.fn.ControlBotones(true,false,true,false,true,true);							   
																		   });
											$('#btnCancelar').click(function(e){
											//$('#modificar_imagen').val(0);
											jQuery.fn.ResetearColorTabla("productos");
										    jQuery.fn.Estado(true);	
											jQuery.fn.Limpiar();
											jQuery.fn.ControlBotones(false,true,true,true,true,false);								 });
											$('#btnEliminar').click(function(e){
											//$('#modificar_imagen').val(1);
											jQuery.fn.Estado(false);
											$('#modelo').attr("disabled",false);
											$('#talla').attr("disabled",false);
											$('#opcion').val("3");
											
										    });
											$('#btnSalir').click(function(e){
																			 
																			 });
											
jQuery.fn.ValidarFoto=function(url)
{
if(url.toUpperCase()=='JPEG' || url.toUpperCase()=='JPG' || url.toUpperCase()=='GIF' || url.toUpperCase()=='PNG')
{
return false;
}
else
{
return true;
}
};																   
	
jQuery.fn.Estado=function(state)
{
$('#nombre').attr("disabled",state);
$('#marca').attr("disabled",state);
$('#categoria').attr("disabled",state);
//$('#modelo').attr("disabled",state);
$('#color').attr("disabled",state);
//$('#talla').attr("disabled",state);
$('#unidad').attr("disabled",state);
$('#precio_venta').attr("disabled",state);
$('#stock').attr("disabled",state);
$('#imagen').attr("disabled",state);

$('#btnMarca').attr("disabled",state);
$('#btnCategoria').attr("disabled",state);
$('#btnColor').attr("disabled",state);
$('#btnTalla').attr("disabled",state);
$('#btnUnidad').attr("disabled",state);
$('#btnModelo').attr("disabled",state);
};

jQuery.fn.Limpiar=function()
{
        $('#nombre').val("");
		$('#marca').val("");
		$('#categoria').val("");
		$('#modelo').val("");
		$('#color').val("");
		$('#talla').val("");
		$('#unidad').val("");
		$('#precio_venta').val("");
		$('#stock').val("");
		$('#imagen').val("");
};
jQuery.fn.ControlBotones=function(state1,state2,state3,state4,state5,state6)
{
$('#btnNuevo').attr("disabled",state1);
$('#btnGuardar').attr("disabled",state2);
$('#btnEditar').attr("disabled",state3);
$('#btnCancelar').attr("disabled",state4);
$('#btnEliminar').attr("disabled",state5);
$('#btnSalir').attr("disabled",state6);
};
	jQuery.fn.Estado(true);
	jQuery.fn.ControlBotones(false,true,true,true,true,false);
	
	$('#btnEWord').click(function(e){
							  

	var string2=$('#btnEWord').attr("data");
	
	$(location).attr('href','../../../Vista/Mantenimiento/Exportar/Word.php?arrays='+string2);

							  });

$('#btnEExcel').click(function(e){
							  

	var string2=$('#btnEExcel').attr("data");
	
	$(location).attr('href','../../../Vista/Mantenimiento/Exportar/Excel.php?arrays='+string2);

							  });

$('#btnEPdf').click(function(e){
							  

		var string2=$('#btnEPdf').attr("data");
	
	$(location).attr('href','../../../Vista/Mantenimiento/Exportar/Pdf.php?arrays='+string2);

							  });
});
				 

