$(document).ready(function(){
						   $('#btnaddMarca').click(function(e){
														 if($('#nombre').val()!="")
														 {
														var nombre=$('#nombre').val();	 
														 $.get("p_addMarca.php",{
															   nombre_marca:nombre
															   },function(data){
																			  if(data=="1")
																			  {
																			  $.get("cmbMarca.php",{
																							nombre2:nombre														},function(data){
																						window.parent.$('#marca').html(data);
																																										});
																			  

																			  }
																			  else
																			  {
																			  jAlert('Operacion Fallida', 'Dialogo Alert');
																			  }
																			  																			  });
				
			window.parent.iframeMMarca.dialog("close");
		
														 $('#nombre').val("");
														 }
														 else
														 {
														  jAlert('Escribe un nombre', 'Dialogo Alert');
														
														 }
														 														 
						   });
						   });