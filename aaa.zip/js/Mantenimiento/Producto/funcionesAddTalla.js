$(document).ready(function(){
						   $('#btnaddTalla').click(function(e){
														if($('#nombre_talla').val()!="")
														 {
														var nombre=$('#nombre_talla').val();	
														var id_categoria2=$('#categoria').val();
														 $.get("p_addTalla.php",{
															   nombre_talla:nombre,
															   id_categoria:id_categoria2
															   },function(data){
																			  if(data=="1")
																			  {
																			  $.get("cmbTalla.php",{
																					    id_categoria:id_categoria2,
																						nombre_talla:nombre														},function(data){
																						window.parent.$('#talla').html(data);
																																										});
																			  

																			  }
																			  else
																			  {
																			  jAlert('Operacion Fallida', 'Dialogo Alert');
																			  }
																			  																			  });
				
			window.parent.iframeMTalla.dialog("close");
		
														 $('#nombre_talla').val("");
														 }
														 else
														 {
														  jAlert('Faltan llenar campos', 'Dialogo Alert');
														
														 }
																});
						   });