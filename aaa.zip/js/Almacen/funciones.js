var $=jQuery.noConflict();
$.fx.speeds._default = 1000;
var iframetb_Compras;
var id_compra;
var id_detalle_compra;
var iframetb_ProductoProveedor;

var id_producto;
var precio_compra;
var descripcion;

var aid_PRODUCTO=new Array();;
var acantidad=new Array();
var acosto=new Array();
var tabla;

var iframeProveedores
$(document).ready(function()
 {
	 
	 $("#fecha").datepicker({
	 dateFormat: 'yy-mm-dd'
	}
	);
oTableAlmacen=$('#almacen').dataTable({
					"bJQueryUI": true,
					'bPaginate': false,
					"sScrollY": "39%",
					'bLengthChange':false,
					'bFilter': false, /*para realizar busqueda de datos */
					/*Sirve para mostrar al lado superior izquierdo la opcion Show 10 entries*/
//"sScrollY": "39%",
"sPaginationType": "full_numbers",
'iDisplayLength': 5 /*Para cambiar el tama�o de paginacion*/
				});

$('#productos_proveedor').dataTable({
					"bJQueryUI": true,
					'bPaginate': true,
					'bLengthChange':false,

"sPaginationType": "full_numbers",
'iDisplayLength': 5 
				});

$("#almacen tbody").click(function(event) {
			jQuery(oTableAlmacen.fnSettings().aoData).each(function() {
			jQuery(this.nTr).removeClass("row_selected");

			
			});

            jQuery(event.target.parentNode).addClass("row_selected");
													  });

oTableCompras=$('#tb_compras').dataTable({
					"bJQueryUI": true,
					'bPaginate': true,
					'bLengthChange':false, /*Sirve para mostrar al lado superior izquierdo la opcion Show 10 entries*/
//"sScrollY": "39%",
"sPaginationType": "full_numbers",
'iDisplayLength': 5 /*Para cambiar el tama�o de paginacion*/
				});

 $('#btnBuscarProveedor').click(function(e){
var urlTablaProveedores="CCtablaproveedores.php";
iframeProveedores=$('<iframe src="'+ urlTablaProveedores +'" />');
											 iframeProveedores.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Lista de Proveedores",
 width : 780,
 height : 300,
 bgiframe:true,
 position : 'top',
resizable : false,
							autoResize: true,
                           close:function(event,ui)
            {
                          }
 
       }).width(780).height(330);						
									
});	
$('#btnBuscarOC').click(function(e){
var urlTablaCompras="CCtablacompras.php";
iframetb_Compras=$('<iframe src="'+ urlTablaCompras +'" />');
											 iframetb_Compras.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Lista de Ordenes de Compra",
 width : 850,
 height : 450,
 bgiframe:true,
 position : 'top',
resizable : false,
							autoResize: true,
                           close:function(event,ui)
            {
                          }
 
       }).width(820).height(430);						
									
});	

$('#mas').click(function(e){
var urlTablaProveedorProducto="CCtablaproductoproveedor.php?id_proveedor="+$('#id_proveedor').val();
iframetb_ProductoProveedor=$('<iframe src="'+ urlTablaProveedorProducto +'" />');
											 iframetb_ProductoProveedor.dialog({
                            autoOpen:true,
                            modal:true,
							title: "Lista de Productos ",
 width : 850,
 height : 350,
 bgiframe:true,
 position : 'top',
resizable : false,
							autoResize: true,
                           close:function(event,ui)
            {
                          }
 
       }).width(820).height(330);						
									
});	

$('#addProducto').click(function(e){
								 if(id_producto!=undefined)
								 {
	if(document.getElementById("cantidad").value=="")
	{
		jAlert('INGRESA UNA CANTIDAD','Atencion!');
	}
	else
	{
	var cantidad=document.getElementById("cantidad").value
	var costo=precio_compra*cantidad;
	var fila_repetido=jQuery.fn.ProductoRepetido(id_producto);
	
	if(fila_repetido!=-1)
									{

window.parent.$('#almacen').dataTable().fnUpdate(String(parseInt(window.parent.$('#almacen').dataTable().fnGetData(fila_repetido)[3])+parseInt(cantidad)),fila_repetido,3);
							
window.parent.$('#almacen').dataTable().fnUpdate(String(parseFloat(window.parent.$('#almacen').dataTable().fnGetData(fila_repetido)[4])+parseFloat(costo)),fila_repetido,4);
								
									}
									else
									{
										
window.parent.$('#almacen').dataTable().fnAddData([id_producto,descripcion,String(precio_compra),String(cantidad),String(costo)]);

									}
								
window.parent.$('#subtotal').val(jQuery.fn.CalcularSubtotal(1));
window.parent.$('#igv').val(jQuery.fn.CalcularIGV(1));
window.parent.$('#total').val(jQuery.fn.CalcularTotal(1));
window.parent.iframetb_ProductoProveedor.dialog("close");
}	
								 }
								 else
								 {
								jAlert('SELECCIONA UN PRODUCTO','Atencion!');
								 }
									
});	

$('#menos').click(function(e){

						   					   
				var anSelected = jQuery.fn.fnGetSelected(oTableAlmacen);
				if(anSelected[0]!=null)
			    {
					oTableAlmacen.fnDeleteRow( anSelected[0] );

				}
				else {
				alert("SELECCIONA UNA FILA");
				}
				$('#subtotal').val(jQuery.fn.CalcularSubtotal(2));
				$('#igv').val(jQuery.fn.CalcularIGV(2));
                $('#total').val(jQuery.fn.CalcularTotal(2));
						   });

$('#btnGuardar').click(function(e){
								if($(this).val()!="NUEVO")
								{
								var opcion=$('#opcion').val();
								var estado2;
								var id_compra2;
								if(jQuery.fn.ValidarFormulario(opcion))
								{
								if(opcion==2||opcion==3)
								{
							    id_compra2=$('#id_compra').val();
								}
								else
								{
								id_compra2="1";
								}
															
								if(document.getElementById('estado').checked)
								{
								estado2=1;
								}
								else
								{
								estado2=0;
								}
								
								jQuery.fn.LlenarArreglos();
									 var  id_compra=id_compra2;
									   var id_proveedor=$('#id_proveedor').val();
									   var fecha_compra=$('#fecha').val();
									   var estado=estado2;
									   var subtotal=$('#subtotal').val();
									   var igv=$('#igv').val();
									   var total=$('#total').val();
									   var arregloProducto=aid_PRODUCTO;
									   var arregloCantidad=acantidad;
									   var arregloCosto=acosto;
								$(location).attr('href','p_compra.php?opcion='+opcion+'&id_compra='+id_compra+'&id_proveedor='+id_proveedor+'&fecha_compra='+fecha_compra+'&estado='+estado2+'&subtotal='+subtotal+'&igv='+igv+'&total='+total+'&arregloProducto='+arregloProducto+'&arregloCantidad='+arregloCantidad+'&arregloCosto='+arregloCosto);
								$(this).val("NUEVO");
								}
								}
								else
								{
							    jQuery.fn.Estado(false);
								$(this).val("GUARDAR");
								}
					
									
});	

jQuery.fn.Pulsar=function(obj,e)
{
jQuery.fn.ResetearColorTabla("productos_proveedor");
obj.style.backgroundColor = '#E2E4FF';
if(!e)e=window.event;
if(!e.target) e.target=e.srcElement;
// e.target ahora simboliza la celda en la que hemos hecho click
// subimos de nivel hasta encontrar un tr
var TR=e.target;
if(!(TR.nodeName=="INPUT"))
{
while( TR.nodeType==1 && TR.tagName.toUpperCase()!="TR" )
TR=TR.parentNode;
var celdas=TR.getElementsByTagName("TD");
// cogemos la primera celda TD del tr (si existe)
if( celdas.length!=0 )
    {
	id_producto=celdas[0].innerHTML;
	descripcion=celdas[1].innerHTML+" "+celdas[2].innerHTML+" "+celdas[3].innerHTML+" "+celdas[4].innerHTML+" "+celdas[5].innerHTML;
	precio_compra=celdas[7].innerHTML;
}
}
};

jQuery.fn.fnGetSelected=function( oTableLocal )
			{
				var aReturn = new Array();
				var aTrs = oTableLocal.fnGetNodes();
				for ( var i=0 ; i<aTrs.length ; i++ )
				{
					if ( $(aTrs[i]).hasClass('row_selected') )
					{
						aReturn.push( aTrs[i] );
					}
				}
				return aReturn;
			};


jQuery.fn.LlenarArreglos=function(opcion)
{
$.each( oTableAlmacen.fnGetData(), function(i, row){				
aid_PRODUCTO[i]=row[0];
acantidad[i]=parseInt(row[3]);
acosto[i]=parseFloat(row[4]);
});

}
jQuery.fn.CalcularSubtotal=function(opcion)
{
var oTableAlmacen2;
if(opcion==1)
{
oTableAlmacen2=window.parent.$("#almacen").dataTable();
}
else
{
oTableAlmacen2=$("#almacen").dataTable();
}
var subtotal=0.00;
$.each( oTableAlmacen2.fnGetData(), function(i, row){
								subtotal+=parseFloat(row[4]);	   
									   
									   });


return subtotal;
};

jQuery.fn.CalcularIGV=function(opcion)
{
var igv=0.18*jQuery.fn.CalcularSubtotal(opcion);
return igv;
}
jQuery.fn.CalcularTotal=function(opcion)
{
	var subtotal;
	var igv;
if(opcion==1)
{
subtotal=parseFloat(window.parent.document.getElementById("subtotal").value);
igv=parseFloat(window.parent.document.getElementById("igv").value);
}
else
{
subtotal=parseFloat(document.getElementById("subtotal").value);
igv=parseFloat(document.getElementById("igv").value);
}
var total=subtotal+igv;
return total;
}
jQuery.fn.ResetearColorTabla=function(tabla)
{
var tabla2 = document.getElementById(tabla);
for (var i=1; i<tabla2.rows.length; i++)
{
tabla2.rows[i].style.backgroundColor='white';
}
};
jQuery.fn.ProductoRepetido=function(idproducto)
{
	var fila=-1;
	var oTable2=window.parent.$('#almacen').dataTable();
	$.each(oTable2.fnGetData(), function(i, row){
								if(idproducto==row[0])
								{
								fila=i;
								
								}
								
									   });

	
return fila;
};
jQuery.fn.EstadoBotones=function(state)
{
$('#mas').attr("disabled",state);
$('#menos').attr("disabled",state);
};
jQuery.fn.Estado=function(state)
{
$('#id_proveedor').attr("disabled",state);
$('#RS').attr("disabled",state);
$('#Nombres').attr("disabled",state);
$('#ruc').attr("disabled",state);
$('#telefono').attr("disabled",state);
$('#fecha').attr("disabled",state);
$('#estado').attr("disabled",state);
$('#btnNuevoProveedor').attr("disabled",state);
$('#btnBuscarProveedor').attr("disabled",state);
}
jQuery.fn.ValidarFormulario=function(opcion)
{
if(opcion==1)
{
if($('#id_proveedor').val()=="")
{
alert("Falta seleccionar el Proveedor!");
return false;
}
if($('#fecha').val()=="")
{
alert("falta el campo Fecha!");
return false;
}
if(oTableAlmacen.fnGetData().length<1)
{
alert("Falta a�adir productos!");
return false;
}
}
else
{
if($('#id_compra').val()=="")
{
alert("Selecciona una Orden de Compra");
return false;
}
else
{
if($('#fecha').val()=="")
{
alert("falta el campo Fecha!");
return false;
}
if(oTableAlmacen.fnGetData().length<1)
{
alert("Falta a�adir productos!");
return false;
}
}
}
return true;
}
});