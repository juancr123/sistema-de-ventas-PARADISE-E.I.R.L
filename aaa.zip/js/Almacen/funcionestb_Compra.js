var id_compra;
$(document).ready(function()
						   {
oTableCompras=$('#tb_compras').dataTable({
					"bJQueryUI": true,
					'bPaginate': true,
					'bLengthChange':false, /*Sirve para mostrar al lado superior izquierdo la opcion Show 10 entries*/
//"sScrollY": "39%",
"sPaginationType": "full_numbers",
'iDisplayLength': 5 /*Para cambiar el tama�o de paginacion*/
				});

$('#btnAgregarCompra').click(function(e){
window.parent.iframetb_Compras.dialog("close");
window.parent.location.href="CCOC.php?opcionFormulario="+window.parent.$('#opcion').val()+"&id_compra="+id_compra;								
});	

jQuery.fn.Pulsar=function(obj,e)
{
jQuery.fn.ResetearColorTabla("tb_compras");
obj.style.backgroundColor = '#E2E4FF';
if(!e)e=window.event;
if(!e.target) e.target=e.srcElement;
// e.target ahora simboliza la celda en la que hemos hecho click
// subimos de nivel hasta encontrar un tr
var TR=e.target;
if(!(TR.nodeName=="INPUT"))
{
while( TR.nodeType==1 && TR.tagName.toUpperCase()!="TR" )
TR=TR.parentNode;
var celdas=TR.getElementsByTagName("TD");
// cogemos la primera celda TD del tr (si existe)
if( celdas.length!=0 )
    {
	id_compra=celdas[0].innerHTML;

}
}
};

jQuery.fn.ResetearColorTabla=function(tabla)
{
var tabla2 = document.getElementById(tabla);
for (var i=1; i<tabla2.rows.length; i++)
{
tabla2.rows[i].style.backgroundColor='white';
}
};
						   });