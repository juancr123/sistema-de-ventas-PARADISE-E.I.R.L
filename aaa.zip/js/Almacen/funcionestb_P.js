var codigo;
var razon_social;
var nombres;
var ruc;
var telefono;
$(document).ready(function()
 {
		 $('#proveedores').dataTable({
					"bJQueryUI": true,
					'bPaginate': true,
					'bLengthChange':false, /*Sirve para mostrar al lado superior izquierdo la opcion Show 10 entries*/
//"sScrollY": "39%",
"sPaginationType": "full_numbers",
'iDisplayLength': 5 /*Para cambiar el tama�o de paginacion*/
				});
	 
	 $('#btnAgregarProveedor').click(function(e){
											
											  window.parent.$('#id_proveedor').val(codigo);
											  window.parent.$('#RS').val(razon_social);
											  window.parent.$('#Nombres').val(nombres);
											  window.parent.$('#ruc').val(ruc);
											  window.parent.$('#telefono').val(telefono);
											  window.parent.iframeProveedores.dialog("close");
											  window.parent.$('#mas').attr("disabled",false);
window.parent.$('#menos').attr("disabled",false);
											  });
	  jQuery.fn.Pulsar=function(obj,e)
{
jQuery.fn.ResetearColorTabla("proveedores");
obj.style.backgroundColor = '#E2E4FF';
if(!e)e=window.event;
if(!e.target) e.target=e.srcElement;
// e.target ahora simboliza la celda en la que hemos hecho click
// subimos de nivel hasta encontrar un tr
var TR=e.target;
if(!(TR.nodeName=="INPUT"))
{
while( TR.nodeType==1 && TR.tagName.toUpperCase()!="TR" )
TR=TR.parentNode;
var celdas=TR.getElementsByTagName("TD");
// cogemos la primera celda TD del tr (si existe)
if( celdas.length!=0 )
    {
	codigo=celdas[0].innerHTML;
razon_social=celdas[2].innerHTML;
nombres=celdas[3].innerHTML+" "+celdas[4].innerHTML;
ruc=celdas[1].innerHTML;
telefono=celdas[5].innerHTML;
}
}
};
jQuery.fn.ResetearColorTabla=function(tabla)
{
var tabla2 = document.getElementById(tabla);
for (var i=1; i<tabla2.rows.length; i++)
{
tabla2.rows[i].style.backgroundColor='white';
}
};

	 
 });