$(document).ready(function(){
						   $('#clave').bind('keypress',function(e)
																{
																	if(e.keyCode=='13')
																	{
																	var usuario2=document.getElementById("usuario").value;
						var clave2=document.getElementById("clave").value;
														 $.get("p_acceso.php",{
																 usuario:usuario2,
																 clave:clave2
																 },function(data){
																
							jQuery.fn.validarAcceso(data);
																				});
																	}
																});
						   $('#btn_acceso').click(function(e){
						var usuario2=document.getElementById("usuario").value;
						var clave2=document.getElementById("clave").value;
														 $.get("p_acceso.php",{
																 usuario:usuario2,
																 clave:clave2
																 },function(data){
																
							jQuery.fn.validarAcceso(data);
																				});
														 
														   });
						   
						   jQuery.fn.validarAcceso=function(respuesta2)
						   {
						   if(respuesta2==1)
{
window.parent.jAlert('Bienvenido al Sistema!', 'Dialogo Alert');
window.parent.iframeAcceso.dialog("close");
}
else
{
window.parent.jAlert('Usuario o Clave Incorrecto!', 'Dialogo Alert');
}
						   };
						   });