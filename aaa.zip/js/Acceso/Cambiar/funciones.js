$(document).ready(function(){
						   $('#btnEnviar').click(function(e)
														  {
															 $.get("../../../Vista/Acceso/Cambiar/p_cambiarclave.php",{
																   /*
																   a�adir valores a pasar
																   
																   
																   */
																   
																   
																   
																   },) 
														  });
						   
						   });