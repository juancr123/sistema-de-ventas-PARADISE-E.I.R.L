$(document).ready(function(){
$('#tabs').tabs();   
						 
	jQuery.fn.ObtenerValorRadio=function()
{
    var i
    for (i=0;i<$("input[name='rbProducto']").length;i++)
	{
       if ($("input[name='rbProducto']")[i].checked)
         {
		 return $("input[name='rbProducto']")[i].value;
		 }
	}
	
}
					 					 
						 											 
jQuery.fn.obtenerOpcionReporte=function()
{
if(document.getElementById("chkProducto").checked)
{
var opcion=jQuery.fn.ObtenerValorRadio();
return opcion;
}
else
{
return 1;
}
}
					

jQuery.fn.obtenerOpcion=function()
{
if(document.getElementById("chkMes").checked)
{
return 2;
}
else
{
return 1;
}
}

jQuery.fn.EstadoMes=function()
{
if(document.getElementById("chkMes").checked)
{
document.getElementById("cmbMes").disabled=false;
}
else
{
document.getElementById("cmbMes").disabled=true;
}
}

jQuery.fn.EstadoOpcionProducto=function()
{

if(document.getElementById("chkProducto").checked)
{
for(var i=0;i<$("input[name='rbProducto']").length;i++)
{
$("input[name='rbProducto']")[i].disabled=false;
//$('#rbProducto').attr("disabled",false);
}
}
else
{
for(var i=0;i<$("input[name='rbProducto']").length;i++)
{
	$("input[name='rbProducto']")[i].disabled=true;
	//$('#rbProducto').attr("disabled",true);
}
}
}
$('#btnOk').click(function(event){
													
													
						$.post("grafico1.php",{
														  anio:$('#cmbAnio').val(),
														  mes:$('#cmbMes').val(),
														  opcion:jQuery.fn.obtenerOpcion(),
														  opcionReporte:jQuery.fn.obtenerOpcionReporte()
														  },function(data){
																						   $('#Grafico1').html(data);
																						   //$('#Grafico1').html(data);
																						   });
						
							
													$.post("grafico2.php",
														   {
														  anio:$('#cmbAnio').val(),
														  mes:$('#cmbMes').val(),
														  opcion:jQuery.fn.obtenerOpcion(),
														  opcionReporte:jQuery.fn.obtenerOpcionReporte()
														  },function(data){
																						   $('#Grafico2').html(data);
																						   //$('#Grafico1').html(data);
																						   });
													
													$.post("grafico3.php",
														   {
														  anio:$('#cmbAnio').val(),
														  mes:$('#cmbMes').val(),
														  opcion:jQuery.fn.obtenerOpcion(),
														  opcionReporte:jQuery.fn.obtenerOpcionReporte()
														  },function(data){
																						   $('#Grafico3').html(data);
																						   //$('#Grafico1').html(data);
																						   });
													});
					$('#chkMes').change(function(e){
												 jQuery.fn.EstadoMes();
												 });
					$('#chkProducto').change(function(e){
													  jQuery.fn.EstadoOpcionProducto();
													  });
							$.get("grafico1.php",{
														  anio:$('#cmbAnio').val(),
														  mes:$('#cmbMes').val(),
														  opcion:jQuery.fn.obtenerOpcion(),
														  opcionReporte:jQuery.fn.obtenerOpcionReporte()
														  },function(data){
																						   $('#Grafico1').html(data);
																						   //$('#Grafico1').html(data);
																						   });
						
							
													$.get("grafico2.php",
														   {
														  anio:$('#cmbAnio').val(),
														  mes:$('#cmbMes').val(),
														  opcion:jQuery.fn.obtenerOpcion(),
														  opcionReporte:jQuery.fn.obtenerOpcionReporte()
														  },function(data){
																						   $('#Grafico2').html(data);
																						   //$('#Grafico1').html(data);
																						   });
													
													$.get("grafico3.php",
														   {
														  anio:$('#cmbAnio').val(),
														  mes:$('#cmbMes').val(),
														  opcion:jQuery.fn.obtenerOpcion(),
														  opcionReporte:jQuery.fn.obtenerOpcionReporte()
														  },function(data){
																						   $('#Grafico3').html(data);
																						   //$('#Grafico1').html(data);
																						   });
													
												
						});