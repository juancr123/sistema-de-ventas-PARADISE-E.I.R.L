$(document).ready(function(){
						   
						   $('#btnVer').click(function(e)
													   {
														  var opcion=jQuery.fn.obtenerOpcion();
														  if(opcion==2)
														  {
														  var dato=$('#linea').val();
														  }
														  else if(opcion==3)
														  {
														  var dato=$('#categoria').val();
														  }
														  else
														  {
														  var dato=1;
														  }
														 $(location).attr('href','p_ReporteAlmacen.php?opcion='+opcion+'&dato='+dato);
														  
														  
													   });
						   $('#chkMarca').change(function(e)
														  {
														  if(document.getElementById("chkMarca").checked)
														  {
														  $('#categoria').attr("disabled",false);
														  }
														  else
														  {
														  $('#categoria').attr("disabled",true);
														  }
														  });
						   
						   						   $('#chkCategoria').change(function(e)
														  {
														  if(document.getElementById("chkCategoria").checked)
														  {
														  $('#chkMarca').attr("disabled",false);
														  }
														  else
														  {
														  $('#chkMarca').attr("disabled",true);
														  $('#categoria').attr("disabled",true);
														  document.getElementById("chkMarca").checked=false;
														  }
														  });
												   
												   $('#linea').change(function(e){
																			   $.get("../../../Vista/Reportes/Almacen/cmbCategoria.php",{
																					 id_linea:$('#linea').val()
																					 },function(data){
																						$('#categoria').html(data); 
																					 });
																			   
						   })
						   
						   
						   
						   
jQuery.fn.obtenerOpcion=function()
{
var opcion=1;
if(document.getElementById("chkCategoria").checked)
{
opcion=2;
}
if(document.getElementById("chkMarca").checked)
{
opcion=3;
}
return opcion;
}
						   });