function getXMLHttpRequest(){
	var xmlhttp=false;
	try {
		xmlhttp = new ActiveXObject("Msxml2.XMLHTTP");
	} catch (e) {
		try {
		   xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
		} catch (E) {
			xmlhttp = false;
  		}
	}

	if (!xmlhttp && typeof XMLHttpRequest!='undefined') {
		xmlhttp = new XMLHttpRequest();
	}
	return xmlhttp;
}

function TraerPagina(url,contenedor){
	var divResultado = document.getElementById(contenedor);
	ajax=getXMLHttpRequest();
	ajax.open("GET",url);
	ajax.onreadystatechange=function(){
	if(ajax.readyState==1)
	{
		divResultado.innerHTML='<br/><br/><br/><center><img widht="50" height="50" src="../../images/loading.gif"/><br/>Cargando...</center>'}
		else{
			if(ajax.readyState==4){
				divResultado.innerHTML=ajax.responseText;
				}
			}
			}
	ajax.send(null)
}