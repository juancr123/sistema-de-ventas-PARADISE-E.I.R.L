<?php
require_once '../../../Modelo/conexion.php';
class CMVenta
{
public static function RegistrarVenta($arregloBoleta,$arregloProducto,$arregloCantidad,$arregloCosto)
{
$sql="call SPRINSPedido(".$arregloBoleta[0].",".$arregloBoleta[1].",".$arregloBoleta[2].",".$arregloBoleta[3].",'".$arregloBoleta[4]."','".$arregloBoleta[5]."',".$arregloBoleta[6].",".$arregloBoleta[7].",".$arregloBoleta[8].",".$arregloBoleta[9].")";
$resultBoleta=new query($sql);
if($resultBoleta->n)
{
foreach($resultBoleta->v as $fila)
{
$IdBoleta2=$fila->Idboleta;
}
}
/*$arregloProducto2 = explode(',',$arregloProducto);
$arregloCantidad2 = explode(',',$arregloCantidad);
$arregloCosto2 = explode(',',$arregloCosto);*/
for($i=0;$i<count($arregloProducto);$i++)
{
$resultDetalleBoleta=new query("call SPRINSDetallePedido(".$IdBoleta2.",".$arregloProducto[$i].",".$arregloCantidad[$i].",".$arregloCosto[$i].")");
}
if($resultBoleta->n&&$resultDetalleBoleta==true)
{
return true;
}
else
{
return false;
}
}
public static function SPRCNSVentas($anio,$mes,$opcion)
{
$sql="call SPRCNSVentas('$anio','$mes',$opcion)";
$query=new query($sql);
if($query->n>0)
{
$i=0;
foreach($query->v as $fila)
{
$data[$i]=array('Mes'=>$fila->Mes,'Cantidad'=>$fila->Cantidad);
$i++;
}
}
else
{
$data=null;
}
return $data;
}
public static function SPRCNSVentasxLinea($anio,$mes,$opcion)
{
$sql="call SPRCNSVentasxLinea('$anio','$mes',$opcion)";
$query=new query($sql);
if($query->n>0)
{
$i=0;
foreach($query->v as $fila)
{
$data[$i]=array('Linea'=>$fila->Linea,'Cantidad'=>$fila->Cantidad);
$i++;
}
}
else
{
$data=null;
}
return $data;
}
public static function SPRCNSVentasxCategoria($anio,$mes,$opcion)
{
$sql="call SPRCNSVentasxCategoria('$anio','$mes',$opcion)";
$query=new query($sql);
if($query->n>0)
{
$i=0;
foreach($query->v as $fila)
{
$data[$i]=array('Categoria'=>$fila->Categoria,'Cantidad'=>$fila->Cantidad);
$i++;
}
}
else
{
$data=null;
}
return $data;
}
public static function SPRCNSVentasxMarca($anio,$mes,$opcion)
{
$sql="call SPRCNSVentasxMarca('$anio','$mes',$opcion)";
$query=new query($sql);
if($query->n>0)
{
$i=0;
foreach($query->v as $fila)
{
$data[$i]=array('Marca'=>$fila->Marca,'Cantidad'=>$fila->Cantidad);
$i++;
}
}
else
{
$data=null;
}
return $data;
}
}
?>
