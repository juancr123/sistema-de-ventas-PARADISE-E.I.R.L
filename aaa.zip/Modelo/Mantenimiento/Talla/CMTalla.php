<?php
require_once '../../../Modelo/conexion.php';
class CMTalla
{
public static function SPRCNSTalla($opcion,$dato)
{
$sql="call SPRCNSTalla($opcion,$dato)";
$query=new query($sql);
if($query)
{
$i=0;
foreach($query->v as $fila)
{
$data[$i]=array('ID_TALLA'=>$fila->id_talla,'NOMBRE'=>$fila->nombre,'CATEGORIA'=>$fila->Categoria);
$i++;
}
}
return $data;
}
public static function ABMTalla($opcion,$id_talla,$nombre,$id_categoria)
{
$sql="call SPRABMTalla($opcion,$id_talla,'$nombre',$id_categoria)";
$query=new query($sql);
if($query->estado)
{
return true;
}
else
{
return false;
}
}
}
?>