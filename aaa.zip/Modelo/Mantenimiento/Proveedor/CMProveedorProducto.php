<?php
require_once '../../../Modelo/conexion.php';
class CMProveedorProducto{
public static function SPRCNSProveedorProducto($opcion,$id_proveedor,$dato)
{
$sql="call SPRCNSProductoProveedor($opcion,$id_proveedor,'$dato')";
$query=new query($sql);
if($query->n>0)
{
$i=0;
foreach($query->v as $fila)
{
$data[$i]=array('id_pp'=>$fila->id_proveedorproducto,'id_producto'=>$fila->id_producto,'Categoria'=>$fila->Categoria,'Marca'=>$fila->Marca,'Modelo'=>$fila->modelo,'Talla'=>$fila->Talla,'Color'=>$fila->Color,'Unidad'=>$fila->Unidad,'precio_compra'=>$fila->PCompra,'Stock'=>$fila->Stock);
$i++;
}
}
else
{
$data=array();
}
return $data;
}
public static function ABMProveedorProducto($opcion,$id_proveedorproducto,$id_proveedor,$id_producto,$precio_compra)
{
$sql="call SPRABMProductoProveedor($opcion,$id_proveedorproducto,$id_proveedor,$id_producto,$precio_compra)";
$query=new query($sql);
if($query->estado)
{
return true;
}
else
{
return false;
}
}
}
?>