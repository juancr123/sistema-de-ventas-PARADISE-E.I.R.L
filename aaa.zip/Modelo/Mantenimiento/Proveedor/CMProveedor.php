<?php
require_once '../../../Modelo/conexion.php';
class CMProveedor{
public static function SPRCNSProveedor($opcion,$dato)
{
$sql="call SPRCNSProveedor($opcion,'$dato')";
$query=new query($sql);
if($query)
{
$i=0;
foreach($query->v as $fila)
{
$data[$i]=array('id_proveedor'=>$fila->id_proveedor,'nombres'=>$fila->nombres,'apellidos'=>$fila->apellidos,'ruc'=>$fila->ruc,'provincia'=>$fila->provincia,'distrito'=>$fila->nombre,'razon_social'=>$fila->razon_social,'direccion'=>$fila->direccion,'telefono'=>$fila->telefono,'celular'=>$fila->celular,'rpm'=>$fila->rpm,'email'=>$fila->email,'fax'=>$fila->fax,'estado'=>$fila->estado);
$i++;
}
}
return $data;
}
public static function ABMProveedor($opcion,$id_proveedor,$nombres,$apellidos,$ruc,$id_distrito,$razon_social,$direccion,$telefono,$celular,$rpm,$email,$fax,$estado)
{
$sql="call SPRABMProveedor($opcion,$id_proveedor,'$nombres','$apellidos','$ruc',$id_distrito,'$razon_social','$direccion','$telefono','$celular','$rpm','$email','$fax',$estado)";
$query=new query($sql);
if($query->estado)
{
return true;
}
else
{
return false;
}
}
}
?>