<?php
require_once '../../../Modelo/conexion.php';
class CMColor
{
public static function SPRCNSColor()
{
$sql="call SPRCNSColor()";
$query=new query($sql);
if($query)
{
$i=0;
foreach($query->v as $fila)
{
$data[$i]=array('ID_COLOR'=>$fila->id_color,'NOMBRE'=>$fila->nombre);
$i++;
}
}
return $data;
}
public static function ABMColor($opcion,$id_color,$nombre)
{
$sql="call SPRABMColor($opcion,$id_color,'$nombre')";
$query=new query($sql);
if($query->estado)
{
return true;
}
else
{
return false;
}
}
}
?>
