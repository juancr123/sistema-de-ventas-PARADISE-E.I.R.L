<?php
require_once '../../../Modelo/conexion.php';
class CMPersonal{
public static function CNSPersonal($opcion,$dato)
{
$sql="call SPRCNSPersonal($opcion,'$dato')";
$query=new query($sql);
if($query)
{
$i=0;
foreach($query->v as $fila)
{
$data[$i]=array('ID_PERSONAL'=>$fila->id_personal,'NOMBRES'=>$fila->nombres,'APELLIDOS'=>$fila->apellidos,'PROVINCIA'=>$fila->provincia,'DISTRITO'=>$fila->distrito,'DIRECCION'=>$fila->direccion,'SEXO'=>$fila->sexo,'EMAIL'=>$fila->email,'TELEFONO'=>$fila->Telefono,'CLAVE'=>$fila->clave,'CELULAR'=>$fila->Celular,'TIPO'=>$fila->tipo_personal);
$i++;
}
}
return $data;
}
public static function ABMPersonal($opcion,$id_personal,$nombres,$apellidos,$id_distrito,$direccion,$sexo,$email,$telefono,$clave,$celular,$id_tipo_personal)
{
$sql="call SPRABMPersonal($opcion,$id_personal,'$nombres','$apellidos',$id_distrito,'$direccion','$sexo',$telefono,'$email',$celular,'$clave',$id_tipo_personal)";
$query=new query($sql);
if($query->estado)
{
return true;
}
else
{
return false;
}
}
}
?>
