<?php
require_once '../../../Modelo/conexion.php';
class CMMarca
{
public static function ABMMarca($opcion2,$id_marca2,$nombre_marca2)
{
/*try
{*/
$sql="call SPRABMMarca($opcion2,$id_marca2,'$nombre_marca2');";
$query=new query($sql);
if($query->estado)
{
return true;
}
else
{
return false;
}
}
public static function SPRCNSMarca()
{
$sql="call SPRCNSMarca()";
$query=new query($sql);
if($query)
{
$i=0;
foreach($query->v as $fila)
{
$data[$i]=array('ID_MARCA'=>$fila->id_marca,'NOMBRE'=>$fila->nombre);
$i++;
}
}
return $data;
}
}
/*if(CMMarca::SPRCNSMarca())
{
echo "yea";
}*/
?>