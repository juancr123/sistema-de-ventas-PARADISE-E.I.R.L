<?php
require_once '../../../Modelo/conexion.php';
class CMUnidad
{
public static function SPRCNSUnidad()
{
$sql="call SPRCNSUnidad()";
$query=new query($sql);
if($query)
{
$i=0;
foreach($query->v as $fila)
{
$data[$i]=array('ID_UNIDAD'=>$fila->id_unidad,'NOMBRE'=>$fila->nombre);
$i++;
}
}
return $data;
}
}
?>
