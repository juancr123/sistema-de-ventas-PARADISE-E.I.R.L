<?php
require_once '../../../Modelo/conexion.php';
class CMCliente
{
public static function SPRCNSCliente()
{
$sql="call SPRListadoClientes()";
$query=new query($sql);
if($query)
{
$i=0;
foreach($query->v as $fila)
{
$data[$i]=array('id_cliente'=>$fila->id_cliente,'nombres'=>$fila->nombres,'apellidos'=>$fila->apellidos,'Provincia'=>$fila->Provincia,'Distrito'=>$fila->Distrito,'direccion'=>$fila->direccion,'dni'=>$fila->dni,'ruc'=>$fila->ruc,'telefono'=>$fila->telefono,'celular'=>$fila->celular);
$i++;
}
}
return $data;
}
public static function ABMCliente($opcion,$id_cliente,$dni,$ruc,$nombres,$apellidos,$distrito,$direccion,$telefono,$celular)
{
$sql="call SPRABMClientes($opcion,$id_cliente,'$nombres','$apellidos',$distrito,'$direccion','$dni','$ruc','$telefono','$celular')";
$query=new query($sql);
if($query->n>0)
{
foreach($query->v as $fila)
{
return $fila->IdCliente;
}
}
else
{
return "";
}
}
}
?>

