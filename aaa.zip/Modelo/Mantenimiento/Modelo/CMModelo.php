<?php
require_once '../../../Modelo/conexion.php';
class CMModelo
{
public static function SPRCNSModelo($opcion,$dato)
{
$sql="call SPRCNSModelo($opcion,$dato)";
$query=new query($sql);
if($query)
{
$i=0;
foreach($query->v as $fila)
{
$data[$i]=array('ID_MODELO'=>$fila->id_modelo,'NOMBRE'=>$fila->nombre,"CATEGORIA"=>$fila->Categoria);
$i++;
}
}
return $data;
}
public static function ABMModelo($opcion,$id_modelo,$nombre,$id_categoria)
{
$sql="call SPRABMModelo($opcion,$id_modelo,'$nombre',$id_categoria)";
$query=new query($sql);
if($query->estado)
{
return true;
}
else
{
return false;
}
}
}
?>
