<?php
require_once '../../../Modelo/conexion.php';
class CMProducto
{
public static function ABMProducto($opcion,$id_producto2,$id_marca2 ,$id_color2 ,$id_talla2 ,$precio2 ,$stock2 ,$id_categoria2,$id_modelo2 ,$id_unidad2,$imagen )
{
$sql="call SPRABMProductos($opcion,$id_producto2,$id_marca2,$id_color2,$id_talla2,$precio2,$stock2 ,$id_categoria2,$id_modelo2,$id_unidad2,'$imagen')";
$query=new query($sql);
if($query->estado)
{
return true;
}
else
{
return false;
}
}
public static function SPRCNSProducto($opcion,$dato)
{
$sql="call SPRCNSProductos($opcion,'$dato')";
$query=new query($sql);
if($query->n>0)
{
$i=0;
foreach($query->v as $fila)
{
$data[$i]=array('id_producto'=>$fila->id_producto,'linea'=>$fila->Linea,'Modelo'=>$fila->Modelo,'Marca'=>$fila->Marca,'Color'=>$fila->Color,'Talla'=>$fila->Talla,'Unidad'=>$fila->Unidad,'precio_venta'=>$fila->precio_venta,'stock'=>$fila->stock,'ruta_imagen'=>$fila->ruta_imagen);
$i++;
}
}
else
{
$data=array();
}
return $data;
}
public static function getImagenProducto($id_producto)
{
$sql="call SPRObtenerImagen_Producto($id_producto)";
$query=new query($sql);
if($query)
{
foreach($query->v as $fila)
{
return $fila->ruta_imagen;
}
}
}
}
?>