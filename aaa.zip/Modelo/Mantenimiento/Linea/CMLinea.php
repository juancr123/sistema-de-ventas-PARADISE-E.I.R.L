<?php
require '../../../Modelo/conexion.php';
class CMLinea
{
public static function ABMLinea($opcion,$id_linea,$nombre_linea)
{
$sql="call SPRABMLINEA($opcion,$id_linea,'$nombre_linea');";
$query=new query($sql);
if($query->estado)
{
return true;
}
else
{
return false;
}
}
public static function VIEWLinea()
{
$sql="call SPRCNSLinea()";
$query=new query($sql);
if($query)
{
$i=0;
foreach($query->v as $fila)
{
$data[$i]=array('ID_LINEA'=>$fila->id_linea,'NOMBRE'=>$fila->nombre);
$i++;
}
}
return $data;
}
}
?>