<?php
require_once '../../../Modelo/conexion.php';
class CMCategoria
{
public static function SPRCNSCategoria()
{
$sql="call SPRCNSCategoria()";
$query=new query($sql);
if($query)
{
$i=0;
foreach($query->v as $fila)
{
$data[$i]=array('ID_CATEGORIA'=>$fila->id_categoria,'NOMBRE'=>$fila->nombre,'LINEA'=>$fila->Linea);
$i++;
}
}
return $data;
}
public static function getCategoria($id_linea)
{
$sql="select * from categoria where id_linea=$id_linea";
$query=new query($sql);
if($query)
{
$i=0;
foreach($query->v as $fila)
{
$data[$i]=array('ID_CATEGORIA'=>$fila->id_categoria,'NOMBRE'=>$fila->nombre,'LINEA'=>$fila->id_linea);
$i++;
}
}
return $data;
}
public static function ABMCategoria($opcion,$id_categoria,$nombre,$id_linea)
{
$sql="call SPRABMCategoria($opcion,$id_categoria,'$nombre',$id_linea)";
$query=new query($sql);
if($query->estado)
{
return true;
}
else
{
return false;
}
}
}
?>
