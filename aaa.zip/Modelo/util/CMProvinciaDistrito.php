<?php
require_once '../../../Modelo/conexion.php';
class CMProvinciaDistrito{
public static function CNSDistrito($id_provincia)
{
$sql="call SPRCNSDistrito($id_provincia)";
$query=new query($sql);
if($query->n>0)
{
$i=0;
foreach($query->v as $fila)
{
$data[$i]=array('ID_DISTRITO'=>$fila->id_distrito,'NOMBRE'=>$fila->nombre);
$i++;
}
}
return $data;
}
public static function CNSProvincia()
{
$sql="call SPRCNSProvincia()";
$query=new query($sql);
if($query->n>0)
{
$i=0;
foreach($query->v as $fila)
{
$data[$i]=array('ID_PROVINCIA'=>$fila->id_provincia,'NOMBRE'=>$fila->provincia);
$i++;
}
}
return $data;
}
}
?>
