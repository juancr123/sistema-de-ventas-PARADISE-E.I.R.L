<?php
class CMTipo_Personal
{
public static function CNSTipo()
{
$sql="call SPRCNSTipo_Personal()";
$query=new query($sql);
if($query)
{
$i=0;
foreach($query->v as $fila)
{
$data[$i]=array('ID_TIPO_PERSONAL'=>$fila->id_tipo_personal,'NOMBRE'=>$fila->tipo_personal);
$i++;
}
}
return $data;
}
}
?>