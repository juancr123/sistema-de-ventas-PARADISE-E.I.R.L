<?php
class bd{
	var $usuari='root'; //nombre de usuario de la base de datos
	var $clau='12345'; //contrase??el usuario
	var $servidor='localhost'; //nombre del servidor, normalmente localhost
	var $nomBD='paradise'; //nombre de la base de datos
	var $conn; //necesario para la conexion y desconexion de la base de datos
	var $debug; //modo depuracion, mostrara los errores y los querys

	function bd($debug=0){
		//para que en php 4 haya un destructor como en php 4
		register_shutdown_function(array(&$this, '__destruct'));

		//constructor
		$argcv = func_get_args();
		call_user_func_array(array(&$this, '__construct'), $argcv);
	}

	function x(){
	//para cerrar la conexion mysql
	//debes utlizarla SIEMPRE al final de tu documento
		if(isset($this->conn))@mysql_close($this->conn);
	}
	
	function error_mysql($msg,$query=''){
	//muestra el error
		if($this->debug==1 && !empty($query)) $msg .= '<br><b />QUERY:</b><br />'.$query;
		$this->enmarcar($msg);
		$this->x();
		die();
	}

	function enmarcar($str){
	//para mostrar los errores dentro de un rectangulo
		echo '<span style="display:block;border:1px red solid;padding:5px;">',$str,'</span>';
	}

	function f( $valor ){
	/*
	funcion para evitar ataques sql-injection, debes utilizarla cuando hagas querys
	Ejemplo:
	$query1 = new query("select * from usuarios where nombre='".$bd->f($_POST['nombre'])."' and password='".$bd->f($_POST['password'])."'",$bd);
	*/
        	if(get_magic_quotes_gpc())
	      		$valor = stripslashes($valor);
		if( function_exists('mysql_real_escape_string') )
			return mysql_real_escape_string( $valor );
		else //per PHP inferior a 4.3.0
			return addslashes( $valor );
	}

	function __destruct(){
		//el destructor se ejecuta antes de cerrar la ejecucion y con esto cerramos la conexion a la base de datos
		$this->x();
	}


	function __construct($debug=0)
	{
		//al llamarla conecta directametne a la base de datos
		$this->debug = $debug;
		$this->conn = @mysql_connect($this->servidor, $this->usuari, $this->clau) or $this->error_mysql(mysql_error());
		mysql_select_db($this->nomBD) or $this->error_mysql(mysql_error());
	}
}

class query{
	var $bd;//conexion mysql, requerido para llamar funciones de la classe bd
	var $q; //query introducida
	var $n;//numero de resultados
	var $v;//los resultados en una tabla de objetos
	var $a;//numero de filas afectadas por la query
	var $estado=true;
	

	function query($query){
		//constructor
		$argcv = func_get_args();
		call_user_func_array(array(&$this, '__construct'), $argcv);
	}

	function __construct($query)
	{
	//ejecuta la query y rellena las propiedades del objeto
	
		$this->q = $query;
		$this->bd = new bd();
		$mysql_result = @mysql_query($query) or $this->error();
		/*$this->bd->error_mysql(mysql_error(),$query); 
		/*para mostrar la descripcion del error*/
		
		$this->n = @mysql_num_rows($mysql_result);
		$this->a = @mysql_affected_rows();
		if($this->n)
			for($i=0;$i<$this->n;$i++) $taula[$i] = @mysql_fetch_object($mysql_result);
		else $taula = null;
		$this->v = $taula;
		if(  $this->n > 0  ) mysql_free_result($mysql_result);
			
	$this->bd->x();
		
	}
	function error()
	{
	$this->estado=false;
	}
}
?>
