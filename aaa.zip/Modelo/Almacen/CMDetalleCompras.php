<?php
require_once '../../../Modelo/conexion.php';
class CMDetalleCompras
{
public static function ABMDetalle_Compras($opcion,$id_detalle_compra,$id_compra,$id_producto,$cantidad,$costo)
{
$sql="call SPRABMDetalleCompra($opcion,$id_detalle_compra,$id_compra,$id_producto,$cantidad,$costo)";
$query=new query($sql);
return $query;
}
public static function CNSDetalleCompras($id_compra,$id_proveedor)
{
$sql="call SPRCNSDetalle_Compra($id_compra,$id_proveedor)";
$query=new query($sql);
if($query->n>0)
{
$i=0;
foreach($query->v as $fila)
{
$data[$i]=array('ID_DETALLE_COMPRA'=>$fila->id_detalle_compra_producto,'ID_PRODUCTO'=>$fila->id_producto,'DESCRIPCION'=>$fila->Descripcion,'PRECIO_COMPRA'=>$fila->precio_compra,'CANTIDAD'=>$fila->cantidad,'COSTO'=>$fila->costo);
$i++;
}
}
else
{
$data=array();
}
return $data;
}
public static function get_ID_DETALLE_COMPRA($dato)
{
$sql="call SPRObtenerIdDetalleCompra($dato)";
$query=new query($sql);
$i=0;
foreach($query->v as $fila)
{
$data[$i]=$fila->id_detalle_compra_producto;
$i++;
}
return $data;
}
}
?>
