<?php
require '../../../Modelo/conexion.php';
class CMCompras
{
public static function ABMCompras($opcion,$id_compra,$id_proveedor,$fecha_compra,$estado,$subtotal,$igv,$total)
{
$sql="call SPRABMCompra($opcion,$id_compra,$id_proveedor,'$fecha_compra',$estado,$subtotal,$igv,$total)";
$query=new query($sql);
return $query;
}
public static function get_ID_COMPRA()
{
$sql="call SPRObtenerIdCompra()";
$query=new query($sql);
foreach($query->v as $fila)
{
return $fila->id_compra;
}
}
public static function CNSCompras($opcion,$dato)
{
$sql="call SPRCNSCompra($opcion,'$dato')";
$query=new query($sql);
if($query->n>0)
{
$i=0;
foreach($query->v as $fila)
{
$data[$i]=array('ID_COMPRA'=>$fila->id_compra,'ID_PROVEEDOR'=>$fila->id_proveedor,'RUC'=>$fila->ruc,'TELEFONO'=>$fila->telefono,'RAZON_SOCIAL'=>$fila->razon_social,'NOMBRES'=>$fila->nombres,'APELLIDOS'=>$fila->apellidos,'FECHA'=>$fila->fecha_compra,'SUBTOTAL'=>$fila->sub_total,'IGV'=>$fila->igv,'TOTAL'=>$fila->total);
$i++;
}
}
else
{
$data=array(); /*en caso la consulta devuelva 0 registros*/
}
return $data;
}
public static function ReportesAlmacen($opcion,$dato)
{
$sql="call SPRReportesAlmacen($opcion,$dato)";
$query=new query($sql);
if($query)
{
$i=0;
foreach($query->v as $fila)
{
$data[$i]=array('DESCRIPCION'=>$fila->Descripcion,'STOCK'=>$fila->Stock);
$i++;
}
}
return $data;
}
}
?>
