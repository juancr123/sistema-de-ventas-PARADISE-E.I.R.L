<?php
require '../../Modelo/conexion.php';
class CMAcceso 
{
public static function validAcceso($nick,$clave)
{
$conn=conexion::conectar();
$sql = "select * from table(ValidarUsuario('$nick','$clave'))";
$stid =oci_parse($conn,$sql);
oci_execute($stid);
$fila=oci_fetch_array($stid,OCI_ASSOC);
if($fila)
{
$valid=true;
}
else
{
$valid=false;
}
return $valid;
}
public static function valid()
{
$conn=conexion::conectar();
$sql = "select * from table (SPRCNSMARCA())";
$stid =oci_parse($conn,$sql);
oci_execute($stid);
$conn=conexion::cerrar();
return $stid;
}
}
/*$stid=CMAcceso::valid();
while($fila=oci_fetch_array($stid,OCI_ASSOC))
{
//$fila=oci_fetch_array($stid,OCI_ASSOC);
echo $fila['NOMBRE']."<br>";
}*/
?>