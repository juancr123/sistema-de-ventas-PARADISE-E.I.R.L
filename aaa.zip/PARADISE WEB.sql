-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.86-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema paradise
--

CREATE DATABASE IF NOT EXISTS paradise;
USE paradise;

--
-- Definition of table `boleta`
--

DROP TABLE IF EXISTS `boleta`;
CREATE TABLE `boleta` (
  `id_boleta` int(11) NOT NULL auto_increment,
  `numero_boleta` int(11) NOT NULL,
  `id_cliente` int(11) NOT NULL,
  `id_personal` int(11) NOT NULL,
  `id_forma_pago` int(11) NOT NULL,
  `fecha_pedido` datetime NOT NULL,
  `fecha_entrega` datetime NOT NULL,
  `sub_total` decimal(6,2) NOT NULL,
  `igv` decimal(6,2) NOT NULL,
  `total` decimal(6,2) NOT NULL,
  `id_tipo_recibo` int(11) NOT NULL,
  PRIMARY KEY  (`id_boleta`),
  KEY `FK_BOLETA01` (`id_cliente`),
  KEY `FK_BOLETA02` (`id_personal`),
  KEY `FK_BOLETA03` (`id_forma_pago`),
  KEY `fk_BOLETA04` (`id_tipo_recibo`),
  CONSTRAINT `FK_BOLETA01` FOREIGN KEY (`id_cliente`) REFERENCES `cliente` (`id_cliente`),
  CONSTRAINT `FK_BOLETA02` FOREIGN KEY (`id_personal`) REFERENCES `personal` (`id_personal`),
  CONSTRAINT `FK_BOLETA03` FOREIGN KEY (`id_forma_pago`) REFERENCES `forma_pago` (`id_forma_pago`),
  CONSTRAINT `fk_BOLETA04` FOREIGN KEY (`id_tipo_recibo`) REFERENCES `tipo_recibo` (`id_tipo_recibo`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `boleta`
--

/*!40000 ALTER TABLE `boleta` DISABLE KEYS */;
INSERT INTO `boleta` (`id_boleta`,`numero_boleta`,`id_cliente`,`id_personal`,`id_forma_pago`,`fecha_pedido`,`fecha_entrega`,`sub_total`,`igv`,`total`,`id_tipo_recibo`) VALUES 
 (1,12321,4,46606801,1,'2012-07-27 00:00:00','2012-07-27 00:00:00','140.50','25.29','165.79',1),
 (2,23123,4,46606801,1,'2012-07-27 00:00:00','2012-07-27 00:00:00','290.50','52.29','342.79',1),
 (3,43434,9,46606801,1,'2012-07-28 00:00:00','2012-07-28 00:00:00','150.00','27.00','177.00',1),
 (4,213123,16,46606801,1,'2012-08-02 00:00:00','2012-08-02 00:00:00','281.00','50.58','331.58',1),
 (5,21312,3,46606801,1,'2012-09-10 00:00:00','2012-09-10 00:00:00','140.50','25.29','165.79',1),
 (6,213123,4,46606801,1,'2012-10-07 00:00:00','2012-10-07 00:00:00','140.50','25.29','165.79',1),
 (7,21312,3,46606801,1,'2012-10-07 00:00:00','2012-10-07 00:00:00','281.00','50.58','331.58',1),
 (8,213123,9,46606801,1,'2012-10-07 00:00:00','2012-10-07 00:00:00','590.50','106.29','696.79',1);
/*!40000 ALTER TABLE `boleta` ENABLE KEYS */;


--
-- Definition of table `categoria`
--

DROP TABLE IF EXISTS `categoria`;
CREATE TABLE `categoria` (
  `id_categoria` int(11) NOT NULL auto_increment,
  `nombre` varchar(45) NOT NULL,
  `id_linea` int(11) NOT NULL,
  PRIMARY KEY  (`id_categoria`),
  KEY `FK_CATEGORIA01` (`id_linea`),
  CONSTRAINT `FK_CATEGORIA01` FOREIGN KEY (`id_linea`) REFERENCES `linea` (`id_linea`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categoria`
--

/*!40000 ALTER TABLE `categoria` DISABLE KEYS */;
INSERT INTO `categoria` (`id_categoria`,`nombre`,`id_linea`) VALUES 
 (0,'',0),
 (1,'SANDALIA',1),
 (2,'ZAPATILLA',1),
 (3,'BOTA',1),
 (4,'ZAPATO',1),
 (5,'TACO2',1),
 (6,'POLO',2),
 (7,'PANTALON',2),
 (8,'CAMIZA',2),
 (9,'POLERAS',2),
 (10,'CORREA',3),
 (11,'BILLETERA',3),
 (12,'LLAVERO',3),
 (13,'BOLSO',4),
 (14,'DE ASA',4),
 (15,'DE MANO',4),
 (16,'MOCHILA',5),
 (17,'LONCHERA',5),
 (40,'cat5555',1),
 (44,'cat2322',1),
 (49,'cat7777',1);
/*!40000 ALTER TABLE `categoria` ENABLE KEYS */;


--
-- Definition of table `cliente`
--

DROP TABLE IF EXISTS `cliente`;
CREATE TABLE `cliente` (
  `id_cliente` int(11) NOT NULL auto_increment,
  `nombres` varchar(50) NOT NULL,
  `apellidos` varchar(50) NOT NULL,
  `id_distrito` int(11) NOT NULL,
  `direccion` varchar(50) NOT NULL,
  `dni` varchar(8) NOT NULL,
  `ruc` varchar(11) NOT NULL,
  `telefono` varchar(8) NOT NULL,
  `celular` varchar(9) NOT NULL,
  PRIMARY KEY  (`id_cliente`),
  KEY `FK_CLIENTE01` (`id_distrito`),
  CONSTRAINT `FK_CLIENTE01` FOREIGN KEY (`id_distrito`) REFERENCES `distrito` (`id_distrito`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cliente`
--

/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` (`id_cliente`,`nombres`,`apellidos`,`id_distrito`,`direccion`,`dni`,`ruc`,`telefono`,`celular`) VALUES 
 (3,'JUAN MANUEL','PALACIOS FERNANDEZ',17,'URB FUJIMORI 444','45665522','213212','21312','992123333'),
 (4,'MIGUEL2','XIMENEZ BAZAN',18,'DOMINGO COLOMA 444','56553322','213213','23123','213123'),
 (6,'JOSE','PEREZ',28,'DOMINGO COLOMA 222','46606877','23123123','232444','22222222'),
 (9,'JOSE LUIS','MENESES MORALES',20,'Urb San Jose 233','46600988','2312312','3222232','213213123'),
 (10,'JUAN CARLOS','CAMONES PALOMINO',20,'Los sauces 211','46606755','2321331','2312312','213123123'),
 (11,'JORGE LUIS','MORALEZ GONZALES',28,'Las Flores 111','46554433','','2325566','992123544'),
 (13,'asd2','asd',28,'asd','123','123','123','123'),
 (14,'asd','asd',28,'sad','23','23','23','23'),
 (15,'juan','juan',28,'rivera','santiago','2322','2324433','9987766'),
 (16,'Juan Carlos','Juan Carlos',28,'las flores 234','45655544','','2325566',''),
 (19,'adsas','adsas',28,'','32432432','','','');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;


--
-- Definition of table `color`
--

DROP TABLE IF EXISTS `color`;
CREATE TABLE `color` (
  `id_color` int(11) NOT NULL auto_increment,
  `nombre` varchar(35) NOT NULL,
  PRIMARY KEY  (`id_color`),
  UNIQUE KEY `uqcolor_color` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `color`
--

/*!40000 ALTER TABLE `color` DISABLE KEYS */;
INSERT INTO `color` (`id_color`,`nombre`) VALUES 
 (0,''),
 (18,'AMARILLO'),
 (14,'AMATISTE'),
 (12,'AZUL'),
 (13,'AZUL AQUA'),
 (23,'AZUL ARTICO'),
 (20,'AZUL CIELO'),
 (10,'AZUL CLARO'),
 (24,'AZUL MARINO2'),
 (11,'AZUL TURQUESA'),
 (2,'BLANCO'),
 (6,'BURDEOS'),
 (19,'DAMSON'),
 (4,'FRAMBUESA'),
 (15,'LILA'),
 (5,'MORA'),
 (1,'NEGRO'),
 (26,'NEGRO Y BLANCO'),
 (25,'PLOMO CON VERDE'),
 (21,'PRUNA'),
 (3,'ROJO'),
 (9,'ROSA'),
 (8,'ROSA CLARO'),
 (7,'ROSA ENCARNADO'),
 (22,'SEYCHELLES'),
 (17,'VERDE'),
 (16,'VIOLETA');
/*!40000 ALTER TABLE `color` ENABLE KEYS */;


--
-- Definition of table `compra`
--

DROP TABLE IF EXISTS `compra`;
CREATE TABLE `compra` (
  `id_compra` int(11) NOT NULL auto_increment,
  `id_proveedor` int(11) NOT NULL,
  `fecha_compra` datetime NOT NULL,
  `estado` decimal(1,0) NOT NULL,
  `sub_total` float NOT NULL,
  `igv` decimal(10,0) NOT NULL,
  `total` float NOT NULL,
  PRIMARY KEY  (`id_compra`,`sub_total`),
  KEY `FK_COMPRA01` (`id_proveedor`),
  CONSTRAINT `FK_COMPRA01` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedor` (`id_proveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `compra`
--

/*!40000 ALTER TABLE `compra` DISABLE KEYS */;
INSERT INTO `compra` (`id_compra`,`id_proveedor`,`fecha_compra`,`estado`,`sub_total`,`igv`,`total`) VALUES 
 (3,6,'2012-10-07 00:00:00','0',369.88,'67',436.458);
/*!40000 ALTER TABLE `compra` ENABLE KEYS */;


--
-- Definition of table `detalle_boleta_producto`
--

DROP TABLE IF EXISTS `detalle_boleta_producto`;
CREATE TABLE `detalle_boleta_producto` (
  `id_detalle_boleta_producto` int(11) NOT NULL auto_increment,
  `id_boleta` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `costo` decimal(6,2) NOT NULL,
  PRIMARY KEY  (`id_detalle_boleta_producto`),
  KEY `FK_DETABOLETA01` (`id_boleta`),
  KEY `FK_DETABOLETA02` (`id_producto`),
  CONSTRAINT `FK_DETABOLETA01` FOREIGN KEY (`id_boleta`) REFERENCES `boleta` (`id_boleta`),
  CONSTRAINT `FK_DETABOLETA02` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id_producto`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detalle_boleta_producto`
--

/*!40000 ALTER TABLE `detalle_boleta_producto` DISABLE KEYS */;
INSERT INTO `detalle_boleta_producto` (`id_detalle_boleta_producto`,`id_boleta`,`id_producto`,`cantidad`,`costo`) VALUES 
 (1,1,1,1,'140.50'),
 (2,2,1,1,'140.50'),
 (3,2,3,1,'150.00'),
 (4,3,3,1,'150.00'),
 (5,4,1,2,'281.00'),
 (6,5,1,1,'140.50'),
 (7,6,1,1,'140.50'),
 (8,7,1,2,'281.00'),
 (9,8,1,1,'140.50'),
 (10,8,2,3,'450.00');
/*!40000 ALTER TABLE `detalle_boleta_producto` ENABLE KEYS */;


--
-- Definition of trigger `CTBTGRINSDetalleVenta`
--

DROP TRIGGER /*!50030 IF EXISTS */ `CTBTGRINSDetalleVenta`;

DELIMITER $$

CREATE DEFINER = `root`@`localhost` TRIGGER `CTBTGRINSDetalleVenta` AFTER INSERT ON `detalle_boleta_producto` FOR EACH ROW begin
update producto set stock=stock-new.cantidad where id_producto=new.id_producto;
end $$

DELIMITER ;

--
-- Definition of table `detalle_compra_producto`
--

DROP TABLE IF EXISTS `detalle_compra_producto`;
CREATE TABLE `detalle_compra_producto` (
  `id_detalle_compra_producto` int(11) NOT NULL auto_increment,
  `id_compra` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `costo` float NOT NULL,
  PRIMARY KEY  (`id_detalle_compra_producto`),
  KEY `FK_detallecompra01` (`id_compra`),
  KEY `FK_detallecompra02` (`id_producto`),
  CONSTRAINT `FK_detallecompra01` FOREIGN KEY (`id_compra`) REFERENCES `compra` (`id_compra`),
  CONSTRAINT `FK_detallecompra02` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id_producto`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detalle_compra_producto`
--

/*!40000 ALTER TABLE `detalle_compra_producto` DISABLE KEYS */;
INSERT INTO `detalle_compra_producto` (`id_detalle_compra_producto`,`id_compra`,`id_producto`,`cantidad`,`costo`) VALUES 
 (11,3,2,1,123),
 (12,3,4,2,246.88);
/*!40000 ALTER TABLE `detalle_compra_producto` ENABLE KEYS */;


--
-- Definition of trigger `CTBTGRINSDetalleCompra`
--

DROP TRIGGER /*!50030 IF EXISTS */ `CTBTGRINSDetalleCompra`;

DELIMITER $$

CREATE DEFINER = `root`@`localhost` TRIGGER `CTBTGRINSDetalleCompra` AFTER INSERT ON `detalle_compra_producto` FOR EACH ROW begin
set @estado=(select com.estado from compra com,detalle_compra_producto det where det.id_compra = com.id_compra and det.id_detalle_compra_producto=new.id_detalle_compra_producto);
if (@estado=1) then
update producto set stock=stock+new.cantidad where id_producto=new.id_producto;
end if;
end $$

DELIMITER ;

--
-- Definition of trigger `CTBTGRUPDDetalleCompra`
--

DROP TRIGGER /*!50030 IF EXISTS */ `CTBTGRUPDDetalleCompra`;

DELIMITER $$

CREATE DEFINER = `root`@`localhost` TRIGGER `CTBTGRUPDDetalleCompra` BEFORE UPDATE ON `detalle_compra_producto` FOR EACH ROW begin
set @estado=(select com.estado from compra com,detalle_compra_producto det where det.id_compra = com.id_compra and det.id_detalle_compra_producto=new.id_detalle_compra_producto);
if (@estado=1) 
then
update producto set stock=stock+new.cantidad where id_producto=new.id_producto;
end if;
end $$

DELIMITER ;

--
-- Definition of table `distrito`
--

DROP TABLE IF EXISTS `distrito`;
CREATE TABLE `distrito` (
  `id_distrito` int(11) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `id_provincia` int(11) unsigned NOT NULL,
  PRIMARY KEY  (`id_distrito`),
  KEY `FK_distrito_1` (`id_provincia`),
  CONSTRAINT `FK_distrito_1` FOREIGN KEY (`id_provincia`) REFERENCES `provincia` (`id_provincia`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `distrito`
--

/*!40000 ALTER TABLE `distrito` DISABLE KEYS */;
INSERT INTO `distrito` (`id_distrito`,`nombre`,`id_provincia`) VALUES 
 (0,'',0),
 (1,'CAJATAMBO',184),
 (2,'COPA',184),
 (3,'GORGOR',184),
 (4,'HUANCAPO',184),
 (5,'MANAS',184),
 (6,'BARRANCA',185),
 (7,'PARAMONGA',185),
 (8,'PATIVILCA',185),
 (9,'SUPE',185),
 (10,'SUPE PUERTO',185),
 (11,'ANDAJES',186),
 (12,'CAUJUL',186),
 (13,'COCHAMARCA',186),
 (14,'NAVA',186),
 (15,'OYO',186),
 (16,'PACHANGARA',186),
 (17,'AMBAR',187),
 (18,'CALETA DE CARQUIN',187),
 (19,'CHECRAS',187),
 (20,'HUACHO',187),
 (21,'HUALMAY',187),
 (22,'HUAURA',187),
 (23,'LEONCIO PRADO',187),
 (24,'PACCHO',187),
 (25,'SANTA LEONOR',187),
 (26,'SANTA MARIA',187),
 (27,'SAYAN',187),
 (28,'VEGUETA',187),
 (29,'ATAVILLOS ALTO',188),
 (30,'ATAVILLOS BAJO',188),
 (31,'AUCALLAMA',188),
 (32,'CHANCAY',188),
 (33,'HUARAL',188),
 (34,'IHUARI',188),
 (35,'LAMPIA',188),
 (36,'PACARAOS',188),
 (37,'SAN MIGUEL DE ACOS',188),
 (38,'SANTA CRUZ DE ANDAMARCA',188),
 (39,'SUMBILCA',188),
 (40,'VENTISIETE DE NOVIEMBRE',188),
 (41,'ARAHUAY',189),
 (42,'CANTA',189),
 (43,'HUAMANTANGA',189),
 (44,'HUAROS',189),
 (45,'LACHAQUI',189),
 (46,'SAN BUENAVENTURA',189),
 (47,'SANTA ROSA DE QUIVES',189),
 (48,'ANCON',190),
 (49,'ATE VITARTE',190),
 (50,'SANTA ANITA',190),
 (51,'SANTA MARIA DEL MAR',190),
 (52,'SANTA ROSA',190),
 (53,'CHACLACAYO',190),
 (54,'SANTIAGO DE SURCO',190),
 (55,'SURQUILLO',190),
 (56,'BARRANCO',190),
 (57,'BREÃ‘A',190),
 (58,'CARABAYLLO',190),
 (59,'VILLA EL SALVADOR',190),
 (60,'CHORRILLOS',190),
 (61,'CIENEGUILLA',190),
 (62,'COMAS',190),
 (63,'EL AGUSTINO',190),
 (64,'INDEPENDENCIA',190),
 (65,'JESUS MARIA',190),
 (66,'LA MOLINA',190),
 (67,'LA VICTORIA',190),
 (68,'LIMA',190),
 (69,'LINCE',190),
 (70,'LOS OLIVOS',190),
 (71,'LURIGANCHO',190),
 (72,'LURIN',190),
 (73,'MAGDALENA DEL MAR',190),
 (74,'MAGDALENA VIEJA',190),
 (75,'MIRAFLORES',190),
 (76,'PACHACAMAC',190),
 (77,'PUCUSANA',190),
 (78,'PUENTE PIEDRA',190),
 (79,'PUNTA HERMOSA',190),
 (80,'PUNTA NEGRA',190),
 (81,'RIMAC',190),
 (82,'SAN BARTOLO',190),
 (83,'SAN BORJA',190),
 (84,'SAN ISIDRO',190),
 (85,'SAN JUAN DE LURIGANCHO',190),
 (86,'SAN JUAN DE MIRAFLORES',190),
 (87,'SAN LUIS',190),
 (88,'VILLA MARÃA DEL TRIUNFO',190),
 (89,'SAN MARTIN DE PORRES',190),
 (90,'SAN MIGUEL',190),
 (91,'ANTIOQUIA',191),
 (92,'CALLAHUANCA',191),
 (93,'CARAMPOMA',191),
 (94,'CHICLA',191),
 (95,'CUENCA',191),
 (96,'HUACHUPAMPA',191),
 (97,'HUANZA',191),
 (98,'HUAROCHIRI',191),
 (99,'LAHUAYTAMBO',191),
 (100,'LANGA',191),
 (101,'LARAOS',191),
 (102,'MARIATANA',191),
 (103,'MATUCANA',191),
 (104,'RICARDO PALMA',191),
 (105,'SAN ANDRES DE TUPICOCHA',191),
 (106,'SAN ANTONIO',191),
 (107,'SAN BARTOLOME',191),
 (108,'SAN DAMIA',191),
 (109,'SAN JUAN DE IRIS',191),
 (110,'SAN JUAN DE TANTARANCHE',191),
 (111,'SAN LORENZO DE QUINTI',191),
 (112,'SAN MATEO',191),
 (113,'SAN MATEO DE OTAO',191),
 (114,'SAN PEDRO DE CASTA',191),
 (115,'SAN PEDRO DE HUANCAYRE',191),
 (116,'SANGALLAYA',191),
 (117,'SANTA CRUZ DE COCACHACRA',191),
 (118,'SANTA EULALIA',191),
 (119,'SANTIAGO DE ANCHUCAYA',191),
 (120,'SANTIAGO DE TUNA',191),
 (121,'SANTO DOMINGO DE LOS OLLERO',191),
 (122,'SURCO',191),
 (123,'ALIS',192),
 (124,'AYAUCA',192),
 (125,'AYAVIRI',192),
 (126,'AZANGARO',192),
 (127,'CACRA',192),
 (128,'CARANIA',192),
 (129,'CATAHUASI',192),
 (130,'CHOCOS',192),
 (131,'COCHAS',192),
 (132,'COLONIA',192),
 (133,'HONGOS',192),
 (134,'HUAÃ‘EC',192),
 (135,'HUAMPARA',192),
 (136,'HUANCAYA',192),
 (137,'HUANGASCAR',192),
 (138,'HUANTA',192),
 (139,'LARAOS',192),
 (140,'LINCHA',192),
 (141,'MADEA',192),
 (142,'MIRAFLORES',192),
 (143,'OMAS',192),
 (144,'PUTINZA',192),
 (145,'QUINCHES',192),
 (146,'QUINOCAY',192),
 (147,'SAN JOAQUI',192),
 (148,'SAN PEDRO DE PILAS',192),
 (149,'TANTA',192),
 (150,'TAURIPAMPA',192),
 (151,'TOMAS',192),
 (152,'TUPE',192),
 (153,'VIÃ‘AC',192),
 (154,'VITIS',192),
 (155,'YAUYOS',192),
 (156,'ASIA',193),
 (157,'CALANGO',193),
 (158,'CERRO AZUL',193),
 (159,'CHILCA',193),
 (160,'COAYLLO',193),
 (161,'IMPERIAL',193),
 (162,'LUNAHUANA',193),
 (163,'MALA',193),
 (164,'NUEVO IMPERIAL',193),
 (165,'PACARA',193),
 (166,'QUILMANA',193),
 (167,'SAN ANTONIO',193),
 (168,'SAN LUIS',193),
 (169,'SAN VICENTE DE CAÃ‘ETE',193),
 (170,'SANTA CRUZ DE FLORES',193),
 (171,'ZUÃ‘IGA',193),
 (172,'ASUNCION',1),
 (173,'BALSAS',1),
 (174,'CHACHAPOYAS',1),
 (175,'CHETO',1),
 (176,'CHILIQUI',1),
 (177,'CHUQUIBAMBA',1),
 (178,'GRANADA',1),
 (179,'HUANCAS',1),
 (180,'LA JALCA',1),
 (181,'LEIMEBAMBA',1),
 (182,'LEVANTO',1),
 (183,'MAGDALENA',1),
 (184,'MARISCAL CASTILLA',1),
 (185,'MOLINOPAMPA',1),
 (186,'MONTEVIDEO',1),
 (187,'OLLEROS',1),
 (188,'QUINJALCA',1),
 (189,'SAN FRANCISCO DE DAGUAS',1),
 (190,'SAN ISIDRO DE MAINO',1),
 (191,'SOLOCO',1),
 (192,'SONCHE',1),
 (193,'CHIRIMOTO',2),
 (194,'COCHAMAL',2),
 (195,'HUAMBO',2),
 (196,'LIMABAMBA',2),
 (197,'LONGAR',2),
 (198,'MARISCAL BENAVIDES',2),
 (199,'MILPUC',2),
 (200,'OMIA',2),
 (201,'SAN NICOLAS',2),
 (202,'SANTA ROSA',2),
 (203,'TOTORA',2),
 (204,'VISTA ALEGRE',2),
 (205,'CAMPORREDONDO',3),
 (206,'COCABAMBA',3),
 (207,'COLCAMAR',3),
 (208,'CONILA',3),
 (209,'INGUILPATA',3),
 (210,'LAMUD',3),
 (211,'LONGUITA',3),
 (212,'LONYA CHICO',3),
 (213,'LUYA',3),
 (214,'LUYA VIEJO',3),
 (215,'MARIA',3),
 (216,'OCALLI',3),
 (217,'OCUMAL',3),
 (218,'PISUQUIA',3),
 (219,'PROVIDENCIA',3),
 (220,'SAN CRISTOBAL',3),
 (221,'SAN FRANCISCO DEL YESO',3),
 (222,'SAN JERONIMO',3),
 (223,'SAN JUAN DE LOPECANCHA',3),
 (224,'SANTA CATALINA',3),
 (225,'SANTO TOMAS',3),
 (226,'TINGO',3),
 (227,'TRITA',3),
 (228,'CHISQUILLA',4),
 (229,'CHURUJA',4),
 (230,'COROSHA',4),
 (231,'CUISPES',4),
 (232,'FLORIDA',4),
 (233,'JAZA',4),
 (234,'JUMBILLA',4),
 (235,'RECTA',4),
 (236,'SAN CARLOS',4),
 (237,'SHIPASBAMBA',4),
 (238,'VALERA',4),
 (239,'YAMBRASBAMBA',4),
 (240,'BAGUA GRANDE',5),
 (241,'CAJARURO',5),
 (242,'CUMBA',5),
 (243,'EL MILAGRO',5),
 (244,'JAMALCA',5),
 (245,'LONYA GRANDE',5),
 (246,'YAMO',5),
 (247,'ARAMANGO',6),
 (248,'COPALLI',6),
 (249,'EL PARCO',6),
 (250,'IMAZA',6),
 (251,'LA PECA',6),
 (252,'EL CENEPA',7),
 (253,'NIEVA',7),
 (254,'RIO SANTIAGO',7),
 (255,'COCHABAMBA',8),
 (256,'COLCABAMBA',8),
 (257,'HUANCHAY',8),
 (258,'HUARAZ',8),
 (259,'INDEPENDENCIA',8),
 (260,'JANGAS',8),
 (261,'LA LIBERTAD',8),
 (262,'OLLEROS',8),
 (263,'PAMPAS',8),
 (264,'PARIACOTO',8),
 (265,'PIRA',8),
 (266,'TARICA',8),
 (267,'CASCAPARA',9),
 (268,'MANCOS',9),
 (269,'MATACOTO',9),
 (270,'QUILLO',9),
 (271,'RANRAHIRCA',9),
 (272,'SHUPLUY',9),
 (273,'YANAMA',9),
 (274,'YUNGAY',9),
 (275,'ACOPAMPA',10),
 (276,'AMASHCA',10),
 (277,'ANTA',10),
 (278,'ATAQUERO',10),
 (279,'CARHUAZ',10),
 (280,'MARCARA',10),
 (281,'PARIAHUANCA',10),
 (282,'SAN MIGUEL DE ACO',10),
 (283,'SHILLA',10),
 (284,'TINCO',10),
 (285,'YUNGAR',10),
 (286,'CARAZ',11),
 (287,'HUALLANCA',11),
 (288,'HUATA',11),
 (289,'HUAYLAS',11),
 (290,'MATO',11),
 (291,'PAMPAROMAS',11),
 (292,'PUEBLO LIBRE',190),
 (293,'SANTA CRUZ',11),
 (294,'SANTO TORIBIO',11),
 (295,'YURACMARCA',11),
 (296,'CATAC',12),
 (297,'COTAPARACO',12),
 (298,'HUAYLLAPAMPA',12),
 (299,'LLACLLI',12),
 (300,'MARCA',12),
 (301,'PAMPAS CHICO',12),
 (302,'PARARI',12),
 (303,'RECUAY',12),
 (304,'TAPACOCHA',12),
 (305,'TICAPAMPA',12),
 (306,'AIJA',13),
 (307,'CORIS',13),
 (308,'HUACLLA',13),
 (309,'LA MERCED',13),
 (310,'SUCCHA',13),
 (311,'HUAYLLA',14),
 (312,'PAROBAMBA',14),
 (313,'POMABAMBA',14),
 (314,'QUINUABAMBA',14),
 (315,'CASCA',15),
 (316,'ELEAZAR GUZMAN BARRO',15),
 (317,'FIDEL OLIVAS ESCUDERO',15),
 (318,'LLAMA',15),
 (319,'LLUMPA',15),
 (320,'LUCMA',15),
 (321,'MUSGA',15),
 (322,'PISCOBAMBA',15),
 (323,'ACOCHACA',16),
 (324,'CHACAS',16),
 (325,'SAN LUIS',17),
 (326,'SAN NICOLAS',17),
 (327,'YAUYA',17),
 (328,'ANRA',18),
 (329,'CAJAY',18),
 (330,'CHAVIN DE HUANTAR',18),
 (331,'HUACACHI',18),
 (332,'HUACCHIS',18),
 (333,'HUACHIS',18),
 (334,'HUANTAR',18),
 (335,'HUARI',18),
 (336,'MASI',18),
 (337,'PAUCAS',18),
 (338,'PONTO',18),
 (339,'RAHUAPAMPA',18),
 (340,'RAPAYA',18),
 (341,'SAN MARCOS',18),
 (342,'SAN PEDRO DE CHANA',18),
 (343,'UCO',18),
 (344,'ACZO',19),
 (345,'CHACCHO',19),
 (346,'CHINGAS',19),
 (347,'LLAMELLI',19),
 (348,'MIRGAS',19),
 (349,'SAN JUAN DE RONTOY',19),
 (350,'ACAS',20),
 (351,'CAJAMARQUILLA',20),
 (352,'CARHUAPAMPA',20),
 (353,'COCHAS',20),
 (354,'CONGAS',20),
 (355,'LLIPA',20),
 (356,'OCROS',20),
 (357,'SAN CRISTOBAL DE RAJA',20),
 (358,'SAN PEDRO',20),
 (359,'SANTIAGO DE CHILCAS',20),
 (360,'ABELARDO PARDO LEZAMETA',21),
 (361,'ANTONIO RAYMONDI',21),
 (362,'AQUIA',21),
 (363,'CAJACAY',21),
 (364,'CANIS',21),
 (365,'CHIQUIA',21),
 (366,'COLQUIOC',21),
 (367,'HUALLANCA',21),
 (368,'HUASTA',21),
 (369,'HUAYLLACAYA',21),
 (370,'LA PRIMAVERA',21),
 (371,'MANGAS',21),
 (372,'PACLLO',21),
 (373,'SAN MIGUEL DE CORPANQUI',21),
 (374,'TICLLOS',21),
 (375,'CACERES DEL PERU',22),
 (376,'CHIMBOTE',22),
 (377,'COISHCO',22),
 (378,'MACATE',22),
 (379,'MORO',22),
 (380,'NEPEÃ‘A',22),
 (381,'NUEVO CHIMBOTE',22),
 (382,'SAMANCO',22),
 (383,'SANTA',22),
 (384,'BUENA VISTA ALTA',23),
 (385,'CASMA',23),
 (386,'COMANDANTE NOEL',23),
 (387,'YAUTA',23),
 (388,'COCHAPETI',24),
 (389,'CULEBRAS',24),
 (390,'HUARMEY',24),
 (391,'HUAYA',24),
 (392,'MALVAS',24),
 (393,'ACOBAMBA',25),
 (394,'ALFONSO UGARTE',25),
 (395,'CASHAPAMPA',25),
 (396,'CHINGALPO',25),
 (397,'HUAYLLABAMBA',25),
 (398,'QUICHES',25),
 (399,'RAGASH',25),
 (400,'SAN JUA',25),
 (401,'SICSIBAMBA',25),
 (402,'SIHUAS',25),
 (403,'ACO',26),
 (404,'BAMBAS',26),
 (405,'CORONGO',26),
 (406,'CUSCA',26),
 (407,'LA PAMPA',26),
 (408,'YANAC',26),
 (409,'YUPA',26),
 (410,'BOLOGNESI',27),
 (411,'CABANA',27),
 (412,'CONCHUCOS',27),
 (413,'HUACASCHUQUE',27),
 (414,'HUANDOVAL',27),
 (415,'LACABAMBA',27),
 (416,'LLAPO',27),
 (417,'PALLASCA',27),
 (418,'PAMPAS',27),
 (419,'SANTA ROSA',27),
 (420,'TAUCA',27),
 (421,'ANCO-HUALLO',28),
 (422,'CHINCHEROS',28),
 (423,'COCHARCAS',28),
 (424,'HUACCANA',28),
 (425,'OCOBAMBA',28),
 (426,'ONGOY',28),
 (427,'RANRACANCHA',28),
 (428,'URANMARCA',28),
 (429,'ANDAHUAYLAS',29),
 (430,'ANDARAPA',29),
 (431,'CHIARA',29),
 (432,'HUANCARAMA',29),
 (433,'HUANCARAY',29),
 (434,'HUAYANA',29),
 (435,'KAQUIABAMBA',29),
 (436,'KISHUARA',29),
 (437,'PACOBAMBA',29),
 (438,'PACUCHA',29),
 (439,'PAMPACHIRI',29),
 (440,'POMACOCHA',29),
 (441,'SAN ANTONIO DE CACHI',29),
 (442,'SAN JERONIMO',29),
 (443,'SAN MIGUEL DE CHACCRAMPA',29),
 (444,'SANTA MARIA DE CHICMO',29),
 (445,'TALAVERA',29),
 (446,'TUMAY HUARACA',29),
 (447,'TURPO',29),
 (448,'ABANCAY',30),
 (449,'CHACOCHE',30),
 (450,'CIRCA',30),
 (451,'CURAHUASI',30),
 (452,'HUANIPACA',30),
 (453,'LAMBRAMA',30),
 (454,'PICHIRHUA',30),
 (455,'SAN PEDRO DE CACHORA',30),
 (456,'TAMBURCO',30),
 (457,'CAPAYA',31),
 (458,'CARAYBAMBA',31),
 (459,'CHALHUANCA',31),
 (460,'CHAPIMARCA',31),
 (461,'COLCABAMBA',31),
 (462,'COTARUSE',31),
 (463,'HUAYLLO',31),
 (464,'JUSTO APU SAHUARAURA',31),
 (465,'LUCRE',31),
 (466,'POCOHUANCA',31),
 (467,'SAÃ‘AYCA',31),
 (468,'SAN JUAN DE CHACÃ‘A',31),
 (469,'SORAYA',31),
 (470,'TAPAIRIHUA',31),
 (471,'TINTAY',31),
 (472,'TORAYA',31),
 (473,'YANACA',31),
 (474,'ANTABAMBA',32),
 (475,'EL ORO',32),
 (476,'HUAQUIRCA',32),
 (477,'JUAN ESPINOZA MEDRANO',32),
 (478,'OROPESA',32),
 (479,'PACHACONAS',32),
 (480,'SABAINO',32),
 (481,'CHUQUIBAMBILLA',33),
 (482,'CURASCO',33),
 (483,'CURPAHUASI',33),
 (484,'GAMARRA',33),
 (485,'HUAYLLATI',33),
 (486,'MAMARA',33),
 (487,'MICAELA BASTIDAS',33),
 (488,'PATAYPAMPA',33),
 (489,'PROGRESO',33),
 (490,'SAN ANTONIO',33),
 (491,'SANTA ROSA',33),
 (492,'TURPAY',33),
 (493,'VILCABAMBA',33),
 (494,'VIRUNDO',33),
 (495,'CHALLHUAHUACHO',34),
 (496,'COTABAMBAS',34),
 (497,'COYLLURQUI',34),
 (498,'HAQUIRA',34),
 (499,'MARA',34),
 (500,'TAMBOBAMBA',34),
 (501,'ACARI',35),
 (502,'ATICO',35),
 (503,'ATIQUIPA',35),
 (504,'BELLA UNIO',35),
 (505,'CAHUACHO',35),
 (506,'CARAVELI',35),
 (507,'CHALA',35),
 (508,'CHAPARRA',35),
 (509,'HUANUHUANU',35),
 (510,'JAQUI',35),
 (511,'LOMAS',35),
 (512,'QUICACHA',35),
 (513,'YAUCA',35),
 (514,'ALCA',36),
 (515,'CHARCANA',36),
 (516,'COTAHUASI',36),
 (517,'HUAYNACOTAS',36),
 (518,'PAMPAMARCA',36),
 (519,'PUYCA',36),
 (520,'QUECHUALLA',36),
 (521,'SAYLA',36),
 (522,'TAURIA',36),
 (523,'TOMEPAMPA',36),
 (524,'TORO',36),
 (525,'ANDARAY',37),
 (526,'CAYARANI',37),
 (527,'CHICHAS',37),
 (528,'CHUQUIBAMBA',37),
 (529,'IRAY',37),
 (530,'RIO GRANDE',37),
 (531,'SALAMANCA',37),
 (532,'YANAQUIHUA',37),
 (533,'ANDAGUA',38),
 (534,'APLAO',38),
 (535,'AYO',38),
 (536,'CHACHAS',38),
 (537,'CHILCAYMARCA',38),
 (538,'CHOCO',38),
 (539,'HUANCARQUI',38),
 (540,'MACHAGUAY',38),
 (541,'ORCOPAMPA',38),
 (542,'PAMPACOLCA',38),
 (543,'TIPA',38),
 (544,'UÃ‘O',38),
 (545,'URACA',38),
 (546,'VIRACO',38),
 (547,'ACHOMA',39),
 (548,'CABANACONDE',39),
 (549,'CALLALLI',39),
 (550,'CAYLLOMA',39),
 (551,'CHIVAY',39),
 (552,'COPORAQUE',39),
 (553,'HUAMBO',39),
 (554,'HUANCA',39),
 (555,'ICHUPAMPA',39),
 (556,'LARI',39),
 (557,'LLUTA',39),
 (558,'MACA',39),
 (559,'MADRIGAL',39),
 (560,'MAJES',39),
 (561,'SAN ANTONIO DE CHUCA',39),
 (562,'SIBAYO',39),
 (563,'TAPAY',39),
 (564,'TISCO',39),
 (565,'TUTI',39),
 (566,'YANQUE',39),
 (567,'ALTO SELVA ALEGRE',40),
 (568,'AREQUIPA',40),
 (569,'CAYMA',40),
 (570,'CERRO COLORADO',40),
 (571,'CHARACATO',40),
 (572,'CHIGUATA',40),
 (573,'JACOBO HUNTER',40),
 (574,'JOSE LUIS BUSTAMANTE Y RIVE',40),
 (575,'LA JOYA',40),
 (576,'MARIANO MELGAR',40),
 (577,'MIRAFLORES',40),
 (578,'MOLLEBAYA',40),
 (579,'PAUCARPATA',40),
 (580,'POCSI',40),
 (581,'POLOBAYA',40),
 (582,'QUEQUEÃ‘A',40),
 (583,'SABANDIA',40),
 (584,'SACHACA',40),
 (585,'SAN JUAN DE SIGUAS',40),
 (586,'SAN JUAN DE TARUCANI',40),
 (587,'SANTA ISABEL DE SIGUAS',40),
 (588,'SANTA RITA DE SIGUAS',40),
 (589,'SOCABAYA',40),
 (590,'TIABAYA',40),
 (591,'UCHUMAYO',40),
 (592,'VITOR',40),
 (593,'YANAHUARA',40),
 (594,'YARABAMBA',40),
 (595,'YURA',40),
 (596,'COCACHACRA',41),
 (597,'DEAN VALDIVIA',41),
 (598,'ISLAY',41),
 (599,'MEJIA',41),
 (600,'MOLLENDO',41),
 (601,'PUNTA DE BOMBO',41),
 (602,'CAMANA',42),
 (603,'JOSE MARIA QUIMPER',42),
 (604,'MARIANO NICOLAS VALCARCEL',42),
 (605,'MARISCAL CACERES',42),
 (606,'NICOLAS DE PIEROLA',42),
 (607,'OCOÃ‘A',42),
 (608,'QUILCA',42),
 (609,'SAMUEL PASTOR',42),
 (610,'AYAHUANCO',43),
 (611,'HUAMANGUILLA',43),
 (612,'HUANTA',43),
 (613,'IGUAI',43),
 (614,'LLOCHEGUA',43),
 (615,'LURICOCHA',43),
 (616,'SANTILLANA',43),
 (617,'SIVIA',43),
 (618,'ACOCRO',44),
 (619,'ACOS VINCHOS',44),
 (620,'AYACUCHO',44),
 (621,'CARMEN ALTO',44),
 (622,'CHIARA',44),
 (623,'JESUS NAZARENO',44),
 (624,'OCROS',44),
 (625,'PACAYCASA',44),
 (626,'QUINUA',44),
 (627,'SAN JOSE DE TICLLAS',44),
 (628,'SAN JUAN BAUTISTA',44),
 (629,'SANTIAGO DE PISCHA',44),
 (630,'SOCOS',44),
 (631,'TAMBILLO',44),
 (632,'VINCHOS',44),
 (633,'CANGALLO',45),
 (634,'CHUSCHI',45),
 (635,'LOS MOROCHUCOS',45),
 (636,'MARIA PARADO DE BELLIDO',45),
 (637,'PARAS',45),
 (638,'TOTOS',45),
 (639,'ACCOMARCA',46),
 (640,'CARHUANCA',46),
 (641,'CONCEPCIO',46),
 (642,'HUAMBALPA',46),
 (643,'INDEPENDENCIA',46),
 (644,'SAURAMA',46),
 (645,'VILCAS HUAMA',46),
 (646,'VISCHONGO',46),
 (647,'ALCAMENCA',47),
 (648,'APONGO',47),
 (649,'ASQUIPATA',47),
 (650,'CANARIA',47),
 (651,'CAYARA',47),
 (652,'COLCA',47),
 (653,'HUAMANQUIQUIA',47),
 (654,'HUANCAPI',47),
 (655,'HUANCARAYLLA',47),
 (656,'HUAYA',47),
 (657,'SARHUA',47),
 (658,'VILCANCHOS',47),
 (659,'ANCO',48),
 (660,'AYNA',48),
 (661,'CHILCAS',48),
 (662,'CHUNGUI',48),
 (663,'LUIS CARRANZA',48),
 (664,'SAN MIGUEL',48),
 (665,'SANTA ROSA',48),
 (666,'TAMBO',48),
 (667,'CARAPO',49),
 (668,'SACSAMARCA',49),
 (669,'SANCOS',49),
 (670,'SANTIAGO DE LUCANAMARCA',49),
 (671,'BELE',50),
 (672,'CHALCOS',50),
 (673,'CHILCAYOC',50),
 (674,'HUACAÃ‘A',50),
 (675,'MORCOLLA',50),
 (676,'PAICO',50),
 (677,'QUEROBAMBA',50),
 (678,'SAN PEDRO DE LARCAY',50),
 (679,'SAN SALVADOR DE QUIJE',50),
 (680,'SANTIAGO DE PAUCARAY',50),
 (681,'SORAS',50),
 (682,'COLTA',51),
 (683,'CORCULLA',51),
 (684,'LAMPA',51),
 (685,'MARCABAMBA',51),
 (686,'OYOLO',51),
 (687,'PARARCA',51),
 (688,'PAUSA',51),
 (689,'SAN JAVIER DE ALPABAMBA',51),
 (690,'SAN JOSE DE USHUA',51),
 (691,'SARA SARA',51),
 (692,'CHUMPI',52),
 (693,'CORACORA',52),
 (694,'CORONEL CASTAÃ‘EDA',52),
 (695,'PACAPAUSA',52),
 (696,'PULLO',52),
 (697,'PUYUSCA',52),
 (698,'SAN FRANCISCO DE RAVACAYCO',52),
 (699,'UPAHUACHO',52),
 (700,'AUCARA',53),
 (701,'CABANA',53),
 (702,'CARMEN SALCEDO',53),
 (703,'CHAVIÃ‘A',53),
 (704,'CHIPAO',53),
 (705,'HUAC-HUAS',53),
 (706,'LARAMATE',53),
 (707,'LEONCIO PRADO',53),
 (708,'LLAUTA',53),
 (709,'LUCANAS',53),
 (710,'OCAÃ‘A',53),
 (711,'OTOCA',53),
 (712,'PUQUIO',53),
 (713,'SAISA',53),
 (714,'SAN CRISTOBAL',53),
 (715,'SAN JUA',53),
 (716,'SAN PEDRO',53),
 (717,'SAN PEDRO DE PALCO',53),
 (718,'SANCOS',53),
 (719,'SANTA ANA DE HUAYCAHUACHO',53),
 (720,'SANTA LUCIA',53),
 (721,'ASUNCIO',54),
 (722,'CAJAMARCA',54),
 (723,'CHETILLA',54),
 (724,'COSPA',54),
 (725,'ENCAÃ‘ADA',54),
 (726,'JESUS',54),
 (727,'LLACANORA',54),
 (728,'LOS BAÃ‘OS DEL INCA',54),
 (729,'MAGDALENA',54),
 (730,'MATARA',54),
 (731,'NAMORA',54),
 (732,'SAN JUA',54),
 (733,'CACHACHI',55),
 (734,'CAJABAMBA',55),
 (735,'CONDEBAMBA',55),
 (736,'SITACOCHA',55),
 (737,'CHANCAY',56),
 (738,'EDUARDO VILLANUEVA',56),
 (739,'GREGORIO PITA',56),
 (740,'ICHOCA',56),
 (741,'JOSE MANUEL QUIROZ',56),
 (742,'JOSE SABOGAL',56),
 (743,'PEDRO GALVEZ',56),
 (744,'BELLAVISTA',57),
 (745,'CHONTALI',57),
 (746,'COLASAY',57),
 (747,'HUABAL',57),
 (748,'JAE',57),
 (749,'LAS PIRIAS',57),
 (750,'POMAHUACA',57),
 (751,'PUCARA',57),
 (752,'SALLIQUE',57),
 (753,'SAN FELIPE',57),
 (754,'SAN JOSE DEL ALTO',57),
 (755,'SANTA ROSA',57),
 (756,'CHIRINOS',58),
 (757,'HUARANGO',58),
 (758,'LA COIPA',58),
 (759,'NAMBALLE',58),
 (760,'SAN IGNACIO',58),
 (761,'SAN JOSE DE LOURDES',58),
 (762,'TABACONAS',58),
 (763,'CHILETE',59),
 (764,'CONTUMAZA',59),
 (765,'CUPISNIQUE',59),
 (766,'GUZMANGO',59),
 (767,'SAN BENITO',59),
 (768,'SANTA CRUZ DE TOLED',59),
 (769,'TANTARICA',59),
 (770,'YONA',59),
 (771,'SAN BERNARDINO',60),
 (772,'SAN LUIS',60),
 (773,'SAN PABLO',60),
 (774,'TUMBADE',60),
 (775,'BOLIVAR',61),
 (776,'CALQUIS',61),
 (777,'CATILLUC',61),
 (778,'EL PRADO',61),
 (779,'LA FLORIDA',61),
 (780,'LLAPA',61),
 (781,'NANCHOC',61),
 (782,'NIEPOS',61),
 (783,'SAN GREGORIO',61),
 (784,'SAN MIGUEL',61),
 (785,'SAN SILVESTRE DE COCHA',61),
 (786,'TONGOD',61),
 (787,'UNION AGUA BLANCA',61),
 (788,'ANDABAMBA',62),
 (789,'CATACHE',62),
 (790,'CHANCAYBAÃ‘OS',62),
 (791,'LA ESPERANZA',62),
 (792,'NINABAMBA',62),
 (793,'PULA',62),
 (794,'SANTA CRUZ',62),
 (795,'SAUCEPAMPA',62),
 (796,'SEXI',62),
 (797,'UTICYACU',62),
 (798,'YAUYUCA',62),
 (799,'CELENDI',63),
 (800,'CHUMUCH',63),
 (801,'CORTEGANA',63),
 (802,'HUASMI',63),
 (803,'JORGE CHAVEZ',63),
 (804,'JOSE GALVEZ',63),
 (805,'LA LIBERTAD DE PALLA',63),
 (806,'MIGUEL IGLESIAS',63),
 (807,'OXAMARCA',63),
 (808,'SOROCHUCO',63),
 (809,'SUCRE',63),
 (810,'UTCO',63),
 (811,'ANGUIA',64),
 (812,'CHADI',64),
 (813,'CHALAMARCA',64),
 (814,'CHIGUIRIP',64),
 (815,'CHIMBA',64),
 (816,'CHOROPAMPA',64),
 (817,'CHOTA',64),
 (818,'COCHABAMBA',64),
 (819,'CONCHA',64),
 (820,'HUAMBOS',64),
 (821,'LAJAS',64),
 (822,'LLAMA',64),
 (823,'MIRACOSTA',64),
 (824,'PACCHA',64),
 (825,'PIO',64),
 (826,'QUEROCOTO',64),
 (827,'SAN JUAN DE LICUPIS',64),
 (828,'TACABAMBA',64),
 (829,'TOCMOCHE',64),
 (830,'BAMBAMARCA',65),
 (831,'CHUGUR',65),
 (832,'HUALGAYOC',65);
/*!40000 ALTER TABLE `distrito` ENABLE KEYS */;


--
-- Definition of table `forma_pago`
--

DROP TABLE IF EXISTS `forma_pago`;
CREATE TABLE `forma_pago` (
  `id_forma_pago` int(11) NOT NULL auto_increment,
  `nombre` varchar(30) NOT NULL,
  `descripcion` varchar(45) NOT NULL,
  PRIMARY KEY  (`id_forma_pago`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `forma_pago`
--

/*!40000 ALTER TABLE `forma_pago` DISABLE KEYS */;
INSERT INTO `forma_pago` (`id_forma_pago`,`nombre`,`descripcion`) VALUES 
 (1,'contado','efectivo');
/*!40000 ALTER TABLE `forma_pago` ENABLE KEYS */;


--
-- Definition of table `linea`
--

DROP TABLE IF EXISTS `linea`;
CREATE TABLE `linea` (
  `id_linea` int(11) NOT NULL auto_increment,
  `nombre` varchar(30) NOT NULL,
  PRIMARY KEY  (`id_linea`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `linea`
--

/*!40000 ALTER TABLE `linea` DISABLE KEYS */;
INSERT INTO `linea` (`id_linea`,`nombre`) VALUES 
 (0,''),
 (1,'CALZADO'),
 (2,'ROPA'),
 (3,'ACCESORIOS'),
 (4,'CARTERAS'),
 (5,'MALETINES'),
 (6,'sadsad'),
 (10,'JAJAJAJA');
/*!40000 ALTER TABLE `linea` ENABLE KEYS */;


--
-- Definition of table `marca`
--

DROP TABLE IF EXISTS `marca`;
CREATE TABLE `marca` (
  `id_marca` int(11) NOT NULL auto_increment,
  `nombre` varchar(30) NOT NULL,
  PRIMARY KEY  (`id_marca`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `marca`
--

/*!40000 ALTER TABLE `marca` DISABLE KEYS */;
INSERT INTO `marca` (`id_marca`,`nombre`) VALUES 
 (0,''),
 (1,'BILLABONG'),
 (2,'UMBRO'),
 (3,'ARENA'),
 (4,'PUMA'),
 (5,'JEANS'),
 (6,'RIP CURL'),
 (8,'KARPATOS'),
 (9,'PRADA'),
 (10,'CHANNEL'),
 (11,'LV'),
 (12,'TOUS'),
 (13,'BALLY'),
 (14,'BUFFALO'),
 (15,'CAT'),
 (16,'ETNIES'),
 (17,'NIKE'),
 (18,'ADIDAS'),
 (19,'YOMAS'),
 (20,'KANSAS'),
 (21,'SKATE'),
 (22,'CALIMOD'),
 (23,'TODS'),
 (24,'BURBERRY'),
 (25,'FROU FROU'),
 (26,'ANCACO'),
 (34,'asdas'),
 (35,'CIRCA'),
 (36,'aaaa');
/*!40000 ALTER TABLE `marca` ENABLE KEYS */;


--
-- Definition of table `modelo`
--

DROP TABLE IF EXISTS `modelo`;
CREATE TABLE `modelo` (
  `id_modelo` int(11) NOT NULL auto_increment,
  `nombre` varchar(30) NOT NULL,
  `id_categoria` int(11) default NULL,
  PRIMARY KEY  (`id_modelo`),
  KEY `FK_MODELO01` (`id_categoria`),
  CONSTRAINT `FK_MODELO01` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id_categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `modelo`
--

/*!40000 ALTER TABLE `modelo` DISABLE KEYS */;
INSERT INTO `modelo` (`id_modelo`,`nombre`,`id_categoria`) VALUES 
 (0,'',0),
 (1,'modelo 1',1),
 (2,'modelo 2',2),
 (6,'modelo 32',44),
 (11,'hhhhhhh',49),
 (18,'renuev',7),
 (19,'modelo 33',4),
 (20,'evolution',2),
 (21,'achill classic',2),
 (22,'shox',2),
 (23,'modelo 2012',2),
 (25,'TITAN',2),
 (26,'evolution 3',2),
 (27,'RELEASE',7),
 (29,'NUEVO',6);
/*!40000 ALTER TABLE `modelo` ENABLE KEYS */;


--
-- Definition of table `personal`
--

DROP TABLE IF EXISTS `personal`;
CREATE TABLE `personal` (
  `id_personal` int(11) NOT NULL,
  `nombres` varchar(50) NOT NULL,
  `apellidos` varchar(50) NOT NULL,
  `id_distrito` int(11) NOT NULL,
  `direccion` varchar(50) NOT NULL,
  `sexo` char(2) NOT NULL,
  `Telefono` int(8) unsigned NOT NULL,
  `Celular` int(9) unsigned NOT NULL,
  `email` varchar(70) NOT NULL,
  `clave` varchar(16) NOT NULL,
  `id_tipo_personal` int(2) unsigned NOT NULL,
  PRIMARY KEY  (`id_personal`),
  KEY `FK_PERSONAL01` (`id_distrito`),
  KEY `FK_personal_2` (`id_tipo_personal`),
  CONSTRAINT `FK_PERSONAL01` FOREIGN KEY (`id_distrito`) REFERENCES `distrito` (`id_distrito`),
  CONSTRAINT `FK_personal_2` FOREIGN KEY (`id_tipo_personal`) REFERENCES `tipo_personal` (`id_tipo_personal`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `personal`
--

/*!40000 ALTER TABLE `personal` DISABLE KEYS */;
INSERT INTO `personal` (`id_personal`,`nombres`,`apellidos`,`id_distrito`,`direccion`,`sexo`,`Telefono`,`Celular`,`email`,`clave`,`id_tipo_personal`) VALUES 
 (0,'SAD','SAD',0,'SD','M',2321,213,'','',2),
 (23,'asd2','asds',17,'aasd','M',23,232,'ad','231',1),
 (332,'sad333','asd',20,'asd','M',23,23,'asd','asd',1),
 (555,'sad','sad',20,'asd','F',23,23,'asd','asd',2),
 (2334,'asd','asd',21,'asd','M',23,23,'asd2','',1),
 (45332211,'JOSE','PEREZ SOLANO',1,'AV DOMINGO COLOMA 444','M',2325544,992123344,'','',2),
 (46606801,'','',1,'','M',232,23,'sd','juancaxd',2);
/*!40000 ALTER TABLE `personal` ENABLE KEYS */;


--
-- Definition of table `producto`
--

DROP TABLE IF EXISTS `producto`;
CREATE TABLE `producto` (
  `id_producto` int(11) NOT NULL auto_increment,
  `id_marca` int(11) NOT NULL,
  `id_color` int(11) NOT NULL,
  `id_talla` int(11) NOT NULL,
  `precio_venta` decimal(6,2) NOT NULL,
  `stock` int(10) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  `id_modelo` int(11) NOT NULL,
  `id_unidad` int(11) NOT NULL,
  `ruta_imagen` varchar(300) default NULL,
  PRIMARY KEY  (`id_producto`),
  KEY `FK_PRODUCTO03` (`id_marca`),
  KEY `FK_PRODUCTO04` (`id_color`),
  KEY `FK_PRODUCTO05` (`id_talla`),
  KEY `FK_PRODUCTO06` (`id_categoria`),
  KEY `FK_PRODUCTO07` (`id_modelo`),
  KEY `FK_PRODUCTO08` (`id_unidad`),
  CONSTRAINT `FK_PRODUCTO03` FOREIGN KEY (`id_marca`) REFERENCES `marca` (`id_marca`),
  CONSTRAINT `FK_PRODUCTO04` FOREIGN KEY (`id_color`) REFERENCES `color` (`id_color`),
  CONSTRAINT `FK_PRODUCTO05` FOREIGN KEY (`id_talla`) REFERENCES `talla` (`id_talla`),
  CONSTRAINT `FK_PRODUCTO06` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id_categoria`),
  CONSTRAINT `FK_PRODUCTO07` FOREIGN KEY (`id_modelo`) REFERENCES `modelo` (`id_modelo`),
  CONSTRAINT `FK_PRODUCTO08` FOREIGN KEY (`id_unidad`) REFERENCES `unidad` (`id_unidad`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `producto`
--

/*!40000 ALTER TABLE `producto` DISABLE KEYS */;
INSERT INTO `producto` (`id_producto`,`id_marca`,`id_color`,`id_talla`,`precio_venta`,`stock`,`id_categoria`,`id_modelo`,`id_unidad`,`ruta_imagen`) VALUES 
 (1,4,16,2,'140.50',54,2,2,1,'zapatillas-adidas.png'),
 (2,2,2,2,'150.00',24,2,2,1,'2.png'),
 (3,1,2,2,'154.00',37,2,2,1,'puma-suede-zapatillas-urbano_MPE-O-18232194_941.jpg'),
 (4,1,1,2,'122.50',20,2,2,1,'12470_CCAQ.jpg'),
 (5,6,12,23,'123.00',0,7,18,2,''),
 (6,4,26,2,'120.00',10,2,20,1,'puma-suede-zapatillas-urbano_MPE-O-18232194_941.jpg'),
 (7,18,12,2,'122.10',2,2,21,1,'1.jpg'),
 (8,17,6,2,'100.50',3,2,22,1,'nike-shox-para-varones_MPE-O-2902350393_072012.jpg'),
 (11,2,11,2,'110.00',4,2,26,1,'13500_TURQ.jpg'),
 (12,13,18,1,'32.00',4,1,1,2,''),
 (13,6,12,23,'88.10',10,7,27,4,'pantalon-release-rip-curl-nino.jpg'),
 (15,35,12,26,'25.00',10,6,29,2,'');
/*!40000 ALTER TABLE `producto` ENABLE KEYS */;


--
-- Definition of table `proveedor`
--

DROP TABLE IF EXISTS `proveedor`;
CREATE TABLE `proveedor` (
  `id_proveedor` int(11) NOT NULL auto_increment,
  `nombres` varchar(50) NOT NULL,
  `apellidos` varchar(50) NOT NULL,
  `ruc` varchar(50) NOT NULL,
  `id_distrito` int(11) NOT NULL,
  `razon_social` varchar(75) NOT NULL,
  `direccion` varchar(50) NOT NULL,
  `telefono` varchar(12) NOT NULL,
  `celular` varchar(12) NOT NULL,
  `rpm` varchar(10) NOT NULL,
  `email` varchar(45) NOT NULL,
  `fax` varchar(13) NOT NULL,
  `estado` decimal(1,0) NOT NULL,
  PRIMARY KEY  (`id_proveedor`),
  KEY `FK_PROVEEDOR01` (`id_distrito`),
  CONSTRAINT `FK_PROVEEDOR01` FOREIGN KEY (`id_distrito`) REFERENCES `distrito` (`id_distrito`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `proveedor`
--

/*!40000 ALTER TABLE `proveedor` DISABLE KEYS */;
INSERT INTO `proveedor` (`id_proveedor`,`nombres`,`apellidos`,`ruc`,`id_distrito`,`razon_social`,`direccion`,`telefono`,`celular`,`rpm`,`email`,`fax`,`estado`) VALUES 
 (1,'Jose Luis','Ramirez Diaz','1046512916',1,'CALZADOS YY','Av. las delicias #121','2324444','2233111','777667','Juan_123@hotmail.com','333333','1'),
 (2,'Jorge','Mendez Diaz','12333333',1,'CALZADOS XX22','Av. Domingo Coloma # 222','222222','222222','2321323','sadsa@hotmail.com','233333','1'),
 (6,'Luis','MORALES LEON','213213213',15,'CALZADOS MORALES','PROLG. LEONCIO PRADO SN','2325555','999999999','99999888','JCMLEON@HOTMAIL.COM','232132323','1');
/*!40000 ALTER TABLE `proveedor` ENABLE KEYS */;


--
-- Definition of table `proveedorproducto`
--

DROP TABLE IF EXISTS `proveedorproducto`;
CREATE TABLE `proveedorproducto` (
  `id_proveedorproducto` int(11) NOT NULL auto_increment,
  `id_proveedor` int(11) NOT NULL,
  `id_producto` int(11) NOT NULL,
  `precio_compra` decimal(6,2) default NULL,
  PRIMARY KEY  (`id_proveedorproducto`),
  KEY `fkid_proveedor` (`id_proveedor`),
  KEY `fkid_producto` (`id_producto`),
  CONSTRAINT `fkid_producto` FOREIGN KEY (`id_producto`) REFERENCES `producto` (`id_producto`),
  CONSTRAINT `fkid_proveedor` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedor` (`id_proveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `proveedorproducto`
--

/*!40000 ALTER TABLE `proveedorproducto` DISABLE KEYS */;
INSERT INTO `proveedorproducto` (`id_proveedorproducto`,`id_proveedor`,`id_producto`,`precio_compra`) VALUES 
 (1,1,1,'110.50'),
 (2,1,2,'120.45'),
 (5,2,1,'109.99'),
 (6,6,4,'123.44'),
 (7,6,2,'123.00'),
 (8,6,1,'124.00'),
 (9,2,3,'111.00'),
 (12,6,3,'111.00'),
 (13,6,7,'105.50'),
 (14,6,11,'101.90');
/*!40000 ALTER TABLE `proveedorproducto` ENABLE KEYS */;


--
-- Definition of table `provincia`
--

DROP TABLE IF EXISTS `provincia`;
CREATE TABLE `provincia` (
  `id_provincia` int(10) unsigned NOT NULL,
  `provincia` varchar(150) default NULL,
  PRIMARY KEY  (`id_provincia`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `provincia`
--

/*!40000 ALTER TABLE `provincia` DISABLE KEYS */;
INSERT INTO `provincia` (`id_provincia`,`provincia`) VALUES 
 (0,NULL),
 (1,'CHACHAPOYAS'),
 (2,'RODRIGUEZ DE MENDOZA'),
 (3,'LUYA'),
 (4,'BONGARA'),
 (5,'UTCUBAMBA'),
 (6,'BAGUA'),
 (7,'CONDORCANQUI'),
 (8,'HUARAZ'),
 (9,'YUNGAY'),
 (10,'CARHUAZ'),
 (11,'HUAYLAS'),
 (12,'RECUAY'),
 (13,'AIJA'),
 (14,'POMABAMBA'),
 (15,'MARISCAL LUZURIAGA'),
 (16,'ASUNCION'),
 (17,'CARLOS FERMIN FITZCARRALD'),
 (18,'HUARI'),
 (19,'ANTONIO RAYMONDI'),
 (20,'OCROS'),
 (21,'BOLOGNESI'),
 (22,'SANTA'),
 (23,'CASMA'),
 (24,'HUARMEY'),
 (25,'SIHUAS'),
 (26,'CORONGO'),
 (27,'PALLASCA'),
 (28,'CHINCHEROS'),
 (29,'ANDAHUAYLAS'),
 (30,'ABANCAY'),
 (31,'AYMARAES'),
 (32,'ANTABAMBA'),
 (33,'GRAU'),
 (34,'COTABAMBAS'),
 (35,'CARAVELI'),
 (36,'LA UNION'),
 (37,'CONDESUYOS'),
 (38,'CASTILLA'),
 (39,'CAYLLOMA'),
 (40,'AREQUIPA'),
 (41,'ISLAY'),
 (42,'CAMANA'),
 (43,'HUANTA'),
 (44,'HUAMANGA'),
 (45,'CANGALLO'),
 (46,'VILCAS HUAMAN'),
 (47,'VICTOR FAJARDO'),
 (48,'LA MAR'),
 (49,'HUANCA SANCOS'),
 (50,'SUCRE'),
 (51,'PAUCAR DEL SARA SARA'),
 (52,'PARINACOCHAS'),
 (53,'LUCANAS'),
 (54,'CAJAMARCA'),
 (55,'CAJABAMBA'),
 (56,'SAN MARCOS'),
 (57,'JAEN'),
 (58,'SAN IGNACIO'),
 (59,'CONTUMAZA'),
 (60,'SAN PABLO'),
 (61,'SAN MIGUEL'),
 (62,'SANTA CRUZ'),
 (63,'CELEDIN'),
 (64,'CHOTA'),
 (65,'HUALGAYOC'),
 (66,'CUTERVO'),
 (67,'LA CONVENCION'),
 (68,'CALCA'),
 (69,'URUBAMBA'),
 (70,'PAUCARTAMBO'),
 (71,'ANTA'),
 (72,'CUSCO'),
 (73,'QUISPICANCHI'),
 (74,'PARURO'),
 (75,'ACOMAYO'),
 (76,'CANCHIS'),
 (77,'CHUMBIVILCAS'),
 (78,'CANAS'),
 (79,'ESPINAR'),
 (80,'HUANCAVELICA'),
 (81,'TAYACAJA'),
 (82,'ACOBAMBA'),
 (83,'ANGARES'),
 (84,'HUAYTARA'),
 (85,'CASTROVIRREYNA'),
 (86,'CHURCAMPA'),
 (87,'HUANUCO'),
 (88,'PACHITEA'),
 (89,'AMBO'),
 (90,'LEONCIO PRADO'),
 (91,'DOS DE MAYO'),
 (92,'HUAMALIES'),
 (93,'YAROWILCA'),
 (94,'LAURICOCHA'),
 (95,'MARAÃ‘ON'),
 (96,'HUACAYBAMBA'),
 (97,'PUERTO INCA'),
 (98,'CHINCHA'),
 (99,'ICA'),
 (100,'NAZCA'),
 (101,'PALPA'),
 (102,'PISCO'),
 (103,'CHANCHAMAYO'),
 (104,'CHUPACA'),
 (105,'CONCEPCION'),
 (106,'HUANCAYO'),
 (107,'JAUJA'),
 (108,'JUNIN'),
 (109,'SATIPO'),
 (110,'TARMA'),
 (111,'YAULI'),
 (112,'ASCOPE'),
 (113,'BOLIVAR'),
 (114,'CHEPEN'),
 (115,'GRAN CHIMU'),
 (116,'JULCAN'),
 (117,'OTUZCO'),
 (118,'PACASMAYO'),
 (119,'PATAZ'),
 (120,'SANCHEZ CARRION'),
 (121,'SANTIAGO DE CHUCO'),
 (122,'TRUJILLO'),
 (123,'VIRU'),
 (124,'CHICLAYO'),
 (125,'FERREÃ‘AFE'),
 (126,'LAMBAYEQUE'),
 (127,'ALTO AMAZONAS'),
 (128,'LORETO'),
 (129,'MARISCAL RAMON CASTILLA'),
 (130,'MAYNAS'),
 (131,'REQUENA'),
 (132,'UCAYALI'),
 (133,'MANU'),
 (134,'TAHUAMANU'),
 (135,'TAMBOPATA'),
 (136,'GENERAL SANCHEZ CERRO'),
 (137,'ILO'),
 (138,'MARISCAL NIETO'),
 (139,'DANIEL ALCIDES CARRION'),
 (140,'OXAPAMPA'),
 (141,'PASCO'),
 (142,'CONTRALMIRANTE VILLAR'),
 (143,'TUMBES'),
 (144,'ZARUMILLA'),
 (145,'AZANGARO'),
 (146,'CARABAYA'),
 (147,'CHUCUITO'),
 (148,'EL COLLAO'),
 (149,'HUANCANE'),
 (150,'LAMPA'),
 (151,'MELGAR'),
 (152,'MOHO'),
 (153,'PUNO'),
 (154,'SAN ANTONIO DE PUTINA'),
 (155,'SAN ROMAN'),
 (156,'SANDIA'),
 (157,'YUNGUYO'),
 (158,'BELLAVISTA'),
 (159,'EL DORADO'),
 (160,'HUALLAGA'),
 (161,'LAMAS'),
 (162,'MARISCAL CACERES'),
 (163,'MOYOBAMBA'),
 (164,'PICOTA'),
 (165,'RIOJA'),
 (166,'SAN MARTIN'),
 (167,'TOCACHE'),
 (168,'CANDARAVE'),
 (169,'JORGE BASADRE'),
 (170,'TACNA'),
 (171,'TARATA'),
 (172,'AYABACA'),
 (173,'HUANCABAMBA'),
 (174,'MORROPON'),
 (175,'PAITA'),
 (176,'PIURA'),
 (177,'SECHURA'),
 (178,'SULLANA'),
 (179,'TALARA'),
 (180,'ATALAYA'),
 (181,'CORONEL PORTILLO'),
 (182,'PADRE ABAD'),
 (183,'PURUS'),
 (184,'CAJATAMBO'),
 (185,'BARRANCA'),
 (186,'OYON'),
 (187,'HUAURA'),
 (188,'HUARAL'),
 (189,'CANTA'),
 (190,'LIMA'),
 (191,'HUAROCHIRI'),
 (192,'YAUYOS'),
 (193,'CAÑETE'),
 (194,'CALLAO');
/*!40000 ALTER TABLE `provincia` ENABLE KEYS */;


--
-- Definition of table `talla`
--

DROP TABLE IF EXISTS `talla`;
CREATE TABLE `talla` (
  `id_talla` int(11) NOT NULL auto_increment,
  `nombre` varchar(35) NOT NULL,
  `id_categoria` int(11) NOT NULL,
  PRIMARY KEY  (`id_talla`),
  KEY `FK_TALLA01` (`id_categoria`),
  CONSTRAINT `FK_TALLA01` FOREIGN KEY (`id_categoria`) REFERENCES `categoria` (`id_categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `talla`
--

/*!40000 ALTER TABLE `talla` DISABLE KEYS */;
INSERT INTO `talla` (`id_talla`,`nombre`,`id_categoria`) VALUES 
 (0,'',0),
 (1,'Talla 32',1),
 (2,'Talla 32',2),
 (5,'Talla 34',3),
 (6,'Talla 34',4),
 (7,'Talla 34',5),
 (8,'Talla 34',2),
 (9,'Talla 34',1),
 (10,'Talla 32',3),
 (11,'Talla 32',4),
 (12,'Talla 32',5),
 (13,'talla222',40),
 (15,'talla 20',5),
 (16,'ssssssss',1),
 (23,'Talla 34',7),
 (24,'Talla 42',2),
 (25,'Talla 38',2),
 (26,'M',6);
/*!40000 ALTER TABLE `talla` ENABLE KEYS */;


--
-- Definition of table `tipo_personal`
--

DROP TABLE IF EXISTS `tipo_personal`;
CREATE TABLE `tipo_personal` (
  `id_tipo_personal` int(2) unsigned NOT NULL auto_increment,
  `tipo_personal` varchar(30) NOT NULL,
  `descripcion` varchar(30) default NULL,
  PRIMARY KEY  (`id_tipo_personal`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tipo_personal`
--

/*!40000 ALTER TABLE `tipo_personal` DISABLE KEYS */;
INSERT INTO `tipo_personal` (`id_tipo_personal`,`tipo_personal`,`descripcion`) VALUES 
 (1,'Administrador',NULL),
 (2,'Vendedor',NULL),
 (3,'Almacenero',NULL);
/*!40000 ALTER TABLE `tipo_personal` ENABLE KEYS */;


--
-- Definition of table `tipo_recibo`
--

DROP TABLE IF EXISTS `tipo_recibo`;
CREATE TABLE `tipo_recibo` (
  `id_tipo_recibo` int(11) NOT NULL auto_increment,
  `nombre` varchar(30) NOT NULL,
  PRIMARY KEY  (`id_tipo_recibo`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tipo_recibo`
--

/*!40000 ALTER TABLE `tipo_recibo` DISABLE KEYS */;
INSERT INTO `tipo_recibo` (`id_tipo_recibo`,`nombre`) VALUES 
 (1,'boleta'),
 (2,'factura');
/*!40000 ALTER TABLE `tipo_recibo` ENABLE KEYS */;


--
-- Definition of table `unidad`
--

DROP TABLE IF EXISTS `unidad`;
CREATE TABLE `unidad` (
  `id_unidad` int(11) NOT NULL auto_increment,
  `nombre` varchar(30) default NULL,
  PRIMARY KEY  (`id_unidad`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `unidad`
--

/*!40000 ALTER TABLE `unidad` DISABLE KEYS */;
INSERT INTO `unidad` (`id_unidad`,`nombre`) VALUES 
 (0,''),
 (1,'CAJA'),
 (2,'BOLSA'),
 (4,'UND');
/*!40000 ALTER TABLE `unidad` ENABLE KEYS */;


--
-- Definition of table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL auto_increment,
  `nick` varchar(10) NOT NULL,
  `clave` varchar(55) NOT NULL,
  `fecha_creacion` datetime default NULL,
  `estado` decimal(1,0) NOT NULL,
  PRIMARY KEY  (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuario`
--

/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` (`id_usuario`,`nick`,`clave`,`fecha_creacion`,`estado`) VALUES 
 (1,'INF','juancaxd','2011-07-02 12:00:00','0'),
 (9,'JOSE123','JOSE12345','2011-08-10 09:04:03','1');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;


--
-- Definition of function `NMes`
--

DROP FUNCTION IF EXISTS `NMes`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` FUNCTION `NMes`(nameMes varchar(15)) RETURNS int(3)
BEGIN
CASE nameMes 
WHEN 'Enero' THEN RETURN 1;
WHEN 'Febrero' THEN return 2;
WHEN 'Marzo' then return 3;
WHEN 'Abril' then return 4;
WHEN 'Mayo' then return 5;
WHEN 'Junio' then return 6;
WHEN 'Julio' then return 7;
WHEN 'Agosto' then return 8;
WHEN 'Setiembre' then return 9;
WHEN 'Octubre' then return 10;
WHEN 'Noviembre' then return 11;
WHEN 'Diciembre' then return 12;
end case;
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRABMCategoria`
--

DROP PROCEDURE IF EXISTS `SPRABMCategoria`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRABMCategoria`(opcion int(2),id_categoria2 int(11),nombre2 varchar(30),id_linea2 int(11))
begin

case opcion
when 1 then
insert into categoria(nombre,id_linea)values(nombre2,id_linea2);
when 2 then 
update categoria set nombre=nombre2,id_linea=id_linea2 where id_categoria =id_categoria2;
when 3  then 
delete from categoria where id_categoria=id_categoria2;
end case;

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRABMClientes`
--

DROP PROCEDURE IF EXISTS `SPRABMClientes`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRABMClientes`(opcion int(2),id_cliente2 int(11),nombres2 varchar(50),apellidos2 varchar(50),id_distrito2 int(11),direccion2 varchar(50),dni2 varchar(8),ruc2 varchar(11),telefono2 varchar(8),celular2 varchar(9))
begin
case opcion
when 1 then
insert into cliente(nombres,apellidos,id_distrito,direccion,dni,ruc,telefono,celular)values(nombres2,apellidos2,id_distrito2,direccion2,dni2,ruc2,telefono2,celular2);
SELECT id_cliente as 'IdCliente' FROM cliente order by id_cliente desc LIMIT 1;
when 2 then
update cliente set nombres=nombres2,apellidos=apellidos2,id_distrito=id_distrito2,direccion=direccion2,dni=dni2,ruc=ruc2,telefono=telefono2,celular=celular2 where id_cliente =id_cliente2;
SELECT id_cliente as 'IdCliente' FROM cliente order by id_cliente desc LIMIT 1;
when 3  then
delete from cliente where id_cliente =id_cliente2;
SELECT id_cliente as 'IdCliente' FROM cliente order by id_cliente desc LIMIT 1;
end case;
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRABMColor`
--

DROP PROCEDURE IF EXISTS `SPRABMColor`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRABMColor`(opcion int(2),id_color2 int(11),nombre2 varchar(35))
begin

case opcion
when 1 then
insert into color(nombre)values(nombre2);
when 2 then 
update color set nombre=nombre2 where id_color =id_color2;
when 3  then 
delete from color where id_color =id_color2;
end case;

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRABMCompra`
--

DROP PROCEDURE IF EXISTS `SPRABMCompra`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRABMCompra`(opcion int(2),id_compra2 int(11),id_proveedor2 int(11),fecha_compra2 datetime,estado2 decimal(1,0),sub_total2 float,igv2 decimal(10,0),total2 float)
begin
case opcion
when 1 then
insert into compra(id_proveedor,fecha_compra,estado,sub_total,igv,total)values(id_proveedor2,fecha_compra2,estado2,sub_total2,igv2,total2);
when 2 then
update compra set id_proveedor=id_proveedor2,fecha_compra=fecha_compra2,estado=estado2,sub_total=sub_total2,igv=igv2,total=total2 where id_compra=id_compra2;
when 3  then 
delete from compra where id_compra =id_compra2;
end case;
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRABMDetalleCompra`
--

DROP PROCEDURE IF EXISTS `SPRABMDetalleCompra`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRABMDetalleCompra`(opcion int(2),id_detalle_compra_producto2 int(11),id_compra2 int(11),id_producto2 int(11),cantidad2 int(11),costo2 float)
begin
case opcion
when 1 then
insert into detalle_compra_producto(id_compra,id_producto,cantidad,costo)values(id_compra2,id_producto2,cantidad2,costo2);
when 2 then
update detalle_compra_producto set id_producto=id_producto2,cantidad=cantidad2,costo=costo2 where id_detalle_compra_producto =id_detalle_compra_producto2;
when 3  then 
delete from detalle_compra_producto where id_detalle_compra_producto =id_detalle_compra_producto2;
end case;
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRABMLinea`
--

DROP PROCEDURE IF EXISTS `SPRABMLinea`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRABMLinea`(opcion int(2),id_linea2 int(11),nombre2 varchar(30))
begin

case opcion
when 1 then
insert into linea(nombre)values(nombre2);
when 2 then 
update linea set nombre=nombre2 where id_linea =id_linea2;
when 3  then 
delete from linea where id_linea=id_linea2;
end case;

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRABMMarca`
--

DROP PROCEDURE IF EXISTS `SPRABMMarca`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRABMMarca`(opcion int(2),id_marca2 int(11),nombre2 varchar(30))
begin
case opcion
when 1 then
insert into marca(nombre)values(nombre2);
when 2 then 
update marca set nombre=nombre2 where id_marca =id_marca2;
when 3  then 
delete from marca where id_marca =id_marca2;
end case;

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRABMModelo`
--

DROP PROCEDURE IF EXISTS `SPRABMModelo`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRABMModelo`(opcion int(2),id_modelo2 int(11),nombre2 varchar(30),id_categoria2 int(11))
begin
case opcion
when 1 then
insert into modelo(nombre,id_categoria)values(nombre2,id_categoria2);
when 2 then 
update modelo set nombre=nombre2 where id_modelo =id_modelo2;
when 3  then 
delete from modelo where id_modelo=id_modelo2;
end case;

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRABMPersonal`
--

DROP PROCEDURE IF EXISTS `SPRABMPersonal`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRABMPersonal`(opcion int(2),id_personal2 int(11),nombres2 varchar(50),apellidos2 varchar(50),id_distrito2 int(11),direccion2 varchar(50),sexo2 char(2),telefono2 int(8),email2 varchar(70),celular2 int(9),clave2 varchar(16),id_tipo_personal2 int(2))
begin
case opcion
when 1 then
insert into personal values(id_personal2,nombres2,apellidos2,id_distrito2,direccion2,sexo2,telefono2,celular2,email2,clave2,id_tipo_personal2);
when 2 then
update personal set nombres=nombres2,apellidos=apellidos2,id_distrito=id_distrito2,direccion=direccion2,sexo=sexo2,email=email2,clave=clave2,id_tipo_personal=id_tipo_personal2,Telefono=telefono2,Celular=celular2 where id_personal =id_personal2;
when 3  then
delete from personal where id_personal=id_personal2;
end case;
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRABMProductoProveedor`
--

DROP PROCEDURE IF EXISTS `SPRABMProductoProveedor`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRABMProductoProveedor`(opcion int(2),id_proveedorproducto2 int(11),id_proveedor2 int(11),id_producto2 int(11),precio_compra2 decimal(6,2))
begin
case opcion
when 1 then
insert into proveedorproducto(id_proveedor,id_producto,precio_compra)values(id_proveedor2,id_producto2,precio_compra2);
when 2 then
update proveedorproducto set id_proveedor=id_proveedor2,id_producto=id_producto2,precio_compra=precio_compra2 where id_proveedorproducto=id_proveedorproducto2;
when 3  then 
delete from proveedorproducto where id_proveedorproducto =id_proveedorproducto2;
end case;
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRABMProductos`
--

DROP PROCEDURE IF EXISTS `SPRABMProductos`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRABMProductos`(opcion int(2),id_producto2 int(11),id_marca2 int(11),id_color2 int(11),id_talla2 int(11),precio2 decimal(6,2),stock2 int(10),id_categoria2 int(11),id_modelo2 int(11),id_unidad2 int(11),imagen varchar(300))
begin
case opcion
when 1 then
insert into producto(id_marca,id_color,id_talla,precio_venta,stock,id_categoria,id_modelo,id_unidad,ruta_imagen)values(id_marca2,id_color2,id_talla2,precio2,stock2,id_categoria2,id_modelo2,id_unidad2,imagen);
commit;
when 2 then
update producto set id_marca=id_marca2,id_color=id_color2,id_talla=id_talla2,precio_venta=precio2,stock=stock2,id_categoria=id_categoria2,id_modelo=id_modelo2,id_unidad=id_unidad2,ruta_imagen=imagen where id_producto =id_producto2;
commit;
when 3  then
delete from producto where id_producto =id_producto2;
commit;
end case;

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRABMProveedor`
--

DROP PROCEDURE IF EXISTS `SPRABMProveedor`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRABMProveedor`(opcion int(2),id_proveedor2 int(11),nombres2 varchar(50),apellidos2 varchar(50),ruc2 varchar(50),id_distrito2 int(11),razon_social2 varchar(75),direccion2 varchar(50),telefono2 varchar(12),celular2 varchar(12),rpm2 varchar(10),email2 varchar(45),fax2 varchar(13),estado2 decimal(1,0))
begin
case opcion
when 1 then
insert into proveedor(nombres,apellidos,ruc,id_distrito,razon_social,direccion,telefono,celular,rpm,email,fax,estado)values(nombres2,apellidos2,ruc2,id_distrito2,razon_social2,direccion2,telefono2,celular2,rpm2,email2,fax2,estado2);
when 2 then 
update proveedor set nombres=nombres2,apellidos=apellidos2,ruc=ruc2,id_distrito=id_distrito2,razon_social=razon_social2,direccion=direccion2,telefono=telefono2,celular=celular2,rpm=rpm2,email=email2,fax=fax2,estado=estado2 where id_proveedor =id_proveedor2;
when 3  then 
delete from proveedor where id_proveedor =id_proveedor2;
end case;

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRABMRol`
--

DROP PROCEDURE IF EXISTS `SPRABMRol`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRABMRol`(opcion int(2),id_rol2 int(11),nombre2 varchar(30),descripcion2 varchar(45))
begin
case opcion
when 1 then
insert into rol(nombre,descripcion)values(nombre2,descripcion2);
when 2 then 
update rol set nombre=nombre2,descripcion=descripcion2 where id_rol =id_rol2;
when 3  then 
delete from rol where id_rol =id_rol2;
end case;

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRABMTalla`
--

DROP PROCEDURE IF EXISTS `SPRABMTalla`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRABMTalla`(opcion int(2),id_talla2 int(11),nombre2 varchar(35),id_categoria2 int(11))
begin

case opcion
when 1 then
insert into talla(nombre,id_categoria)values(nombre2,id_categoria2);
when 2 then 
update talla set nombre=nombre2,id_categoria=id_categoria2 where id_talla =id_talla2;
when 3  then 
delete from talla where id_talla =id_talla2;
end case;

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRABMUnidad`
--

DROP PROCEDURE IF EXISTS `SPRABMUnidad`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRABMUnidad`(opcion int(2),id_unidad2 int(11),nombre2 varchar(30))
begin

case opcion
when 1 then
insert into unidad(nombre)values(nombre2);
when 2 then 
update unidad set nombre=nombre2 where id_unidad =id_unidad2;
when 3  then 
delete from unidad where id_unidad =id_unidad2;
end case;

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRABMUsuario`
--

DROP PROCEDURE IF EXISTS `SPRABMUsuario`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRABMUsuario`(opcion int(2),id_usuario2 int(11),nick2 varchar(10),clave2 varchar(55),fecha_creacion2 datetime,estado2 decimal(1,0))
begin
case opcion
when 1 then
insert into usuario(nick,clave,fecha_creacion,estado)values(nick2,clave2,fecha_creacion2,estado2);
when 2 then 
update usuario set nick=nick2,clave=clave2,fecha_creacion=fecha_creacion2,estado=estado2 where id_usuario =id_usuario2;
when 3  then 
delete from usuario where id_usuario =id_usuario2;
end case;

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRBuscarCliente`
--

DROP PROCEDURE IF EXISTS `SPRBuscarCliente`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRBuscarCliente`(apellido_cliente varchar(50))
begin

select cl.id_cliente,cl.nombres,cl.apellidos,dis.nombre,cl.direccion,cl.dni,cl.ruc,cl.telefono,cl.celular from cliente cl,distrito dis where cl.id_distrito = dis.id_distrito and cl.apellidos like concat(apellido_cliente,'%');

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRBuscarProductos`
--

DROP PROCEDURE IF EXISTS `SPRBuscarProductos`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRBuscarProductos`(DescripcionProducto varchar(500))
begin
select pr.id_producto as 'IdProducto',
 concat(cat.nombre,' ',pr.nombre,' ',mo.nombre,' ',mar.nombre,' ',co.nombre,' ',tal.nombre) as 'DescripcionProducto'
         ,pr.precio as 'Precio',
         pr.stock as 'Stock'
from producto pr,
       categoria cat,
        color co,
        modelo mo,
        talla tal, marca mar
      where pr.id_color = co.id_color and pr.id_categoria = cat.id_categoria and pr.id_talla = tal.id_talla
      and pr.id_modelo = mo.id_modelo and pr.id_marca = mar.id_marca and concat(cat.nombre,' ',pr.nombre,' ',mo.nombre,' ',mar.nombre,' ',co.nombre,' ',tal.nombre) like
      concat(DescripcionProducto,'%');

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSCategoria`
--

DROP PROCEDURE IF EXISTS `SPRCNSCategoria`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSCategoria`()
begin

select cat.id_categoria,cat.nombre,li.nombre as 'Linea' from categoria cat,linea li where cat.id_linea = li.id_linea order by cat.id_categoria;

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSColor`
--

DROP PROCEDURE IF EXISTS `SPRCNSColor`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSColor`()
begin

select * from color;

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSCompra`
--

DROP PROCEDURE IF EXISTS `SPRCNSCompra`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSCompra`(opcion int(2),dato varchar(11))
begin
case opcion
when 1 then
select com.id_compra,com.id_proveedor,pro.razon_social,pro.nombres,pro.apellidos,pro.ruc,pro.telefono,com.fecha_compra,com.sub_total,com.igv,com.total from compra com,proveedor pro where com.id_proveedor = pro.id_proveedor
and com.estado=0 and com.id_compra like concat(dato,'%');
when 2 then
select com.id_compra,com.id_proveedor,pro.nombres,pro.apellidos,com.fecha_compra,com.sub_total,com.igv,com.total from compra com,proveedor pro where com.id_proveedor = pro.id_proveedor
and com.estado=0 and Date(com.fecha_compra)=dato;
when 3 then
select com.id_compra,com.id_proveedor,pro.razon_social,pro.nombres,pro.apellidos,pro.ruc,pro.telefono,com.fecha_compra,com.sub_total,com.igv,com.total from compra com,proveedor pro where com.id_proveedor = pro.id_proveedor
and com.estado=0;
end case;
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSComprasxId`
--

DROP PROCEDURE IF EXISTS `SPRCNSComprasxId`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSComprasxId`(id_compra int(11))
begin
select com.id_compra,prov.id_proveedor,prov.nombres,prov.apellidos,prov.ruc,dis.nombre,prov.razon_social,prov.direccion,prov.telefono,prov.celular,prov.rpm,prov.email,prov.fax,com.fecha_compra,com.sub_total,com.igv,com.total,det.id_producto as 'Id',cat.nombre as 'Categoria',pro.nombre as 'NameProducto',mar.nombre as 'Marca',mo.nombre as 'Modelo',col.nombre as 'Color',tal.nombre as 'Talla',un.nombre as 'Unidad',pp.precio_compra as 'PCompra',det.cantidad,det.costo from compra com,detalle_compra_producto det,producto pro,categoria cat,marca mar,modelo mo,talla tal,distrito dis,
color col,unidad un,proveedor prov,proveedorproducto pp where det.id_compra = com.id_compra and det.id_producto = pro.id_producto 
and mo.id_modelo=pro.id_modelo
and pro.id_marca = mar.id_marca and pro.id_unidad = un.id_unidad and pro.id_categoria = cat.id_categoria and com.id_proveedor = prov.id_proveedor
and prov.id_distrito = dis.id_distrito and pp.id_proveedor = prov.id_proveedor and pro.id_talla=tal.id_talla and pro.id_color = col.id_color 
and pp.id_producto = pro.id_producto and com.id_compra=id_compra group by det.id_detalle_compra_producto;
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSDetalle_Compra`
--

DROP PROCEDURE IF EXISTS `SPRCNSDetalle_Compra`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSDetalle_Compra`(id_compra2 int(11),id_proveedor2 int(11))
begin

select det.id_detalle_compra_producto,det.id_producto,concat_ws(" ",ca.nombre,ma.nombre,mo.nombre,co.nombre,ta.nombre)as 'Descripcion',pp.precio_compra,det.cantidad,det.costo from detalle_compra_producto det,proveedorproducto pp,compra com,producto pro,categoria ca,marca ma,modelo mo,talla ta,color co where
pro.id_producto=det.id_producto and ca.id_categoria=pro.id_categoria and mo.id_modelo=pro.id_modelo and ma.id_marca=pro.id_marca and co.id_color=pro.id_color and ta.id_talla=pro.id_talla and det.id_compra = com.id_compra and pp.id_producto=det.id_producto and pp.id_producto=det.id_producto and pp.id_proveedor=id_proveedor2 and  det.id_compra=id_compra2;

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSDistrito`
--

DROP PROCEDURE IF EXISTS `SPRCNSDistrito`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSDistrito`(id_provincia2 int(10))
begin
select dis.id_distrito,dis.nombre from distrito dis,provincia pro where dis.id_provincia=pro.id_provincia and dis.id_provincia=id_provincia2;
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSEgresosAlmacen`
--

DROP PROCEDURE IF EXISTS `SPRCNSEgresosAlmacen`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSEgresosAlmacen`(opcion int(2),anio varchar(4))
begin
case opcion
when 1 then
select MONTHNAME(com.fecha_compra) as 'Descripcion',ROUND(SUM(com.total)) as 'Egreso'  from compra com where YEAR(com.fecha_compra)=anio and com.estado=1 group by MONTH(com.fecha_compra) order by MONTH(com.fecha_compra);
when 2 then
select cat.nombre as 'Descripcion',ROUND(SUM(det.costo+(0.18*det.costo))) as 'Egreso' from compra com,detalle_compra_producto det,categoria cat,producto pro where det.id_compra=com.id_compra 
and cat.id_categoria=pro.id_categoria and det.id_producto=pro.id_producto and YEAR(com.fecha_compra)=anio and com.estado=1 group by cat.nombre order by cat.nombre;
when 3 then
select mar.nombre as 'Descripcion',ROUND(SUM(det.costo+(0.18*det.costo))) as 'Egreso' from compra com,detalle_compra_producto det,marca mar,producto pro where det.id_compra=com.id_compra 
and pro.id_marca=mar.id_marca and det.id_producto=pro.id_producto and YEAR(com.fecha_compra)=anio and com.estado=1 group by mar.nombre order by mar.nombre;
when 4 then
select lin.nombre as 'Descripcion',ROUND(SUM(det.costo+(0.18*det.costo))) as 'Egreso' from compra com,detalle_compra_producto det,categoria cat,linea lin,producto pro where det.id_compra=com.id_compra 
and pro.id_categoria=cat.id_categoria and cat.id_linea=lin.id_linea and det.id_producto=pro.id_producto and YEAR(com.fecha_compra)=anio and com.estado=1 group by lin.nombre order by lin.nombre;
end case;
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSLinea`
--

DROP PROCEDURE IF EXISTS `SPRCNSLinea`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSLinea`()
begin

select * from linea;

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSMarca`
--

DROP PROCEDURE IF EXISTS `SPRCNSMarca`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSMarca`()
begin

select * from marca;

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSModelo`
--

DROP PROCEDURE IF EXISTS `SPRCNSModelo`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSModelo`(opcion int(2),dato int(2))
begin
case opcion
when 1 then
select mo.id_modelo,mo.nombre,cat.nombre as 'Categoria' from modelo mo,categoria cat where mo.id_categoria = cat.id_categoria;
when 2 then
select mo.id_modelo,mo.nombre,cat.nombre as 'Categoria' from categoria cat,modelo mo where cat.id_categoria=mo.id_categoria and mo.id_categoria=dato;
end case;
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSPersonal`
--

DROP PROCEDURE IF EXISTS `SPRCNSPersonal`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSPersonal`(opcion int(2),dato varchar(10))
begin
case opcion
when 1 then
select per.id_personal,per.nombres,per.apellidos,pro.provincia as 'provincia',dis.nombre as 'distrito',per.direccion,per.sexo,per.email,per.Telefono,per.Celular,tip.tipo_personal,per.clave
from personal per,distrito dis,tipo_personal tip,provincia pro where
per.id_distrito = dis.id_distrito and tip.id_tipo_personal=per.id_tipo_personal and dis.id_provincia=pro.id_provincia;
when 2  then
select per.id_personal,per.nombres,per.apellidos,dis.nombre,per.direccion,per.sexo,per.dni,per.ruc,r.nombre,per.persoTelefono,per.persoCelular,per.persoObservacion,us.nick 
from personal per,rol r,distrito dis,usuario us where per.id_rol = r.id_rol and
per.id_distrito = dis.id_distrito and per.id_usuario = us.id_usuario and us.nick=dato;
end case;
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSProductoProveedor`
--

DROP PROCEDURE IF EXISTS `SPRCNSProductoProveedor`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSProductoProveedor`(opcion int(2),id_proveedor2 int,dato varchar(50))
begin
case opcion
when 1 then
select pp.id_proveedorproducto, pro.id_producto,cat.nombre as 'Categoria',mar.nombre as 'Marca',mo.nombre as 'modelo',tal.nombre as 'Talla',co.nombre as 'Color',un.nombre as 'Unidad',pp.precio_compra as 'PCompra',pro.stock as 'Stock' from proveedorproducto pp,producto pro,marca mar,modelo mo,categoria cat,talla tal,unidad un,color co where
pp.id_producto = pro.id_producto and pro.id_categoria = cat.id_categoria and pro.id_color = co.id_color
and pro.id_marca = mar.id_marca and pro.id_modelo = mo.id_modelo and pro.id_talla = tal.id_talla and pro.id_unidad = un.id_unidad and pp.id_proveedor=id_proveedor2;
when 2 then
select pp.id_proveedorproducto, pro.id_producto,cat.nombre as 'Categoria',pro.nombre as 'Nombre',mar.nombre as 'Marca',mo.nombre as 'Modelo',tal.nombre as 'Talla',co.nombre as 'Color',un.nombre as 'Unidad',pp.precio_compra as 'PCompra',pro.stock as 'Stock'  from proveedorproducto pp,producto pro,marca mar,modelo mo,categoria cat,talla tal,unidad un,color co where
pp.id_producto = pro.id_producto and pro.id_categoria = cat.id_categoria and pro.id_color = co.id_color
and pro.id_marca = mar.id_marca and pro.id_modelo = mo.id_modelo and pro.id_talla = tal.id_talla and pro.id_unidad = un.id_unidad and  pp.id_proveedor=id_proveedor2 and pro.id_producto like concat(dato,'%') ;
when 3 then
select pp.id_proveedorproducto, pro.id_producto,cat.nombre,pro.nombre,mar.nombre,mo.nombre,tal.nombre,co.nombre,un.nombre,pp.precio_compra,pro.stock  from proveedorproducto pp,producto pro,marca mar,modelo mo,categoria cat,talla tal,unidad un,color co where
pp.id_producto = pro.id_producto and pro.id_categoria = cat.id_categoria and pro.id_color = co.id_color
and pro.id_marca = mar.id_marca and pro.id_modelo = mo.id_modelo and pro.id_talla = tal.id_talla and pro.id_unidad = un.id_unidad and  pp.id_proveedor=id_proveedor2 and pro.nombre like concat(dato,'%') ;
when 4 then
select pp.id_proveedorproducto, pro.id_producto,cat.nombre,pro.nombre,mar.nombre,mo.nombre,tal.nombre,co.nombre,un.nombre,pp.precio_compra,pro.stock  from proveedorproducto pp,producto pro,marca mar,modelo mo,categoria cat,talla tal,unidad un,color co where
pp.id_producto = pro.id_producto and pro.id_categoria = cat.id_categoria and pro.id_color = co.id_color
and pro.id_marca = mar.id_marca and pro.id_modelo = mo.id_modelo and pro.id_talla = tal.id_talla and pro.id_unidad = un.id_unidad and  pp.id_proveedor=id_proveedor2 and cat.nombre like concat(dato,'%') ;
when 5 then
select pp.id_proveedorproducto, pro.id_producto,cat.nombre,pro.nombre,mar.nombre,mo.nombre,tal.nombre,co.nombre,un.nombre,pp.precio_compra,pro.stock  from proveedorproducto pp,producto pro,marca mar,modelo mo,categoria cat,talla tal,unidad un,color co where
pp.id_producto = pro.id_producto and pro.id_categoria = cat.id_categoria and pro.id_color = co.id_color
and pro.id_marca = mar.id_marca and pro.id_modelo = mo.id_modelo and pro.id_talla = tal.id_talla and pro.id_unidad = un.id_unidad and  pp.id_proveedor=id_proveedor2 and mar.nombre like concat(dato,'%') ;
when 6 then
select pp.id_proveedorproducto, pro.id_producto,cat.nombre,pro.nombre,mar.nombre,mo.nombre,tal.nombre,co.nombre,un.nombre,pp.precio_compra,pro.stock  from proveedorproducto pp,producto pro,marca mar,modelo mo,categoria cat,talla tal,unidad un,color co where
pp.id_producto = pro.id_producto and pro.id_categoria = cat.id_categoria and pro.id_color = co.id_color
and pro.id_marca = mar.id_marca and pro.id_modelo = mo.id_modelo and pro.id_talla = tal.id_talla and pro.id_unidad = un.id_unidad and  pp.id_proveedor=id_proveedor2 and mo.nombre like concat(dato,'%') ;
end case;
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSProductos`
--

DROP PROCEDURE IF EXISTS `SPRCNSProductos`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSProductos`(opcion int(2),dato varchar(50))
begin
case opcion
when 1 then 
select pr.id_producto,cat.nombre as 'Linea',mo.nombre as 'Modelo',mar.nombre as 'Marca',co.nombre as 'Color',tal.nombre as 'Talla',un.nombre as 'Unidad',pr.precio_venta,pr.stock,pr.ruta_imagen
from producto pr,
       categoria cat,
        color co,
        modelo mo,
        talla tal, marca mar,unidad un
      where pr.id_color = co.id_color and pr.id_categoria = cat.id_categoria and pr.id_talla = tal.id_talla
      and pr.id_unidad=un.id_unidad and pr.id_modelo = mo.id_modelo and pr.id_marca = mar.id_marca;
when 2 then 
select pr.id_producto,cat.nombre,pr.nombre,mo.nombre,mar.nombre,co.nombre,tal.nombre,un.nombre,pr.precio_venta,pr.stock
from producto pr,
       categoria cat,
        color co,
        modelo mo,
        talla tal, marca mar,unidad un
      where pr.id_color = co.id_color and pr.id_categoria = cat.id_categoria and pr.id_talla = tal.id_talla
      and pr.id_unidad=un.id_unidad and pr.id_modelo = mo.id_modelo and pr.id_marca = mar.id_marca and pr.id_producto like concat(dato,'%') ;
  when 3 then 
  select pr.id_producto,cat.nombre,pr.nombre,mo.nombre,mar.nombre,co.nombre,tal.nombre,un.nombre,pr.precio_venta,pr.stock
from producto pr,
       categoria cat,
        color co,
        modelo mo,
        talla tal, marca mar,unidad un
      where pr.id_color = co.id_color and pr.id_categoria = cat.id_categoria and pr.id_talla = tal.id_talla
      and pr.id_unidad=un.id_unidad and pr.id_modelo = mo.id_modelo and pr.id_marca = mar.id_marca and pr.nombre like concat(dato,'%') ;
  when 4 then 
  select pr.id_producto,cat.nombre,pr.nombre,mo.nombre,mar.nombre,co.nombre,tal.nombre,un.nombre,pr.precio_venta,pr.stock
from producto pr,
       categoria cat,
        color co,
        modelo mo,
        talla tal, marca mar,unidad un
      where pr.id_color = co.id_color and pr.id_categoria = cat.id_categoria and pr.id_talla = tal.id_talla
      and pr.id_unidad=un.id_unidad and pr.id_modelo = mo.id_modelo and pr.id_marca = mar.id_marca and cat.nombre like concat(dato,'%') ;
      when 5 then 
     select pr.id_producto,cat.nombre,pr.nombre,mo.nombre,mar.nombre,co.nombre,tal.nombre,un.nombre,pr.precio_venta,pr.stock
from producto pr,
       categoria cat,
        color co,
        modelo mo,
        talla tal, marca mar,unidad un
      where pr.id_color = co.id_color and pr.id_categoria = cat.id_categoria and pr.id_talla = tal.id_talla
      and pr.id_unidad=un.id_unidad and pr.id_modelo = mo.id_modelo and pr.id_marca = mar.id_marca and mar.nombre like concat(dato,'%') ; 
     when 6 then 
     select pr.id_producto,cat.nombre,pr.nombre,mo.nombre,mar.nombre,co.nombre,tal.nombre,un.nombre,pr.precio_venta,pr.stock
from producto pr,
       categoria cat,
        color co,
        modelo mo,
        talla tal, marca mar,unidad un
      where pr.id_color = co.id_color and pr.id_categoria = cat.id_categoria and pr.id_talla = tal.id_talla
      and pr.id_unidad=un.id_unidad and pr.id_modelo = mo.id_modelo and pr.id_marca = mar.id_marca and mo.nombre like concat(dato,'%') ;
      end case;

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSProveedor`
--

DROP PROCEDURE IF EXISTS `SPRCNSProveedor`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSProveedor`(opcion int(2),dato varchar(50))
begin
case opcion
when 1 then
select pro.id_proveedor,pro.nombres,pro.apellidos,pro.ruc,dis.nombre,prov.provincia,pro.razon_social,pro.direccion,pro.telefono,pro.celular,pro.rpm,pro.email,pro.fax,pro.estado from proveedor pro,distrito dis,provincia prov where prov.id_provincia=dis.id_provincia and  pro.id_distrito = dis.id_distrito;
when 2 then 
select pro.id_proveedor,pro.nombres,pro.apellidos,pro.ruc,dis.nombre,pro.razon_social,pro.direccion,pro.telefono,pro.celular,pro.rpm,pro.email,pro.fax,pro.estado from proveedor pro,distrito dis where pro.id_distrito = dis.id_distrito and pro.id_proveedor like concat(dato,'%');
when 3 then 
select pro.id_proveedor,pro.nombres,pro.apellidos,pro.ruc,dis.nombre,pro.razon_social,pro.direccion,pro.telefono,pro.celular,pro.rpm,pro.email,pro.fax,pro.estado from proveedor pro,distrito dis where pro.id_distrito = dis.id_distrito and pro.nombres like concat(dato,'%');
when 4 then 
select pro.id_proveedor,pro.nombres,pro.apellidos,pro.ruc,dis.nombre,pro.razon_social,pro.direccion,pro.telefono,pro.celular,pro.rpm,pro.email,pro.fax,pro.estado from proveedor pro,distrito dis where pro.id_distrito = dis.id_distrito and pro.apellidos like concat(dato,'%');
when 5 then 
select pro.id_proveedor,pro.nombres,pro.apellidos,pro.ruc,dis.nombre,pro.razon_social,pro.direccion,pro.telefono,pro.celular,pro.rpm,pro.email,pro.fax,pro.estado from proveedor pro,distrito dis where pro.id_distrito = dis.id_distrito and pro.ruc like concat(dato,'%');
end case;
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSProvincia`
--

DROP PROCEDURE IF EXISTS `SPRCNSProvincia`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSProvincia`()
BEGIN
select * from provincia;
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSRol`
--

DROP PROCEDURE IF EXISTS `SPRCNSRol`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSRol`()
begin
select * from rol; 
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSTalla`
--

DROP PROCEDURE IF EXISTS `SPRCNSTalla`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSTalla`(opcion int(2),dato int(11))
begin
case opcion
when 1 then
select tal.id_talla,tal.nombre,cat.nombre as 'Categoria' from talla tal,categoria cat where tal.id_categoria = cat.id_categoria;
when 2 then
select tal.id_talla,tal.nombre,cat.nombre as 'Categoria' from talla tal,categoria cat where cat.id_categoria=tal.id_categoria and tal.id_categoria=dato;
end case;
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSTipo_Personal`
--

DROP PROCEDURE IF EXISTS `SPRCNSTipo_Personal`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSTipo_Personal`()
BEGIN
select * from tipo_personal;
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSUnidad`
--

DROP PROCEDURE IF EXISTS `SPRCNSUnidad`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSUnidad`()
begin

select * from unidad;

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSUsuario`
--

DROP PROCEDURE IF EXISTS `SPRCNSUsuario`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSUsuario`()
begin

select * from usuario order by id_usuario;

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSVentas`
--

DROP PROCEDURE IF EXISTS `SPRCNSVentas`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSVentas`(anio varchar(4),mes varchar(15),op int(2))
begin
if op=1
then
select MONTHNAME(bol.fecha_entrega) as 'Mes',count(*) as 'Cantidad' from boleta bol where YEAR(bol.fecha_entrega)=anio group by MONTH(bol.fecha_entrega) order by MONTH(bol.fecha_entrega);
else
set @mes=(select NMes(mes));
select DAY(bol.fecha_entrega) as 'Mes',count(*) as 'Cantidad' from boleta bol where YEAR(bol.fecha_entrega)=anio AND MONTH(bol.fecha_entrega)=@mes group by DAY(bol.fecha_entrega) order by DAY(bol.fecha_entrega);
end if;
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSVentasxCategoria`
--

DROP PROCEDURE IF EXISTS `SPRCNSVentasxCategoria`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSVentasxCategoria`(anio varchar(4),mes varchar(15),op int(2))
begin
if op=1
then
select cat.nombre as 'Categoria',sum(del.cantidad) as 'Cantidad' from detalle_boleta_producto del,boleta bol,producto pro,categoria cat  where del.id_producto = pro.id_producto and
pro.id_categoria = cat.id_categoria and del.id_boleta = bol.id_boleta and YEAR(bol.fecha_entrega)=anio group by cat.nombre order by cat.nombre;
else
set @mes=(NMes(mes));
select cat.nombre as 'Categoria',sum(del.cantidad) as 'Cantidad' from detalle_boleta_producto del,boleta bol,producto pro,categoria cat  where del.id_producto = pro.id_producto and
pro.id_categoria = cat.id_categoria and del.id_boleta = bol.id_boleta and YEAR(bol.fecha_entrega)=anio and MONTH(bol.fecha_entrega)=@mes group by cat.nombre order by cat.nombre;
end if;
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSVentasxLinea`
--

DROP PROCEDURE IF EXISTS `SPRCNSVentasxLinea`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSVentasxLinea`(anio varchar(4),mes varchar(15),op int(2))
begin
if op=1
then
select li.nombre as 'Linea',sum(del.cantidad) as 'Cantidad' from detalle_boleta_producto del,boleta bol,producto pro,linea li,categoria cat  where del.id_producto = pro.id_producto and
cat.id_linea = li.id_linea and pro.id_categoria = cat.id_categoria and del.id_boleta = bol.id_boleta and YEAR(bol.fecha_pedido)=anio group by li.nombre order by li.nombre;
else
set @mes=(NMes(mes));
select li.nombre as 'Linea',sum(del.cantidad) as 'Cantidad' from detalle_boleta_producto del,boleta bol,producto pro,linea li,categoria cat  where del.id_producto = pro.id_producto and
cat.id_linea = li.id_linea and pro.id_categoria = cat.id_categoria and del.id_boleta = bol.id_boleta and YEAR(bol.fecha_pedido)=anio and MONTH(bol.fecha_entrega)=@mes group by li.nombre order by li.nombre;
end if;
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRCNSVentasxMarca`
--

DROP PROCEDURE IF EXISTS `SPRCNSVentasxMarca`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRCNSVentasxMarca`(anio varchar(4),mes varchar(15),op int(2))
begin
if op=1
then
select mar.nombre as 'Marca',sum(del.cantidad) as 'Cantidad' from detalle_boleta_producto del,boleta bol,producto pro,marca mar  where del.id_producto = pro.id_producto and
pro.id_marca = mar.id_marca and del.id_boleta = bol.id_boleta and YEAR(bol.fecha_entrega)=anio group by mar.nombre order by mar.nombre;
else
set @mes=(select NMes(mes));
select mar.nombre as 'Marca',sum(del.cantidad) as 'Cantidad' from detalle_boleta_producto del,boleta bol,producto pro,marca mar  where del.id_producto = pro.id_producto and
pro.id_marca = mar.id_marca and del.id_boleta = bol.id_boleta and YEAR(bol.fecha_entrega)=anio AND MONTH(bol.fecha_entrega)=@mes group by mar.nombre order by mar.nombre;
end if;
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRINSDetallePedido`
--

DROP PROCEDURE IF EXISTS `SPRINSDetallePedido`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRINSDetallePedido`(id_boleta2 int(11),id_producto2 int(11),cantidad2 int(11),costo2 decimal(6,2))
begin
insert into detalle_boleta_producto(id_boleta,id_producto,cantidad,costo)values(id_boleta2,id_producto2,cantidad2,costo2);
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRINSPedido`
--

DROP PROCEDURE IF EXISTS `SPRINSPedido`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRINSPedido`(numero_boleta2 int(11),id_cliente2 int(11),id_personal2 int(11),id_forma_pago2 int(11),fecha_pedido2 datetime,fecha_entrega2 datetime,sub_total2 decimal(6,2),igv2 decimal(6,2),total2 decimal(6,2),id_tipo_recibo2 int(11))
begin

insert into boleta(numero_boleta,id_cliente,id_personal,id_forma_pago,fecha_pedido ,fecha_entrega,sub_total,igv,total,id_tipo_recibo)values(numero_boleta2,id_cliente2,id_personal2,id_forma_pago2,fecha_pedido2,fecha_entrega2,sub_total2,igv2,total2,id_tipo_recibo2);
SELECT id_boleta as 'Idboleta' FROM boleta order by id_boleta desc LIMIT 1;
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRListadoClientes`
--

DROP PROCEDURE IF EXISTS `SPRListadoClientes`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRListadoClientes`()
begin

select cl.id_cliente,cl.nombres,cl.apellidos,pro.provincia as 'Provincia',dis.nombre as 'Distrito',cl.direccion,cl.dni,cl.ruc,cl.telefono,cl.celular from cliente cl,distrito dis,provincia pro where pro.id_provincia=dis.id_provincia and cl.id_distrito = dis.id_distrito;

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRListadoProductos`
--

DROP PROCEDURE IF EXISTS `SPRListadoProductos`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRListadoProductos`()
begin
select pr.id_producto as 'CodigoProducto',
 concat(cat.nombre,' ',pr.nombre,' ',mo.nombre,' ',mar.nombre,' ',co.nombre,' ',tal.nombre) as 'DescripcionProducto'
         ,pr.precio as 'Precio',
         pr.stock as 'Stock'
from producto pr,
       categoria cat,
        color co,
        modelo mo,
        talla tal, marca mar
      where pr.id_color = co.id_color and pr.id_categoria = cat.id_categoria and pr.id_talla = tal.id_talla
      and pr.id_modelo = mo.id_modelo and pr.id_marca = mar.id_marca;

end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRObtenerIdCompra`
--

DROP PROCEDURE IF EXISTS `SPRObtenerIdCompra`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRObtenerIdCompra`()
begin

SELECT id_compra FROM compra order by id_compra desc LIMIT 1;
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRObtenerIdDetalleCompra`
--

DROP PROCEDURE IF EXISTS `SPRObtenerIdDetalleCompra`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRObtenerIdDetalleCompra`(dato int(11))
BEGIN
select id_detalle_compra_producto from detalle_compra_producto where id_compra=dato;
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRObtenerImagen_Producto`
--

DROP PROCEDURE IF EXISTS `SPRObtenerImagen_Producto`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRObtenerImagen_Producto`(id_producto2 int(11))
BEGIN
SELECT ruta_imagen from producto where id_producto=id_producto2;
END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRReportesAlmacen`
--

DROP PROCEDURE IF EXISTS `SPRReportesAlmacen`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRReportesAlmacen`(opcion int(2),dato int(3))
BEGIN
case opcion

when 1 then
select li.nombre as 'Descripcion',sum(pro.stock) as 'Stock' from producto pro,categoria ca,linea li where ca.id_categoria=pro.id_categoria
and li.id_linea=ca.id_linea group by ca.id_linea;

when 2 then
select ca.nombre as 'Descripcion',sum(pro.stock) as 'Stock' from producto pro,categoria ca where ca.id_categoria=pro.id_categoria
and ca.id_linea=dato
group by pro.id_categoria;

when 3 then
select ma.nombre as 'Descripcion',sum(pro.stock) as 'Stock' from producto pro,marca ma,categoria ca where ma.id_marca=pro.id_marca
and ca.id_categoria=pro.id_categoria and pro.id_categoria=dato group by pro.id_marca;
end case;

END $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;

--
-- Definition of procedure `SPRValidarUsuario`
--

DROP PROCEDURE IF EXISTS `SPRValidarUsuario`;

DELIMITER $$

/*!50003 SET @TEMP_SQL_MODE=@@SQL_MODE, SQL_MODE='STRICT_TRANS_TABLES,NO_AUTO_CREATE_USER' */ $$
CREATE DEFINER=`root`@`localhost` PROCEDURE `SPRValidarUsuario`(usuario2 int(11),clave2 varchar(16))
begin
select pe.id_personal,pe.clave from personal pe where pe.id_personal=usuario2 and pe.clave=clave2;
end $$
/*!50003 SET SESSION SQL_MODE=@TEMP_SQL_MODE */  $$

DELIMITER ;



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
