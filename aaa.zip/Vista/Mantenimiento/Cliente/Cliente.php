<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css">
			@import "../../../jQuery/dataTable/css/demo_page.css";
			@import "../../../jQuery/dataTable/css/demo_table_jui.css";
			@import "../../../jQuery/dataTable/smoothness/jquery-ui-1.8.4.custom.css";
			
		</style>
<script type="text/javascript" src="../../../jQuery/jquery-1.7.2.js"></script>
<script type="text/javascript" src="../../../jQuery/dataTable/js/jquery.dataTables.js"></script>
<script type="text/javascript" language="javascript" src="../../../js/Mantenimiento/Cliente/funciones.js"></script>
<link href="../../../css/Mantenimiento/Cliente/estilos.css" type="text/css" rel="stylesheet" />
</head>
<body>
<div id="datos">
<form method="post" action="p_cliente.php">
<table width="400" border="0" align="center">
  <tr>
    <td class="celda">
	<input type="hidden" name="opcion" id="opcion" value="1" size="11"/>
	<input type="hidden" name="id_cliente" id="id_cliente" value="1" size="17"/>
	<input type="text" name="dni" id="dni" size="15"/></td>
	 <td class="celda"><input type="text" name="ruc" id="ruc" size="15" /></td>
	<td><input type="text" name="nombres" id="nombres" size="17"/></td>
    <td class="celda"><input type="text" name="apellidos" id="apellidos" size="17"/></td>
  
      </tr>
  <tr>
    <td class="celda"><label>DNI</label></td>
    <td class="celda"><label>RUC</label></td>
    <td class="celda"><label>NOMBRES</label></td>
	<td class="celda"><label>APELLIDOS</label></td>
	  </tr>
  <tr>
  <td class="celda"><select name="provincia" id="provincia">
	<?php
	$result2=CMProvinciaDistrito::CNSProvincia();
	foreach($result2 as $fila)
	{
	echo "<option value='".$fila['ID_PROVINCIA']."'>".$fila['NOMBRE']."</option>";
	}
	?>
	</select></td>
   <td class="celda"><select name="distrito" id="distrito">
	</select></td>
       <td class="celda"><input type="text" name="direccion" id="direccion" size="15"/></td>
    
	   <td class="celda"><input type="text" name="telefono" id="telefono" size="15" /></td>
  
  </tr>
  <tr>

    <td class="celda"><label>PROVINCIA</label></td>
	 <td class="celda"><label>DISTRITO</label></td>
	 <td class="celda"><label>DIRECCION</label></td>
    <td class="celda"><label>TELEFONO</label></td>

  </tr>
  <tr>
 <td class="celda" colspan="4" align="center"><input type="text" name="celular" id="celular" size="15" /></td>
    </tr>
	  <tr>
    <td class="celda" colspan="4" align="center"><label>CELULAR</label></td>
    </tr>
  
 </table>
</div>
<div id="informacion" class="demo_jui">
<table cellpadding="0" cellspacing="0" border="0" class="display" id="mantenimiento_clientes">
<thead>
<tr>
<th style="width:20" >ID</th>
<th >DNI</th>
<th >RUC</th>
<th >Nombres</th>
<th >Apellidos</th>
<th >Provincia</th>
<th style="width:70">Distrito</th>
<th >Direccion</th>
<th style="width:20">Telefono</th>
<th style="width:20">Celular</th>
</tr>
</thead>
<tbody>
<?php
$result=CMCliente::SPRCNSCliente();
if($result)
{
foreach($result as $fila)
{
echo "<tr>";
echo "<td class='center'>".$fila['id_cliente']."</td>";
echo "<td class='center'>".$fila['dni']."</td>";
echo "<td class='center'>".$fila['ruc']."</td>";
echo "<td class='center'>".$fila['nombres']."</td>";
echo "<td class='center'>".$fila['apellidos']."</td>";
echo "<td class='center'>".$fila['Provincia']."</td>";
echo "<td class='center'>".$fila['Distrito']."</td>";
echo "<td class='center'>".$fila['direccion']."</td>";
echo "<td class='center'>".$fila['telefono']."</td>";
echo "<td class='center'>".$fila['celular']."</td>";
echo "</tr>";
}
}
else
{
echo "No Hay datos";
}
?>
</div>
<div id="botones">
<table align='center' class="botones">
<tr>
<td><button name='btnNuevo' type='button' id='btnNuevo'><img src='../../../images/NUEVO1.png'><br/>Nuevo</button></td>
<td><button name='btnGuardar' type='submit' id='btnGuardar'><img src='../../../images/save-icon.png'><br/>Guardar</button></td>
<td><button name='btnEditar' type='button' id='btnEditar' ><img src='../../../images/edit-icon (1).png'><br/>Editar</button></td>
<td><button name='btnCancelar' type='button' id='btnCancelar' ><img src='../../../images/Cancel-icon (1).png'><br/>Cancelar</button></td>
<td><button name='btnEliminar' type='submit' id='btnEliminar' ><img src='../../../images/Delete-icon (2).png'><br/>Eliminar</button></td>
</tr>
</table>
<table align="center">
<tr>
<td><button type='button' id='btnEWord' class="btn" data='<?php 
$string2=json_encode(CMCliente::SPRCNSCliente());
echo $string2; ?>'><img src="../../../images/word.png" width="30" height="30" /> Word</button>
</td>
<td><button type='button' id='btnEExcel' class="btn" data='<?php 
echo $string2; ?>'><img src="../../../images/excel.png" width="30" height="30" /> Excel</button></td>
<td><button type='button' id='btnEPdf' class="btn" data='<?php 
echo $string2; ?>'><img src="../../../images/pdf.png" width="30" height="30" /> PDF</button></td>
</tr>
</table>
</div>
</form>
<div id="resultado">
<?php 
if(isset($_REQUEST['resultado'])) 
{
echo $_REQUEST['resultado'];
}
echo "</div>";
?>
</div>
</body>
</html>
