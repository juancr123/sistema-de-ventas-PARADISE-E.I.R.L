<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Mantenimiento Marca</title>
<style type="text/css">
			@import "../../../jQuery/dataTable/css/demo_page.css";
			@import "../../../jQuery/dataTable/css/demo_table_jui.css";
			@import "../../../jQuery/dataTable/smoothness/jquery-ui-1.8.4.custom.css";
			
		</style>
<script type="text/javascript" language="javascript" src="../../../js/Mantenimiento/Marca/funciones.js"></script>
<script type="text/javascript" src="../../../jQuery/jquery-1.7.2.js"></script>
<script type="text/javascript" src="../../../jQuery/dataTable/js/jquery.dataTables.js"></script>
<script type="text/javascript" language="javascript" src="../../../js/Mantenimiento/Marca/funcionesJQuery.js"></script>
<link href="../../../css/Mantenimiento/Marca/estilos.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body id="dt_example">
<form action="p_marca.php" method="post">
<div id='datos'>
<table align='center'>
<tr>
<td><input type='hidden' id='opcion' name='opcion' value="1"/>
<input type='hidden' id='id_marca' name='id_marca' value="0"/>
<input type='text' id='txtMarca' name="txtMarca"/></td>
</tr>
<tr>
<td colspan='2'><label>NOMBRE DE MARCA</label></td>
</tr>
</table>
</div>
<div id='informacion'>
<div class='demo_jui'>
<table cellpadding='0' cellspacing='0'  border='0' class='display' id='example' style="width:450px">
<thead>
<tr>
<th>ID</th>
<th>Marca</th>
</tr>
</thead>
<tbody>
<?php 
$result=CMMarca::SPRCNSMarca();
if($result)
{
foreach($result as $fila)
{
echo "<tr>";
echo "<td class='center'>".$fila['ID_MARCA']."</td>";
echo "<td class='center'>".$fila['NOMBRE']."</td>";
echo "</tr>";
}
}
else
{
 echo "No Hay Productos";
}
?>
</tbody>
</table>
</div>
<div id='botones'>
<table align='center'>
<tr>
<td><button name='btnNuevo' type='button' id='btnNuevo' ><img src='../../../images/NUEVO1.png'><br/>Nuevo</button></td>
<td><button name='btnGuardar' type='submit' id='btnGuardar' ><img src='../../../images/save-icon.png'><br/>Guardar</button></td>
<td><button name='btnEditar' type='button' id='btnEditar' ><img src='../../../images/edit-icon (1).png'><br/>Editar</button></td>
<td><button name='btnCancelar' type='button' id='btnCancelar' ><img src='../../../images/Cancel-icon (1).png'><br/>Cancelar</button></td>
<td><button name='btnEliminar' type='submit' id='btnEliminar' ><img src='../../../images/Delete-icon (2).png'><br/>Eliminar</button></td>
</tr>
</table>
<br />
<table align="center">
<tr>
<td><button type='button' id='btnEWord' class="btn" data='<?php 
$string2=json_encode(CMMarca::SPRCNSMarca());
echo $string2; ?>'><img src="../../../images/word.png" width="30" height="30"/>Word</button>
</td>
<td><button type='button' id='btnEExcel' class="btn" data='<?php 
echo $string2; ?>'><img src="../../../images/excel.png" width="30" height="30"/> Excel</button></td>
<td><button type='button' id='btnEPdf' class="btn" data='<?php 
echo $string2; ?>'><img src="../../../images/pdf.png" width="30" height="30"/> PDF</button></td>
</tr>
</table>
</div>
</form>
<div id='resultado' align='center'>
<?php
if(isset($_REQUEST['resultado'])) 
{
echo $_REQUEST['resultado'];
}
?>
</div>
</body>
</html>
