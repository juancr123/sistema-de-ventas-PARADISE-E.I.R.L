<?php
header('Content-type: application/vnd.ms-excel');
header("Content-Disposition: attachment; filename=Report.xls");
header("Pragma: no-cache");
header("Expires: 0");
$arrayrecibido=$_REQUEST['arrays'];
echo '<table cellpadding="0" cellspacing="0" border="2">
<thead>';
foreach(json_decode($arrayrecibido) as $key=>$valor)
{
foreach($valor as $key2=>$valor2)
{
if($key==0)
{
echo "<th>".$key2."</th>";
}
}
}
?>
</thead>
<tbody>
<?php
$i=1;
foreach(json_decode($arrayrecibido) as $key=>$valor)
{
if($i%2==0)
{
echo '<tr>';
}
else
{
echo '<tr>';
}
foreach($valor as $key2=>$valor2)
{
echo "<td>".$valor2."</td>";
}
echo "</tr>";
$i++;
}  
?>
</tbody>
</table>

