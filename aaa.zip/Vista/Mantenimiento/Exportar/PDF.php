<?php
require_once('class.ezpdf.php');
$pdf =& new Cezpdf('a4');
$pdf->selectFont('../fonts/courier.afm');
$pdf->ezSetCmMargins(1,1,1.5,1.5);
$arrayrecibido=$_REQUEST['arrays'];
$i=0;
foreach(json_decode($arrayrecibido) as $key=>$valor)
{
$data[$i]=array();//sirve para declarar arreglo vacio
foreach($valor as $key2=>$valor2)
{
$data[$i]+=array($key2=>$valor2);
if($key==0)
{
$titles[$key2]="<b>".$key2."</b>";
}
}
$i++;
}

$options = array(
				'shadeCol'=>array(0.9,0.9,0.9),
				'xOrientation'=>'center',
				'width'=>500
			);
$txttit = "<b>Reporte</b>\n";
$pdf->ezText($txttit, 12);
$pdf->ezTable($data, $titles, '', $options);
$pdf->ezText("\n\n\n", 10);
$pdf->ezText("<b>Fecha:</b> ".date("d/m/Y"), 10);
$pdf->ezText("<b>Hora:</b> ".date("H:i:s")."\n\n", 10);
$pdf->ezStream();
?>