<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Mantenimiento Color</title>
<style type="text/css">
			@import "../../../jQuery/dataTable/css/demo_page.css";
			@import "../../../jQuery/dataTable/css/demo_table_jui.css";
			@import "../../../jQuery/dataTable/smoothness/jquery-ui-1.8.4.custom.css";
			
		</style>
<script type="text/javascript" src="../../../jQuery/jquery-1.7.2.js"></script>
<script type="text/javascript" src="../../../jQuery/dataTable/js/jquery.dataTables.js"></script>
<script type="text/javascript" language="javascript" src="../../../js/Mantenimiento/Color/funciones.js"></script>
<link href="estilos.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body id="dt_example">
<form action="p_color.php" method="post">
<div id='datos'>
<table align='center'>
<tr>
<td>
<input type='hidden' id='opcion' name='opcion' value="1"/>
<input type='hidden' id='id_color' name='id_color' value="0"/>
<input type='text' id='txtColor' name="txtColor"/></td>
</tr>
<tr>
<td colspan='2'><label>NOMBRE DEL COLOR</label></td>
</tr>
</table>
</div>
<div id='informacion'>
<div class='demo_jui'>
<table cellpadding='0' cellspacing='0'  border='0' class='display' id='color'>
<thead>
<tr>
<th >ID</th>
<th >Linea</th>
</tr>
</thead>
<tbody>
<?php
$result=CMColor::SPRCNSColor();
if($result)
{
foreach($result as $fila)
{
echo"<tr>";
echo "<td class='center'>".$fila["ID_COLOR"]."</td>";
echo "<td class='center'>".$fila["NOMBRE"]."</td>";
echo "</tr>";
}
}
else
{
echo "No Hay Datos";
}
?>
</tbody>
</table>
</div>
<div id='botones'>
<table align='center'>
<tr>
<td><button name='btnNuevo' type='button' id='btnNuevo' onClick='btnNuevo_onClick()'><img src='../../../images/NUEVO1.png'><br/>Nuevo</button></td>
<td><button name='btnGuardar' type='submit' id='btnGuardar' ><img src='../../../images/save-icon.png'><br/>Guardar</button></td>
<td><button name='btnEditar' type='button' id='btnEditar' onClick='btnEditar_onClick()'><img src='../../../images/edit-icon (1).png'><br/>Editar</button></td>
<td><button name='btnCancelar' type='button' id='btnCancelar' onClick='btnCancelar_onClick()'><img src='../../../images/Cancel-icon (1).png'><br/>Cancelar</button></td>
<td><button name='btnEliminar' type='submit' id='btnEliminar' ><img src='../../../images/Delete-icon (2).png'><br/>Eliminar</button></td>
</tr>
</table>
</div>
</form>
<div id='resultado' align='center'>
<?php
if(isset($_REQUEST['resultado'])) 
{
echo $_REQUEST['resultado'];
}
echo "</div>";
?>
</body>
</html>
