<?php
require '../../../Modelo/Mantenimiento/Color/CMColor.php';
$nombre_marca=$_GET["nombre_color"];
$result=CMColor::SPRCNSColor();
if($result)
{
foreach($result as $fila)
{
if($fila['NOMBRE']==$nombre_marca)
{
echo "<option value='".$fila['ID_COLOR']."' selected='selected'>".$fila['NOMBRE']."</option>";
}
else
{
echo "<option value='".$fila['ID_COLOR']."'>".$fila['NOMBRE']."</option>";
}
}
}
?>
