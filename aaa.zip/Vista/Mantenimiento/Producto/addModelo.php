<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<script type="text/javascript" src="../../../jQuery/jquery-1.7.2.js" ></script>
<script type="text/javascript" src="../../../js/Mantenimiento/Producto/funcionesAddModelo.js"></script>
			<script src="../../../jQuery/alerts/js/jquery.alerts.js" type="text/javascript"></script>
            <link href="../../../jQuery/alerts/css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
<style type="text/css">
#popup_container {
	font-size: 10px;
	min-width: 150px; /* Dialog will be no smaller than this */
	max-width: 200px; /* Dialog will wrap after this width */
}
#popup_title {
	font-size: 10px;
	}
</style>
</head>
<body>
<table align="center">
<tr>
<td><input type="text" name="nombre_modelo" id="nombre_modelo" /></td>
<td><select name="categoria" id="categoria" disabled="disabled">

<?php
require '../../../Modelo/Mantenimiento/Categoria/CMCategoria.php';
$result=CMCategoria::SPRCNSCategoria();
$id_categoria=$_GET["id_categoria"];
if($result)
foreach($result as $fila)
{
if($fila['ID_CATEGORIA']==$id_categoria)
{
echo "<option value='".$fila['ID_CATEGORIA']."' selected='selected'>".$fila['NOMBRE']."</option>";
}
else
{
echo "<option value='".$fila['ID_CATEGORIA']."'>".$fila['NOMBRE']."</option>";
}
}
?>
</select></td>
</tr>
<tr>
<td>NOMBRE</td>
<td>CATEGORIA</td>
</tr>
<tr>
<td colspan="2" align="center"><button type="button" id="btnaddModelo">Agregar</button></td>  
</tr>
</table>
</body>
</html>
