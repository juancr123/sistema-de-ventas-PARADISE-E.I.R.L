<?php
require '../../../Modelo/Mantenimiento/Marca/CMMarca.php';
$nombre_marca=$_GET["nombre2"];
$result=CMMarca::SPRCNSMarca();
if($result)
{
foreach($result as $fila)
{
if($fila['NOMBRE']==$nombre_marca)
{
echo "<option value='".$fila['ID_MARCA']."' selected='selected'>".$fila['NOMBRE']."</option>";
}
else
{
echo "<option value='".$fila['ID_MARCA']."'>".$fila['NOMBRE']."</option>";
}
}
}
?>
