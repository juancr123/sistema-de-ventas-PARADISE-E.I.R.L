<?php
require '../../../Modelo/Mantenimiento/Talla/CMTalla.php';
$nombre_talla=$_GET["nombre_talla"];
$id_categoria=$_GET['id_categoria'];
$result=CMTalla::SPRCNSTalla(2,$id_categoria);
if($result)
{
foreach($result as $fila)
{
if($fila['NOMBRE']==$nombre_talla)
{
echo "<option value='".$fila['ID_TALLA']."' selected='selected'>".$fila['NOMBRE']."</option>";
}
else
{
echo "<option value='".$fila['ID_TALLA']."'>".$fila['NOMBRE']."</option>";
}
}
}

?>
