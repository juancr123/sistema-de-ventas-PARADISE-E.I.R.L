<?php
require '../../../Modelo/Mantenimiento/Modelo/CMModelo.php';
$nombre_marca=$_GET["nombre_modelo"];
$id_categoria=$_GET["id_categoria"];
$result=CMModelo::ABMModelo("1","1",$nombre_marca,$id_categoria);
if($result)
{
echo "1";
}
else
{
echo "2";
}
?>