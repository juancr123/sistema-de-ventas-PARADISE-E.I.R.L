<?php
require '../../../Modelo/Mantenimiento/Modelo/CMModelo.php';
$nombre_modelo=$_GET["nombre_modelo"];
$id_categoria=$_GET['id_categoria'];
$result=CMModelo::SPRCNSModelo(2,$id_categoria);
if($result)
{
foreach($result as $fila)
{
if($fila['NOMBRE']==$nombre_modelo)
{
echo "<option value='".$fila['ID_MODELO']."' selected='selected'>".$fila['NOMBRE']."</option>";
}
else
{
echo "<option value='".$fila['ID_MODELO']."'>".$fila['NOMBRE']."</option>";
}
}
}
?>
