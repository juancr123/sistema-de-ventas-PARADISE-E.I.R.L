<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link type="text/css" rel="stylesheet" href="../../../jQuery/dialog/themes/base/jquery.ui.all.css" />
<link href="../../../css/Mantenimiento/Producto/estilos.css" type="text/css" rel="stylesheet" />
<style type="text/css">
			@import "../../../jQuery/dataTable/css/demo_page.css";
			@import "../../../jQuery/dataTable/css/demo_table_jui.css";
			@import "../../../jQuery/dataTable/smoothness/jquery-ui-1.8.4.custom.css";
			</style>
 <script type="text/javascript" src="../../../jQuery/jquery-1.7.2.js"></script>
<script type="text/javascript" src="../../../jQuery/dataTable/js/jquery.dataTables.js"></script>
			<script type="text/javascript" src="../../../jQuery/dialog/ui/jquery-ui-1.8.7.custom.js"></script>
			<script type="text/javascript" src="../../../jQuery/dataTable/js/funciones.js"></script>
			<script type="text/javascript" src="../../../js/Mantenimiento/Producto/funciones.js"></script>
			
			<script src="../../../jQuery/alerts/js/jquery.alerts.js" type="text/javascript"></script>
            <link href="../../../jQuery/alerts/css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
			
			
</head>
<body id="dt_example">
<div id="datos">
<form enctype="multipart/form-data" method="post" action="p_producto.php">
<table width="1000" border="0" align="center">
  <tr>
  
    <td class="celda" colspan="5" style="padding-left:78px;">
	<!--<input type="hidden" name="modificar_imagen" id="modificar_imagen" value="0" size="17"/>-->
	<input type="hidden" name="opcion" id="opcion" value="1" size="17"/>
	<input type="hidden" name="id_producto" id="id_producto" value="1" size="17"/>
	<select name="categoria" id="categoria">
	<?php
	$result2=CMCategoria::SPRCNSCategoria();
	foreach($result2 as $fila)
	{
	echo "<option value='".$fila['ID_CATEGORIA']."'>".$fila['NOMBRE']."</option>";
	}
	?>
	</select>&nbsp;&nbsp;&nbsp;<button id="btnCategoria" type="button"><img src="../../../images/Add-icon.png" width="20" height="20"/></button>
	
   <select  id="marca" name="marca">
	<?php
	$result=CMMarca::SPRCNSMarca();
	foreach($result as $fila)
	{
	echo "<option value='".$fila['ID_MARCA']."'>".$fila['NOMBRE']."</option>";
	}
	?>
    </select>&nbsp;&nbsp;&nbsp;<button id="btnMarca" type="button"><img src="../../../images/Add-icon.png" width="20" height="20"/></button>
 <select name="modelo" id="modelo" disabled="disabled">
	
	</select>&nbsp;&nbsp;&nbsp;<button id="btnModelo" type="button" disabled="disabled"><img src="../../../images/Add-icon.png" width="20" height="20"/></button>
   <select name="color" id="color">
	<?php
	$result5=CMColor::SPRCNSColor();
	foreach($result5 as $fila)
	{
	echo "<option value='".$fila['ID_COLOR']."'>".$fila['NOMBRE']."</option>";
	}
	?>
	</select>&nbsp;&nbsp;&nbsp;<button id="btnColor" type="button"><img src="../../../images/Add-icon.png" width="20" height="20"/></button></td>
  </tr>
<tr>
<td class="celda" colspan="5" style="padding-left:70px;"><table><tr><td style="padding-right:60px;"><label>CATEGORIA</label></td><td style="padding-right:60px;"><label>MARCA</label></td><td style="padding-right:60px;"><label>MODELO</label></td><td><label>COLOR</label></td></table></td>
</tr>
  <tr>
       <td class="celda"><select name="talla" id="talla" disabled="disabled">
	
	</select>&nbsp;&nbsp;&nbsp;<button id="btnTalla" type="button" disabled="disabled"><img src="../../../images/Add-icon.png" width="20" height="20"/></button></td>
    
	 <td class="celda"><select name="unidad" id="unidad">
	 <?php
	$result4=CMUnidad::SPRCNSUnidad();
	foreach($result4 as $fila)
	{
	echo "<option value='".$fila['ID_UNIDAD']."'>".$fila['NOMBRE']."</option>";
	}
	?>
	</select>&nbsp;&nbsp;&nbsp;<!--<button id="btnUnidad" type="button"><img src="../../../images/Add-icon.png" width="20" height="20"/></button>--></td>
  
  <td class="celda"><input type="text" name="precio_venta" id="precio_venta" size="17"/></td>
    <td class="celda"><input type="text" name="stock" id="stock" size="17"/></td>
	  <td colspan="3" align="center" ><input type="file" id="imagen" name="imagen" size="15"/></td>
  </tr>
  <tr>

    <td class="celda"><label>TALLA</label></td>
	 <td class="celda"><label>UNIDAD</label></td>
	 <td class="celda"><label>PRECIO</label></td>
    <td class="celda"><label>STOCK</label></td>
	<td colspan="3" align="left" ><label>IMAGEN</label></td>
  </tr>
 </table>
</div>
<div id="informacion" class="demo_jui">
<table cellpadding="0" cellspacing="0" border="0" class="display" id="productos">
<thead>
<tr>
<th style="width:20" >ID</th>
<th >Categoria</th>
<th >Marca</th>
<th >Modelo</th>
<th >Color</th>
<th style="width:70">Talla</th>
<th >Unidad</th>
<th style="width:20">Precio</th>
<th style="width:20">Stock</th>
<th>Imagen</th>
</tr>
</thead>
<tbody>
<?php
$result=CMProducto::SPRCNSProducto(1,'');
if($result)
{
foreach($result as $fila)
{
echo "<tr>";
echo "<td class='center'>".$fila['id_producto']."</td>";
echo "<td class='center'>".$fila['linea']."</td>";
echo "<td class='center'>".$fila['Marca']."</td>";
echo "<td class='center'>".$fila['Modelo']."</td>";
echo "<td class='center'>".$fila['Color']."</td>";
echo "<td class='center'>".$fila['Talla']."</td>";
echo "<td class='center'>".$fila['Unidad']."</td>";
echo "<td class='center'>".$fila['precio_venta']."</td>";
echo "<td class='center'>".$fila['stock']."</td>";
if($fila['ruta_imagen']=="")
{
echo "<td class='center' align='center'>Sin imagen</td>";
}
else
{
echo "<td class='foto' align='center' onClick=jQuery.fn.VistaPrevia()><img src='../../../images/zapatillas/".$fila['ruta_imagen']."' width=80 height=60 /></td>";
}
echo "</tr>";
}
}
else
{
echo "No Hay Productos";
}
?>
</div>
<div id="botones">
<table align='center' class="botones">
<tr>
<td><button name='btnNuevo' type='button' id='btnNuevo'><img src='../../../images/NUEVO1.png'><br/>Nuevo</button></td>
<td><button name='btnGuardar' type='submit' id='btnGuardar'><img src='../../../images/save-icon.png'><br/>Guardar</button></td>
<td><button name='btnEditar' type='button' id='btnEditar' ><img src='../../../images/edit-icon (1).png'><br/>Editar</button></td>
<td><button name='btnCancelar' type='button' id='btnCancelar' ><img src='../../../images/Cancel-icon (1).png'><br/>Cancelar</button></td>
<td><button name='btnEliminar' type='submit' id='btnEliminar' ><img src='../../../images/Delete-icon (2).png'><br/>Eliminar</button></td>
</tr>
</table>
<br />
<table align="center">
<tr>
<td><button type='button' id='btnEWord' class="btn" data='<?php 
$string2=json_encode(CMProducto::SPRCNSProducto(1,''));
echo $string2; ?>'><img src="../../../images/word.png" width="30" height="30"/> Word</button>
</td>
<td><button type='button' id='btnEExcel' class="btn" data='<?php 
echo $string2; ?>'><img src="../../../images/excel.png" width="30" height="30"/> Excel</button></td>
<td><button type='button' id='btnEPdf' class="btn" data='<?php 
echo $string2; ?>'><img src="../../../images/pdf.png" width="30" height="30"/> PDF</button></td>
</tr>
</table>
</div>
</form>
<div id="resultado">
<?php 
if(isset($_REQUEST['resultado'])) 
{
echo $_REQUEST['resultado'];
}
echo "</div>";
?>
</div>
</body>
</html>
