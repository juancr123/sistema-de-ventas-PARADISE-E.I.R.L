<?php
require '../../../Modelo/Mantenimiento/Categoria/CMCategoria.php';
$nombre_marca=$_GET["nombre2"];
$result=CMCategoria::SPRCNSCategoria();
if($result)
{
foreach($result as $fila)
{
if($fila['NOMBRE']==$nombre_marca)
{
echo "<option value='".$fila['ID_CATEGORIA']."' selected='selected'>".$fila['NOMBRE']."</option>";
}
else
{
echo "<option value='".$fila['ID_CATEGORIA']."'>".$fila['NOMBRE']."</option>";
}
}
}
?>
