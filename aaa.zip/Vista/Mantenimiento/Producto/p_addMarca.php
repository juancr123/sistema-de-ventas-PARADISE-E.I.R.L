<?php
require '../../../Modelo/Mantenimiento/Marca/CMMarca.php';
$nombre_marca=$_GET["nombre_marca"];
$result=CMMarca::ABMMarca("1","1",$nombre_marca);
if($result)
{
echo "1";
}
else
{
echo "2";
}
?>
