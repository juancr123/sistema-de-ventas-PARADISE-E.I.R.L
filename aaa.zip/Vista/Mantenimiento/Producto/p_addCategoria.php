<?php
require '../../../Modelo/Mantenimiento/Categoria/CMCategoria.php';
$nombre_marca=$_GET["nombre_categoria"];
$id_linea=$_GET["linea"];
$result=CMCategoria::ABMCategoria("1","1",$nombre_marca,$id_linea);
if($result)
{
echo "1";
}
else
{
echo "2";
}

?>
