<?php
require '../../../Modelo/Mantenimiento/Color/CMColor.php';
$nombre_marca=$_GET["nombre_color"];
$result=CMColor::ABMColor("1","1",$nombre_marca);
if($result)
{
echo "1";
}
else
{
echo "2";
}
?>
