<?php
require '../../../Modelo/Mantenimiento/Talla/CMTalla.php';
$nombre_marca=$_GET["nombre_talla"];
$id_categoria=$_GET["id_categoria"];
$result=CMTalla::ABMTalla("1","1",$nombre_marca,$id_categoria);
if($result)
{
echo "1";
}
else
{
echo "2";
}

?>
