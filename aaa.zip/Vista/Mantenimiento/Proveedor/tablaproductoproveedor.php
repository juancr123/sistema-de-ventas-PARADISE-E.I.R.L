<?php
require '../../../Modelo/Mantenimiento/Proveedor/CMProveedorProducto.php';
$id_proveedor=$_POST["id_proveedor"];
$result=CMProveedorProducto::SPRCNSProveedorProducto(1,$id_proveedor,'');
if(count($result)>0)
{
foreach($result as $fila)
{
echo "<tr onClick=jQuery.fn.Pulsar(this,event)>";
echo "<td>".$fila["id_pp"]."</td>";
echo "<td>".$fila["id_producto"]."</td>";
echo "<td>".$fila["Categoria"]." ".$fila["Marca"]." ".$fila["Modelo"]." ".$fila["Talla"]." ".$fila["Color"]."</td>";
echo "<td>".$fila["Unidad"]."</td>";
echo "<td>".$fila["precio_compra"]."</td>";
echo "</tr>";
}
}
?>
