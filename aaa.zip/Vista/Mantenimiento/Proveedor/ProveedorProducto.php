<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="../../../css/Mantenimiento/Proveedor/estilos.css" type="text/css" rel="stylesheet" />
<style type="text/css">
			@import "../../../jQuery/dataTable/css/demo_page.css";
			@import "../../../jQuery/dataTable/css/demo_table_jui.css";
			@import "../../../jQuery/dataTable/smoothness/jquery-ui-1.8.4.custom.css";
			</style>
<script type="text/javascript" src="../../../jQuery/jquery-1.7.2.js"></script>
<script type="text/javascript" language="javascript" src="../../../jQuery/dialog/ui/jquery-ui-1.8.7.custom.js"></script>
<script type="text/javascript" src="../../../jQuery/dataTable/js/jquery.dataTables.js"></script>
<script src="../../../jQuery/alerts/js/jquery.alerts.js" type="text/javascript"></script>
<script type="text/javascript" src="../../../js/Mantenimiento/Proveedor/funcionesPP.js"></script>
<link href="../../../jQuery/alerts/css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
</head>

<body>
<div id="datos">
<center>
<fieldset style="width:400px;">
<legend>Datos del Proveedor</legend>
<table width="400" border="0">
  <tr>
    <td><input type="text" id="id_proveedor2" readonly="true"  name="id_proveedor" /></td>
    <td><input type="text" id="ruc2" readonly="true" /></td>
    <td><input type="text" id="razon_social2" readonly="true"  /></td>
    <td><input type="text" id="nombres2" readonly="true" /></td>
	<td><button id="btnBuscarProveedor" style="width:100px;height:30px;" >Buscar <img src="../../../images/btn_acceso.png" width="20" height="20"/></button></td>
  </tr>
  <tr>
    <td><label>ID</label></td>
    <td><label>RUC</label></td>
    <td><label>RAZON SOCIAL</label></td>
    <td><label>NOMBRES</label></td>
  </tr>
</table>
</fieldset>

<fieldset style="width:500px;">
<legend>Datos del Producto</legend>
<table width="500" border="0">
  <tr>
    <td><input type="hidden" id="opcion"   name="opcion" />
	<input type="hidden" id="id_productoproveedor" value="1" />
	<input type="text" id="id_producto" readonly="true"/></td>
    <td><input type="text" id="descripcion" readonly="true" size="60"/></td>
    <td><input type="text" id="precio_compra" /></td>
    <td><button id="btnBuscarProducto"  style="width:100px;height:30px;" disabled="disabled">Buscar <img src="../../../images/btn_acceso.png" width="20" height="20"/></button></td>
  </tr>
  <tr>
<td><label>ID</label></td>
    <td align="center"><label>DESCRIPCION</label></td>
    <td><label>PRECIO COMPRA</label></td>
    
  </tr>
</table>

</fieldset></center>
</div>
<div id="informacion" class="demo_jui">
<table cellpadding="0" cellspacing="0" border="0" class="display" id="pp">
<thead>
<tr>
<th >N�</th>
<th >ID</th>
<th width="60%">Descripcion</th>
<th>Unidad</th>
<th >Precio Compra</th>
</tr>
</thead>
<tbody>
</tbody>
</table>
</div>
<div id="botones">
<table align='center' class="botones">
<tr>
<td><button name='btnNuevo2' type='button' id='btnNuevo2'><img src='../../../images/NUEVO1.png'><br/>Nuevo</button></td>
<td><button name='btnGuardar2' type='button' id='btnGuardar2'><img src='../../../images/save-icon.png'><br/>Guardar</button></td>
<td><button name='btnEditar2' type='button' id='btnEditar2' ><img src='../../../images/edit-icon (1).png'><br/>Editar</button></td>
<td><button name='btnCancelar2' type='button' id='btnCancelar2' ><img src='../../../images/Cancel-icon (1).png'><br/>Cancelar</button></td>
<td><button name='btnEliminar2' type='button' id='btnEliminar2' ><img src='../../../images/Delete-icon (2).png'><br/>Eliminar</button></td>
</tr>
</table>
</div>
<div id="botones">
</div>
<div id="resultado">
</div>
</body>
</html>
