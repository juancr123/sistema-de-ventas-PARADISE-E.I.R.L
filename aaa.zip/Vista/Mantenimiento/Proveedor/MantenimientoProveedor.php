<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css">
			@import "../../../jQuery/dataTable/css/demo_page.css";
			@import "../../../jQuery/dataTable/css/demo_table_jui.css";
			@import "../../../jQuery/dataTable/smoothness/jquery-ui-1.8.4.custom.css";
			</style>
			<link href="../../../css/Mantenimiento/Proveedor/estilosG.css" type="text/css" rel="stylesheet" />
		    <script type="text/javascript" src="../../../jQuery/jquery-1.7.2.js"></script>
			<link type="text/css" rel="stylesheet" href="../../../util/themes/base/jquery.ui.all.css" />
			
			<script type="text/javascript" src="../../../jQuery/dataTable/js/jquery.dataTables.js"></script>
			<script type="text/javascript" src="../../../jQuery/dialog/ui/jquery-ui-1.8.7.custom.js"></script>
<script type="text/javascript" src="../../../js/Mantenimiento/Proveedor/funcionesG.js"></script>
</head>
<body>
<div id="tabs">
<ul>
<li><a href="../../../Vista/Mantenimiento/Proveedor/Proveedor.php">Proveedor</a></li><!--cambiar el href si se va a hacer una vista desde el controlador-->
<li><a href="../../../Vista/Mantenimiento/Proveedor/ProveedorProducto.php">Producto - Proveedor</a></li>
</ul>
</div>
</body>
</html>
