<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css">
			@import "../../../jQuery/dataTable/css/demo_page.css";
			@import "../../../jQuery/dataTable/css/demo_table_jui.css";
			@import "../../../jQuery/dataTable/smoothness/jquery-ui-1.8.4.custom.css";
			</style>
			
<link href="../../../css/Mantenimiento/Proveedor/estilos.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="../../../jQuery/validacion/css/validationEngine.jquery.css" type="text/css" />
<script type="text/javascript" src="../../../jQuery/jquery-1.7.2.js"></script>
<script type="text/javascript" src="../../../jQuery/dataTable/js/jquery.dataTables.js"></script>
<script src="../../../jQuery/alerts/js/jquery.alerts.js" type="text/javascript"></script>
<script type="text/javascript" src="../../../jQuery/numeric/numeric.js"></script>
<script type="text/javascript" src="../../../jQuery/validacion/js/jquery.validationEngine-es.js"></script>
<script type="text/javascript" src="../../../jQuery/validacion/js/jquery.validationEngine.js"></script>
<script type="text/javascript" src="../../../js/Mantenimiento/Proveedor/funcionesP.js"></script>
<link href="../../../jQuery/alerts/css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body id="dt_example">
<form action="p_proveedor.php" method="post" id="nuevo_proveedor">
<div id="datos">
<table width="600" border="0" align="center" id="datos_proveedor">
  <tr>
    <td><input type="hidden" id="opcion" name="opcion"/>
	<input type="hidden" id="id_proveedor" name="id_proveedor" value="1"/>
	<input type="text" id="nombres" class="validate[required] text-input" name="nombres" /></td>
    <td><input type="text" id="apellidos" class="validate[required] text-input" name="apellidos"/></td>
    <td><input type="text" id="ruc" class="validate[required] text-input" name="ruc"/></td>
    <td><input type="text" id="razon_social" class="validate[required] text-input" name="razon_social" /></td>
  </tr>
  <tr>
    <td align="center"><label>NOMBRES</label></td>
    <td align="center"><label>APELLIDOS</label></td>
    <td align="center"><label>RUC</label></td>
    <td align="center"><label>RAZON SOCIAL</label></td>
  </tr>
  <tr>
    <td><input type="text" id="direccion" name="direccion" /></td>
    <td><select id="cmbProvincia" name="cmbProvincia">
	<?php
	require '../../../Modelo/util/CMProvinciaDistrito.php';
	$result=CMProvinciaDistrito::CNSProvincia();
	foreach($result as $fila)
	{
	if($fila['NOMBRE']=="HUAURA")
	{
	echo "<option value='".$fila['ID_PROVINCIA']."' selected='selected'>".$fila['NOMBRE']."</option>";
	}
	else
	{
	echo "<option value='".$fila['ID_PROVINCIA']."'>".$fila['NOMBRE']."</option>";
	}
	}
	?>
	</select></td>
    <td><select id="cmbDistrito" name="cmbDistrito">
	
	</select></td>
    <td><input type="text" id="telefono" name="telefono" /></td>
  </tr>
  <tr>
    <td align="center"><label>DIRECCION</label></td>
    <td align="center"><label>PROVINCIA</label></td>
    <td align="center"><label>DISTRITO</label></td>
    <td align="center"><label>TELEFONO</label></td>
  </tr>
   <tr>
    <td><input type="text" id="celular" name="celular" /></td>
    <td><input type="text" id="rpm" name="rpm" /></td>
    <td><input type="text" id="email" name="email" class="validate[required,custom[email]]" /></td>
    <td align="center"><input type="text" id="fax"  name="fax"/></td>
  </tr>
  <tr>
    <td align="center"><label>CELULAR</label></td>
    <td align="center"><label>RPM</label></td>
    <td align="center"><label>EMAIL</label></td>
    <td align="center"><label>FAX</label></td>
  </tr>
</table>
</div>
<div id="informacion" class="demo_jui">
<table cellpadding="0" cellspacing="0" border="0" class="display" id="proveedor">
<thead>
<tr>
<th style="width:20" >ID</th>
<th >Ruc</th>
<th >Razon Social</th>
<th >Nombres</th>
<th >Apellidos</th>
<th >Direccion</th>
<th >Provincia</th>
<th >Distrito</th>
<th >Telefono</th>
<th style="width:20">Celular</th>
<th style="width:20;">Rpm</th>
<th>Email</th>
<th>Fax</th>
</tr>
</thead>
<tbody>
<?php
require '../../../Modelo/Mantenimiento/Proveedor/CMProveedor.php';
$result=CMProveedor::SPRCNSProveedor(1,'');
if($result)
{
foreach($result as $fila)
{
echo "<tr>";
echo "<td class='center'>".$fila['id_proveedor']."</td>";
echo "<td class='center'>".$fila['ruc']."</td>";
echo "<td class='center'>".$fila['razon_social']."</td>";
echo "<td class='center'>".$fila['nombres']."</td>";
echo "<td class='center'>".$fila['apellidos']."</td>";
echo "<td class='center'>".$fila['direccion']."</td>";
echo "<td class='center'>".$fila['provincia']."</td>";
echo "<td class='center'>".$fila['distrito']."</td>";
echo "<td class='center'>".$fila['telefono']."</td>";
echo "<td class='center'>".$fila['celular']."</td>";
echo "<td class='center'>".$fila['rpm']."</td>";
echo "<td class='center'>".$fila['email']."</td>";
echo "<td class='center'>".$fila['fax']."</td>";
/*if($fila['estado']==1)
{
echo "<td class='center'><input type='checkbox' id='estado2'  checked='checked'/></td>";
}
else
{
echo "<td class='center'><input type='checkbox' id='estado2'/></td>";
}*/
echo "</tr>";
}
}
else
{
echo "No Hay Productos";
}
?>
</tbody>
</table>
</div>
<div id="botones">
<table align='center' class="botones">
<tr>
<td><button name='btnNuevo' type='button' id='btnNuevo'><img src='../../../images/NUEVO1.png'><br/>Nuevo</button></td>
<td><button name='btnGuardar' type='submit' id='btnGuardar'><img src='../../../images/save-icon.png'><br/>Guardar</button></td>
<td><button name='btnEditar' type='button' id='btnEditar' ><img src='../../../images/edit-icon (1).png'><br/>Editar</button></td>
<td><button name='btnCancelar' type='button' id='btnCancelar' ><img src='../../../images/Cancel-icon (1).png'><br/>Cancelar</button></td>
<td><button name='btnEliminar' type='submit' id='btnEliminar' ><img src='../../../images/Delete-icon (2).png'><br/>Eliminar</button></td>
<td><button name='btnSalir' type='button' id='btnSalir' ><br/>Salir</button></td>
</tr>
</table>
</div>
</form>
<div id="botones">
</div>
<div id="resultado">
</div>
</body>
</html>
