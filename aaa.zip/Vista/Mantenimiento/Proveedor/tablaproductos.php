<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="../../../css/Mantenimiento/Producto/estilos.css" type="text/css" rel="stylesheet" />
<style type="text/css">
			@import "../../../jQuery/dataTable/css/demo_page.css";
			@import "../../../jQuery/dataTable/css/demo_table_jui.css";
			@import "../../../jQuery/dataTable/smoothness/jquery-ui-1.8.4.custom.css";
			</style>
		    <script type="text/javascript" src="../../../jQuery/jquery-1.7.2.js"></script>
			<link type="text/css" rel="stylesheet" href="../../../util/themes/base/jquery.ui.all.css" />
			
			<script type="text/javascript" src="../../../jQuery/dataTable/js/jquery.dataTables.js"></script>
			<script type="text/javascript" src="../../../jQuery/dialog/ui/jquery-ui-1.8.7.custom.js"></script>
			<script type="text/javascript" src="../../../js/Mantenimiento/Proveedor/funcionestb_Productos.js"></script>
			
			<script src="../../../jQuery/alerts/js/jquery.alerts.js" type="text/javascript"></script>
            <link href="../../../jQuery/alerts/css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
			



</head>
<body id="dt_example">
<div id="informacion" class="demo_jui">
<table cellpadding="0" cellspacing="0" border="0" class="display" id="productos">
<thead>
<tr>
<th style="width:20" >ID</th>
<th >Categoria</th>
<th >Marca</th>
<th >Modelo</th>
<th >Color</th>
<th style="width:70">Talla</th>
<th >Unidad</th>
<th style="width:20">Precio</th>
<th style="width:20">Stock</th>
<th>Imagen</th>
</tr>
</thead>
<tbody>
<?php
require '../../../Modelo/Mantenimiento/Producto/CMProducto.php';
$result=CMProducto::SPRCNSProducto(1,'');
if(count($result)>0)
{
foreach($result as $fila)
{
echo "<tr>";
echo "<td class='center'>".$fila['id_producto']."</td>";
echo "<td class='center'>".$fila['linea']."</td>";
echo "<td class='center'>".$fila['Marca']."</td>";
echo "<td class='center'>".$fila['Modelo']."</td>";
echo "<td class='center'>".$fila['Color']."</td>";
echo "<td class='center'>".$fila['Talla']."</td>";
echo "<td class='center'>".$fila['Unidad']."</td>";
echo "<td class='center'>".$fila['precio_venta']."</td>";
echo "<td class='center'>".$fila['stock']."</td>";
if($fila['ruta_imagen']=="")
{
echo "<td class='center'>Sin imagen</td>";
}
else
{
echo "<td class='foto'><img src='../../../images/zapatillas/".$fila['ruta_imagen']."' width=80 height=60 /></td>";
}
echo "</tr>";
}
}
?>
</tbody>
</table>
</div>
<br />
<br />
<br />
<center><button type="button" id="btnAceptar">Aceptar</button></center>
</body>
</html>
