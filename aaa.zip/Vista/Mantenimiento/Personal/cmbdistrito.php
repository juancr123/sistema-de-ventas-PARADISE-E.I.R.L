<?php
require '../../../Modelo/util/CMProvinciaDistrito.php';
$id_provincia=$_POST['id_provincia'];
$result=CMProvinciaDistrito::CNSDistrito($id_provincia);
if($result)
{
foreach($result as $fila)
{
echo "<option value='".$fila['ID_DISTRITO']."'>".$fila['NOMBRE']."</option>";
}
}
?>
