<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="../../../css/Mantenimiento/Producto/estilos.css" type="text/css" rel="stylesheet" />
<style type="text/css">
			@import "../../../jQuery/dataTable/css/demo_page.css";
			@import "../../../jQuery/dataTable/css/demo_table_jui.css";
			@import "../../../jQuery/dataTable/smoothness/jquery-ui-1.8.4.custom.css";
			</style>
<script type="text/javascript" src="../../../jQuery/jquery-1.7.2.js"></script>
<script type="text/javascript" src="../../../jQuery/dataTable/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="../../../js/Mantenimiento/Personal/funciones.js"></script>
</head>
<body>
<form action="p_personal.php" method="post">
<div id="datos">
<table width="600" border="0" align="center" id="datos_proveedor">
  <tr>
    <td align="center"><input type="hidden" name="opcion" id="opcion" value="3"/>
	<input type="text" name="dni" id="dni" size="12" maxlength="11"/></td>
    <td align="center"><input type="text" name="nombres" id="nombres" /></td>
    <td align="center"><input type="text" name="apellidos" id="apellidos" /></td>
    <td align="center"><input type="text" name="direccion" id="direccion" /></td>
  </tr>
  <tr>
    <td align="center"><label>DNI</label></td>
    <td align="center"><label>NOMBRES</label></td>
    <td align="center"><label>APELLIDOS</label></td>
    <td align="center"><label>DIRECCION</label></td>
  </tr>
  <tr>
    <td align="center"><select name="provincia" id="provincia">
	<?php
	$result=CMProvinciaDistrito::CNSProvincia();
	foreach($result as $fila)
	{
	if($fila['NOMBRE']=="HUAURA")
	{
	echo "<option value='".$fila['ID_PROVINCIA']."' selected='selected'>".$fila['NOMBRE']."</option>";
	}
	else
	{
	echo "<option value='".$fila['ID_PROVINCIA']."'>".$fila['NOMBRE']."</option>";
	}
	}
	?>
	</select></td>
	<td align="center"><select id="distrito" name="distrito">
	<option>asdasd</option>
	
	</select></td>
    <td align="center"><input type="radio" value="M" name="sexo" id="sexo1" checked="checked"/>M<input type="radio" value="F" name="sexo" id="sexo2" />F</td>
    <td align="center"><input type="text" name="telefono" id="telefono" maxlength="8" size="12" /></td>
  </tr>
  <tr>
    <td align="center"><label>PROVINCIA</label></td>
    <td align="center"><label>DISTRITO</label></td>
    <td align="center"><label>SEXO</label></td>
    <td align="center"><label>TELEFONO</label></td>
  </tr>
   <tr>
    <td align="center"><input type="text" name="celular" id="celular" maxlength="9" size="12" /></td>
    <td align="center"><input type="text" name="email" id="email" /></td>
    <td align="center"><input type="password" name="clave" maxlength="16" id="clave" size="12" /></td>
    <td align="center"><select name="tipo" id="tipo">
	<?php
		$result=CMTipo_Personal::CNSTipo();
	foreach($result as $fila)
	{

	echo "<option value='".$fila['ID_TIPO_PERSONAL']."'>".$fila['NOMBRE']."</option>";
	
	}
	?>
	
	</select></td>
  </tr>
  <tr>
    <td align="center"><label>CELULAR</label></td>
    <td align="center"><label>EMAIL</label></td>
    <td align="center"><label>CLAVE</label></td>
    <td align="center"><label>TIPO</label></td>
  </tr>
</table>
</div>
<div id="informacion" class="demo_jui">
<table cellpadding="0" cellspacing="0" border="0" class="display" id="personal">
<thead>
<tr>
<th style="width:20" >DNI</th>
<th >Nombres</th>
<th >Apellidos</th>
<th >Provincia</th>
<th >Distrito</th>
<th >Direccion</th>
<th >Sexo</th>
<th style="width:70">Telefono</th>
<th >Celular</th>
<th style="width:20">Email</th>
<th >Clave</th>
<th style="width:20">tipo</th>
</tr>
</thead>
<tbody>
<?php
$result=CMPersonal::CNSPersonal(1,'');
if($result)
{
foreach($result as $fila)
{
echo "<tr>";
echo "<td class='center'>".$fila['ID_PERSONAL']."</td>";
echo "<td class='center'>".$fila['NOMBRES']."</td>";
echo "<td class='center'>".$fila['APELLIDOS']."</td>";
echo "<td class='center'>".$fila['PROVINCIA']."</td>";
echo "<td class='center'>".$fila['DISTRITO']."</td>";
echo "<td class='center'>".$fila['DIRECCION']."</td>";
echo "<td class='center'>".$fila['SEXO']."</td>";
echo "<td class='center'>".$fila['TELEFONO']."</td>";
echo "<td class='center'>".$fila['CELULAR']."</td>";
echo "<td class='center'>".$fila['EMAIL']."</td>";
echo "<td class='center'>".$fila['CLAVE']."</a></td>";
echo "<td class='center'>".$fila['TIPO']."</td>";
echo "</tr>";
}
}
else
{
echo "No Hay datos";
}
?>
</div>
<div id="botones">
<table align='center' class="botones">
<tr>
<td><button name='btnNuevo' type='button' id='btnNuevo'><img src='../../../images/NUEVO1.png'><br/>Nuevo</button></td>
<td><button name='btnGuardar' type='submit' id='btnGuardar'><img src='../../../images/save-icon.png'><br/>Guardar</button></td>
<td><button name='btnEditar' type='button' id='btnEditar' ><img src='../../../images/edit-icon (1).png'><br/>Editar</button></td>
<td><button name='btnCancelar' type='button' id='btnCancelar' ><img src='../../../images/Cancel-icon (1).png'><br/>Cancelar</button></td>
<td><button name='btnEliminar' type='submit' id='btnEliminar' ><img src='../../../images/Delete-icon (2).png'><br/>Eliminar</button></td>
</tr>
</table>
</div>
</form>
<div id="resultado">
<?php 
if(isset($_REQUEST['resultado'])) 
{
echo $_REQUEST['resultado'];
}
?>
</div>
</body>
</html>
