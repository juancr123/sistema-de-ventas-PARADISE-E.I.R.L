<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Mantenimiento Linea</title>
<style type="text/css">
			@import "../../../jQuery/dataTable/css/demo_page.css";
			@import "../../../jQuery/dataTable/css/demo_table_jui.css";
			@import "../../../jQuery/dataTable/smoothness/jquery-ui-1.8.4.custom.css";
			
		</style>
<script type="text/javascript" src="../../../jQuery/jquery-1.7.2.js"></script>
<script type="text/javascript" src="../../../jQuery/dataTable/js/jquery.dataTables.js"></script>
<script type="text/javascript" language="javascript" src="../../../js/Mantenimiento/Linea/funciones.js"></script>
<script type="text/javascript" language="javascript" src="../../../js/Mantenimiento/Linea/funcionesJQuery.js"></script>
<link href="../../../css/Mantenimiento/Linea/estilos.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body id="dt_example" onload="body_onLoad()">
<form action="p_linea.php" method="post">
<div id='datos'>
<table align='center'>
<tr>
<td>
<input type='hidden' id='opcion' name='opcion' value="1"/>
<input type='hidden' id='id_linea' name='id_linea' value="0"/>
<input type='text' id='txtLinea' name="txtLinea"/></td>
</tr>
<tr>
<td colspan='2'><label>NOMBRE DE LINEA</label></td>
</tr>
</table>
</div>
<div id='informacion'>
<div class='demo_jui'>
<table cellpadding='0' cellspacing='0'  border='0' class='display' id='linea'>
<thead>
<tr>
<th >ID</th>
<th >Linea</th>
</tr>
</thead>
<tbody>
<?php
$result=CMLinea::VIEWLinea();
if($result)
{
foreach($result as $row )
{
echo"<tr onClick=pulsar2(this,event)>";
echo "<td class='center'>".$row['ID_LINEA']."</td>";
echo "<td class='center'>".$row['NOMBRE']."</td>";
echo "</tr>";
}
}
else
{
echo "No Hay Datos";
}
echo "</div>";
?>
</tbody>
</table>
</div>
<div id='botones'>
<table align='center'>
<tr>
<td><button name='btnNuevo' type='button' id='btnNuevo' onClick='btnNuevo_onClick()'><img src='../../../images/NUEVO1.png'><br/>Nuevo</button></td>
<td><button name='btnGuardar' type='submit' id='btnGuardar'><img src='../../../images/save-icon.png'><br/>Guardar</button></td>
<td><button name='btnEditar' type='button' id='btnEditar' onClick='btnEditar_onClick()'><img src='../../../images/edit-icon (1).png'><br/>Editar</button></td>
<td><button name='btnCancelar' type='button' id='btnCancelar' onClick='btnCancelar_onClick()'><img src='../../../images/Cancel-icon (1).png'><br/>Cancelar</button></td>
<td><button name='btnEliminar' type='submit' id='btnEliminar' onClick='btnEliminar_onClick()'><img src='../../../images/Delete-icon (2).png'><br/>Eliminar</button></td>
</tr>
</table>
</div>
</form>
<div id='resultado' align='center'>
<?php
if(isset($_REQUEST['resultado'])) 
{
echo $_REQUEST['resultado'];
}
echo "</div>";
?>
</body>
</html>
