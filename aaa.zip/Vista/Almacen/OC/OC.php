<html>
<head>
<link type="text/css" rel="stylesheet" href="../../../css/Almacen/estilos.css"/>
<link type="text/css" rel="stylesheet" href="../../../jQuery/dialog/themes/base/jquery.ui.all.css" />
<style type="text/css">
			@import "../../../jQuery/dataTable/css/demo_page.css";
			@import "../../../jQuery/dataTable/css/almacen/demo_table_jui.css";
			</style>
<script type="text/javascript" language="javascript" src="../../../jQuery/jquery-1.3.2.js"></script>
<script type="text/javascript" language="javascript" src="../../../jQuery/dialog/ui/jquery-ui-1.8.7.custom.js"></script>
<script type="text/javascript" language="javascript" src="../../../jQuery/dataTable/js/jquery.dataTables.js"></script>
<script type="text/javascript" language="javascript" src="../../../js/Almacen/funciones.js"></script>
<link href="../../../jQuery/alerts/css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
<script src="../../../jQuery/alerts/js/jquery.alerts.js" type="text/javascript"></script>
</head>
<body>
<?php
require '../../../Modelo/Almacen/CMCompras.php';
require '../../../Modelo/Almacen/CMDetalleCompras.php';
$opcionFormulario=$_GET["opcionFormulario"];
if($opcionFormulario==2 || $opcionFormulario==3)
{
if(isset($_GET["id_compra"]))
{
$id_compra=$_GET["id_compra"];
$resultCompra=CMCompras::CNSCompras(1,$id_compra);
foreach($resultCompra as $fila)
{
$id_compra=$fila["ID_COMPRA"];
$id_proveedor=$fila["ID_PROVEEDOR"];
$razon_social=$fila["RAZON_SOCIAL"];
$nombres=$fila["NOMBRES"]." ".$fila["APELLIDOS"];
$fecha_compra=$fila["FECHA"];
$subtotal=$fila["SUBTOTAL"];
$ruc=$fila["RUC"];
$telefono=$fila["TELEFONO"];
$igv=$fila["IGV"];
$total=$fila["TOTAL"];
}
}
?>
<table align="center">
<tr>
<td>ID Orden de Compra :</td>
<td>
<input type="text" id="id_compra" disabled="disabled" class="inp" value="<?php if(isset($_GET["id_compra"])) { echo $id_compra; }?>" /></td>
<td colspan="2" align="center">Buscar Orden Compra :</td><td><button type="button" id="btnBuscarOC" class="btn2">Buscar</button></td>
</tr>
</table>
<?php
}
?>
<div id="cabecera">
<table align="center">
<tr>
<td>Codigo : </td><td>
<input type="hidden" id="opcion" value="<?php echo $opcionFormulario; ?>"/>
<input type="text" id="id_proveedor" class="inp"  disabled="disabled" readonly value="<?php if(isset($_GET["id_compra"]))
{
 echo $id_proveedor; 
 }?>" /></td><td>Razon Social :</td><td><input type="text" class="inp" id="RS" disabled="disabled" readonly value="<?php if(isset($_GET["id_compra"]))
{
 echo $razon_social; }?>" /></td>
<?php 
if($opcionFormulario==1)
{
?>
<td>
<!-- <button id="btnNuevoProveedor"  class="btn2" disabled="disabled">Nuevo</button>-->
</td>
<?php
}
?>
</tr>
<tr>
<td>Nombres y Apellidos : </td><td colspan="3"><input type="text" class="inp" id="Nombres" readonly disabled="disabled" size="60" value="<?php if(isset($_GET["id_compra"]))
{ echo $nombres; }?>" /></td>
<?php 
if($opcionFormulario==1)
{
?>
<td>
<button id="btnBuscarProveedor"  class="btn2" disabled="disabled">Buscar</button>
</td>
<?php
}
?>
</tr>
<tr>
<td>RUC :</td><td><input type="text" id="ruc" class="inp" disabled="disabled" readonly value="<?php if(isset($_GET["id_compra"]))
{ echo $ruc; }?>" /></td><td>Telefono :</td><td><input type="text" class="inp" readonly id="telefono" disabled="disabled" value="<?php if(isset($_GET["id_compra"]))
{ echo $telefono; }?>"/></td>
</tr>
</table>
<table align="center">
<tr>
<td colspan="2" align="right">
Fecha :
</td>
<td colspan="2">
<input type="text" id="fecha" class="inp" disabled="disabled" <?php if(isset($_GET["id_compra"]))
{
echo "value='$fecha_compra'";
}
?>/>
</td>
</tr> 
</table>
<br>
</div>
<div id="AddDel">
<?php if($opcionFormulario!=3)
{
?>
<table align="right">
<tr>
<td>
<button id="mas" type="button" <?PHP if(!isset($_GET["id_compra"]))
echo 'disabled="disabled"'; 
?> style="width:65;height:65;" <?php if(isset($_GET["id_compra"]))
{
echo "value='$subtotal' ";
}
?>><img src="../../../images/Add-icon.png" width="20" height="20"></button>
</td>
</tr>
<tr>
<td>
<button id="menos" type="button" <?PHP if(!isset($_GET["id_compra"]))
echo 'disabled="disabled"'; 
?> style="width:65;height:65;" <?php if(isset($_GET["id_compra"]))
{
echo "value='$subtotal' ";
}
?>><img src="../../../images/Delete-icon (1).png" width="20" height="20"></button>
</td>
</tr>
</table>
<?php
}
?>
</div>
<div id="detalleOC">
<div class="demo_jui">
<table cellpadding="0" cellspacing="0" border="0" class="display" id="almacen">
      <thead>
      <th width="5%">IdProducto</th><th width="80%">Descripcion</th><th width="5%">P.Compra</th><th width="5%">Cantidad</th>
<th width="5%">Costo</th>
      </thead>
	  <tbody>
	 <?PHP
	 if(isset($_GET["id_compra"]))
	 {
$resultDetalleCompra=CMDetalleCompras::CNSDetalleCompras($id_compra,$id_proveedor);
if($resultDetalleCompra)
{
foreach($resultDetalleCompra as $fila2)
{
$id_producto=$fila2["ID_PRODUCTO"];
$descripcion=$fila2["DESCRIPCION"];
$precio_compra=$fila2["PRECIO_COMPRA"];
$costo=$fila2["COSTO"];
$cantidad=$fila2["CANTIDAD"];
echo "<tr>";
echo "<td>".$id_producto."</td>";
echo "<td>".$descripcion."</td>";
echo "<td>".$precio_compra."</td>";
echo "<td>".$cantidad."</td>";
echo "<td>".$costo."</td>";
echo "</tr>";
}
}
}
?>
</tbody>
</table>
</div>
</div>
<div id="descuentos">
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
Estado :<input type="checkbox" class="inp" id="estado" name="estado" <?php
if(!isset($_GET["id_compra"]))
echo 'disabled="disabled"';
?> />
<table align="right">  
<tr>
<td>SubTotal :</td>
<td>
<input type="text" id="subtotal" class="inp" disabled="disabled" 
<?php if(isset($_GET["id_compra"]))
{
echo "value='$subtotal'";
}
?>/>
</td>
</tr>
<tr>
<td>IGV :</td>
<td>
<input type="text" id="igv" class="inp" disabled="disabled" 
<?php if(isset($_GET["id_compra"]))
{
echo "value='$igv'";
}
?> />
</td>
</tr>
<tr>
<td>Total :</td>
<td>
<input type="text" id="total" class="inp" disabled="disabled" 
<?php if(isset($_GET["id_compra"]))
{
echo "value='$total'";
}
?>/>
</td>
</tr>
</table>
</div>
<div id="botones">
<center>
<input type="button" class="btn" id="btnGuardar" value="<?php
if($opcionFormulario==1)
{
echo "NUEVO";
}
else if($opcionFormulario==2)
{
echo "ACTUALIZAR";
}
else
{
echo "ELIMINAR";
}
?>" /></center>
</div>
<div id="resultado" align="center">
<?php
if(isset($_REQUEST['resultado'])) 
{
echo $_REQUEST['resultado'];
}
?>
</div>
</body>
</html>
