<html>
<head>
<link type="text/css" rel="stylesheet" href="../../../jQuery/dialog/themes/base/jquery.ui.all.css" />
<style type="text/css">
			@import "../../../jQuery/dataTable/css/demo_page.css";
			@import "../../../jQuery/dataTable/css/demo_table_jui.css";
		</style>
<script type="text/javascript" language="javascript" src="../../../jQuery/jquery-1.4.4.js"></script>
<script type="text/javascript" src="../../../jQuery/numeric/numeric.js"></script>
<script type="text/javascript" language="javascript" src="../../../jQuery/dialog/ui/jquery-ui-1.8.7.custom.js"></script>
<script type="text/javascript" language="javascript" src="../../../jQuery/dataTable/js/jquery.dataTables.js"></script>
<script src="../../../jQuery/alerts/js/jquery.alerts.js" type="text/javascript"></script>
<link href="../../../jQuery/alerts/css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" language="javascript" src="../../../js/Almacen/funciones.js"></script>
<style type="text/css">
.btn{
width:100px;
height:30px;
font-weight:bold;
border:2px solid #0099FF;
border-radius:10px;
background-color:#333333;
color:#FFFFFF;
}
.dataTables_wrapper {
	min-height: 150px;
	_height: 150px;
}
</style>
<script type="text/javascript">
$(document).ready(function(){
 $('#cantidad').numeric();
});
</script>
</head>
<body>
<div class="demo_jui">
<table cellpadding="0" cellspacing="0" border="0" class="display" id="productos_proveedor">
<thead>
<tr>
<th >ID</th>
<th >Categoria</th>
<th >Marca</th>
<th >Modelo</th>
<th >Talla</th>
<th >Color</th>
<th >Unidad</th>
<th >PCompra</th>
</tr>
</thead>
<tbody>
<?php
$id_proveedor=$_GET['id_proveedor'];
$result =CMProveedorProducto::SPRCNSProveedorProducto(1,$id_proveedor,'');
if(count($result)>0)
{
foreach($result as $fila)
{
echo "<tr onClick=jQuery.fn.Pulsar(this,event)>";
echo "<td class='center'>".$fila["id_producto"]."</td>";
echo "<td class='center'>".$fila["Categoria"]."</td>";
echo "<td class='center'>".$fila["Marca"]."</td>";
echo "<td class='center'>".$fila["Modelo"]."</td>";
echo "<td class='center'>".$fila["Talla"]."</td>";
echo "<td class='center'>".$fila["Color"]."</td>";
echo "<td class='center'>".$fila["Unidad"]."</td>";
echo "<td class='center'>".$fila["precio_compra"]."</td>";
echo "</tr>";
}
}
?>
</tbody>
</table>
</div>
<table align="center">
<tr>
<td>CANTIDAD : </td>
<td><input type="text" id="cantidad" />
</td>
</tr>
</table>
<table align="center">
<tr>
<td>
<button id="addProducto" class="btn"><img src="../../../images/accept.PNG"> Aceptar</button>
</td>
</tr>
</table>
</body>
</html>
