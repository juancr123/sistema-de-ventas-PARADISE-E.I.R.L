<html>
<head>
<style type="text/css">
			@import "../../../jQuery/dataTable/css/demo_page.css";
			@import "../../../jQuery/dataTable/css/almacen/demo_table_jui_proveedores.css";
			@import "../../../jQuery/dataTable/smoothness/jquery-ui-1.8.4.custom.css";
					</style>
<script type="text/javascript" src="../../../jQuery/jquery-1.7.2.js"></script>
<script type="text/javascript" src="../../../jQuery/dialog/ui/jquery-ui-1.8.7.custom.js"></script>
<script type="text/javascript" language="javascript" src="../../../jQuery/dataTable/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="../../../js/Almacen/funcionestb_P.js"></script>
<style type="text/css">
#informacion{
width:750px;
height:250px;
}
.btn2{
width:120px;
height:40px;
font-weight:bold;
border:2px solid #0099FF;
border-radius:10px;
background-color:#333333;
color:#FFFFFF;
}
</style>
</head>
<body>
<div id="informacion">
<div class="demo_jui">
<table cellpadding="0" cellspacing="0" class='display' border="0"  id="proveedores" style="width:750px">
<thead>
<tr>
<th width="5%">ID</th>
<th width="10%">RUC</th>
<th width="20%">Razon Social</th>
<th width="20%">Nombres</th>
<th width="20%">Apellidos</th>
<th width="15%">Telefono</th>
<th width="15%">Celular</th>
</tr>
</thead>
<tbody>
<?php
$result =CMProveedor::SPRCNSProveedor(1,'');
if($result)
{
foreach($result as $fila)
{
echo "<tr onClick=jQuery.fn.Pulsar(this,event)>";
echo "<td class='center'>".$fila["id_proveedor"]."</td>";
echo "<td class='center'>".$fila["ruc"]."</td>";
echo "<td class='center'>".$fila["razon_social"]."</td>";
echo "<td class='center'>".$fila["nombres"]."</td>";
echo "<td class='center'>".$fila["apellidos"]."</td>";
echo "<td class='center'>".$fila["telefono"]."</td>";
echo "<td class='center'>".$fila["celular"]."</td>";
echo "</tr>";
}
}
else
{
echo "No Hay datos";
}
?>
</tbody>
</table>
</div>
</div>
<table align="center">
<tr>
<td>
<button id="btnAgregarProveedor"  class="btn2">Aceptar</button>
</td>
</tr>
</table>
</body>
</html>
