<html>
<head>
</head>
<link type="text/css" rel="stylesheet" href="../../../jQuery/dialog/themes/base/jquery.ui.all.css" />
<style type="text/css">
			@import "../../../jQuery/dataTable/css/demo_page.css";
			@import "../../../jQuery/dataTable/css/demo_table_jui.css";
			
			
		</style>
<script type="text/javascript" language="javascript" src="../../../jQuery/jquery-1.4.4.js"></script>
<script type="text/javascript" language="javascript" src="../../../jQuery/dialog/ui/jquery-ui-1.8.7.custom.js"></script>
<script type="text/javascript" language="javascript" src="../../../jQuery/dataTable/js/jquery.dataTables.js"></script>
<script type="text/javascript" language="javascript" src="../../../js/Almacen/funcionestb_Compra.js"></script>
<body>

<div class="demo_jui">
<table cellpadding="0" cellspacing="0" border="0" class="display" id="tb_compras" align="center">
<thead>
<tr>
<th width="10%">ID Compra</th>
<th width="12%">ID Proveedor</th>
<th >Razon Social</th>
<th >Nombres</th>
<th width="16%">Fecha</th>
<th >Total</th>
</tr>
</thead>
<tbody>
<?php
$result =CMCompras::CNSCompras(3,'');
if(count($result)>0)
{
foreach($result as $fila)
{
echo "<tr onClick=jQuery.fn.Pulsar(this,event)>";
echo "<td class='center'>".$fila["ID_COMPRA"]."</td>";
echo "<td class='center'>".$fila["ID_PROVEEDOR"]."</td>";
echo "<td class='center'>".$fila["RAZON_SOCIAL"]."</td>";
echo "<td class='center'>".$fila["NOMBRES"]." ".$fila["APELLIDOS"]."</td>";
echo "<td class='center'>".$fila["FECHA"]."</td>";
echo "<td class='center'>".$fila["TOTAL"]."</td>";
echo "</tr>";
}
}
?>
</tbody>
</table>
<br>
<table align="center">
<tr>
<td>
<button id="btnAgregarCompra" ><img src="../../../images/accept.PNG"> Aceptar</button>
</td>
</tr>
</table>
</body>
</html>
