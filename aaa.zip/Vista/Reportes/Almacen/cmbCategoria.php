<?php
require '../../../Modelo/Mantenimiento/Categoria/CMCategoria.php';
$id_linea=$_GET["id_linea"];
$result=CMCategoria::getCategoria($id_linea);
foreach($result as $fila)
{
echo "<option value='".$fila['ID_CATEGORIA']."'>".$fila['NOMBRE']."</option>";
}
?>
