<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<script type="text/javascript" src="../../../jQuery/jquery-1.7.2.js"></script>
<script type="text/javascript" src="../../../js/Reportes/Almacen/funciones.js"></script>
<link href="../../../css/Reportes/Almacen/estilos.css" type="text/css" rel="stylesheet" />
</head>
<body>
<table align="center" id="reporte_almacen">
<tr>
<td><input type="checkbox" disabled="disabled" checked="checked" /> &nbsp;&nbsp;<b>Linea</b></td>
<td><input type="checkbox" id="chkCategoria" /> &nbsp;<b>Categoria</b>&nbsp;&nbsp;
<select id="linea">
<?php
$result2=CMLinea::VIEWLinea();
if(count($result2))
{
foreach($result2 as $fila2)
{
echo "<option value='".$fila2["ID_LINEA"]."'>".$fila2["NOMBRE"]."</option>";
}
}
?>
</select></td>
<td>&nbsp;&nbsp;&nbsp;<input type="checkbox" id="chkMarca" disabled="disabled"/> &nbsp;&nbsp;<b>Marca</b> &nbsp;&nbsp;
<select id="categoria" disabled="disabled">
<?php
$result2=CMCategoria::SPRCNSCategoria();
if(count($result2))
{
foreach($result2 as $fila2)
{
echo "<option value='".$fila2["ID_CATEGORIA"]."'>".$fila2["NOMBRE"]."</option>";
}
}
?>
</select></td>
</tr>
<tr>
<td colspan="3" align="center"><br /><button type="button" id="btnVer" class="btn"><img src="../../../images/buscar.png" width="25" height="25"/> Ver</button></td>
</tr>
</table>
</body>
</html>
