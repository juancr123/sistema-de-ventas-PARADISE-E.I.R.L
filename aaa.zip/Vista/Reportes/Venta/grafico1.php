<?php
require '../../../Modelo/Venta/CMVenta.php';
require '../../../fusionChart/funciones_php/FusionCharts.php';
?>
<center>
<?php
$anio=$_REQUEST['anio'];
$mes=$_REQUEST['mes'];
$opcion=$_REQUEST['opcion'];
$opcionReporte=$_REQUEST['opcionReporte'];
if($opcionReporte==1)
{
$result=CMVenta::SPRCNSVentas($anio,$mes,$opcion);
if($result)
{
$i=0;
foreach($result as $fila)
{
$arregloLabel[$i]=$fila['Mes'];
$arregloValues[$i]=$fila['Cantidad'];
$i++;
}
}
}
else if($opcionReporte==2)
{
$result=CMVenta::SPRCNSVentasxLinea($anio,$mes,$opcion);
if($result)
{
$i=0;
foreach($result as $fila)
{
$arregloLabel[$i]=$fila['Linea'];
$arregloValues[$i]=$fila['Cantidad'];
$i++;
}
}
}
else if($opcionReporte==3)
{
$result=CMVenta::SPRCNSVentasxMarca($anio,$mes,$opcion);
if($result)
{
$i=0;
foreach($result as $fila)
{
$arregloLabel[$i]=$fila['Marca'];
$arregloValues[$i]=$fila['Cantidad'];
$i++;
}
}
}
else if($opcionReporte==4)
{
$result=CMVenta::SPRCNSVentasxCategoria($anio,$mes,$opcion);
if($result)
{
$i=0;
foreach($result as $fila)
{
$arregloLabel[$i]=$fila['Categoria'];
$arregloValues[$i]=$fila['Cantidad'];
$i++;
}
}
}
$strXML = "";
// Armo los par�metros para el gr�fico. Todos estos datos se concatenan en una variable.
// Encabezado de la variable XML. Comienza con la etiqueta "Chart".
// caption: define el t�tulo del gr�fico.
// bgColor: define el color de fondo que tendr� el gr�fico.
// baseFontSize: Tama�o de la fuente que se usar� en el gr�fico.
// showValues: = 1 indica que se mostrar�n los valores de cada barra. = 0 No mostrar� los valores en el gr�fico.
// xAxisName: define el texto que ir� sobre el eje X. Abajo del gr�fico. Tambi�n est� xAxisName.
$strXML = "<chart caption = 'Reporte de Ventas Paradise' bgColor='#CDDEE5' baseFontSize='12' showValues='1'>";
// Genero los enlaces que ir� en cada barra del gr�fico.
// Llamo a una funci�n javascript llamado "detalleAnios". Tambi�n envio par�metros como el t�tulo, total en semestre 1 y total en semestre 2
// La suma de las variables total de los semestres, enviados como par�metros, es igual al total del A�o en cuesti�n.
// La funci�n javascript que recibe estos datos se encuentra en el archivo "js/ajax.js"
// La funci�n javascript, lo que hace es enviar los par�metros a un archivo llamado "grafico2.php" para que genere el gr�fico detalle.
// Una vez generado el gr�fico detalle, se desplegar� en el DIV "detalle_chart". Haci�ndose ahora visible.
// Armado de cada barra.
// set label: asigno el nombre de cada barra.
// value: asigno el valor para cada barra.
// color: color que tendr� cada barra. Si no lo defino, tomar� colores por defecto.
// Asigno los enlaces para cada barra.
for($j=0;$j<count($arregloLabel);$j++)
{
$strXML .= "<set label = '".$arregloLabel[$j]."' value ='".$arregloValues[$j]."' color = 'EA1000' />";
}
// Cerramos la etiqueta "chart".
$strXML .= "</chart>";
// Por �ltimo imprimo el gr�fico.
// renderChartHTML: funci�n que se encuentra en el archivo FusionCharts.php
// Env�a varios par�metros.
// 1er par�metro: indica la ruta y nombre del archivo "swf" que contiene el gr�fico. En este caso Columnas ( barras) 3D
// 2do par�metro: indica el archivo "xml" a usarse para graficar. En este caso queda vac�o "", ya que los par�metros lo pasamos por PHP.
// 3er par�metro: $strXML, es el archivo par�metro para el gr�fico. 
// 4to par�metro: "ejemplo". Es el identificador del gr�fico. Puede ser cualquier nombre.
// 5to y 6to par�metro: indica ancho y alto que tendr� el gr�fico.
// 7mo par�metro: "false". Trata del "modo debug". No es im,portante en nuestro caso, pero pueden ponerlo a true ara probarlo.
echo renderChartHTML("../../../fusionChart/swf_charts/Column3D.swf", "",$strXML, "Reporte",550, 450, false);
?></center>
