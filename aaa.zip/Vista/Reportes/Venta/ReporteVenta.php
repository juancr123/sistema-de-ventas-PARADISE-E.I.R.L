<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
 <script type="text/javascript" src="../../../js/ajax/ajax.js"></script>
 <script type="text/javascript" src="../../../jQuery/jquery-1.7.2.js"></script>
	<link type="text/css" rel="stylesheet" href="../../../jQuery/dialog/themes/base/jquery.ui.all.css" />
	<script type="text/javascript" src="../../../jQuery/dialog/ui/jquery-ui-1.8.7.custom.js"></script>
	<script type="text/javascript" src="../../../js/Reportes/Venta/funcionesG.js"></script>
<style type="text/css">
#reporte_venta{
border:2px solid #333333;
border-radius:20px;
padding:5px;
box-shadow:10px 10px 8px hsla(0,0%,0%,3);
}
.btn{
width:80px;
height:40px;
font-weight:bold;
border:2px solid #999999;
border-radius:10px;
background-color:#333333;
color:#FFFFFF;
}
</style>
</head>
<body>
<div id="datos">
<table align="center" id="reporte_venta">
<tr>
<td><input type="checkbox" value="" id="chkPeriodo"  checked="checked" disabled="disabled" /></td><td>A�o :</td><td><select id="cmbAnio">
<option value="2005">2005</option>
<option value="2006">2006</option>
<option value="2007">2007</option>
<option value="2008">2008</option>
<option value="2009">2009</option>
<option value="2010">2010</option>
<option value="2011">2011</option>
<option value="2012" selected="selected">2012</option>
<option value="2013">2013</option>
<option value="2014">2014</option>
<option value="2015">2015</option>
</select></td>
<td><input type="checkbox" id="chkMes"/></td>
<td>Mes :</td>
<td><select id="cmbMes" disabled="disabled">
<option value="Enero">Enero</option>
<option value="Febrero">Febrero</option>
<option value="Marzo">Marzo</option>
<option value="Abril">Abril</option>
<option value="Mayo">Mayo</option>
<option value="Junio">Junio</option>
<option value="Julio">Julio</option>
<option value="Agosto">Agosto</option>
<option value="Setiembre">Setiembre</option>
<option value="Octubre">Octubre</option>
<option value="Noviembre">Noviembre</option>
<option value="Diciembre">Diciembre</option>
</select></td>
</tr>
<tr>
<td><input type="checkbox" id="chkProducto" /></td>
<td colspan="2"><input type="radio" name="rbProducto" id="rbProducto" disabled="disabled" checked="checked"  value=2/>LINEA
</td>
<td colspan="2"><input type="radio" name="rbProducto" id="rbProducto" disabled="disabled"  value=3 />MARCA
</td>
<td colspan="2"><input type="radio" name="rbProducto" id="rbProducto" disabled="disabled"   value=4 />CATEGORIA
</td>
</tr>
<tr>
<td colspan="7" align="center"><button id="btnOk" class="btn">OK</button></td>
</tr>
</table>
<br />
</div>
<div id="tabs">
<ul>
<li><a href="#Grafico1">Grafico 1</a></li><!--cambiar el href si se va a hacer una vista desde el controlador-->
<li><a href="#Grafico2">Grafico 2</a></li>
<li><a href="#Grafico3">Grafico 3</a></li>
</ul>

<div id="tab_container">
<div id="Grafico1">

</div>
<div id="Grafico2">

</div>
<div id="Grafico3">

</div>
</div>
</div>
</body>
</html>
