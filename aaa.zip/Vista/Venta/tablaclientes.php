<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<link href="../../../jQuery/dataTable/css/demo_page.css" rel="stylesheet" type="text/css" />
<link href="../../../jQuery/dataTable/css/demo_table_jui.css" rel="stylesheet" type="text/css"  />
<style type="text/css">
@import "../../../jQuery/dataTable/smoothness/jquery-ui-1.8.4.custom.css";
			@import "../../../css/Venta/estilosInputs.css";
					</style>

	<script type="text/javascript" language="javascript" src="../../../jQuery/dataTable/js/jquery.js"></script>
<script type="text/javascript" language="javascript" src="../../../jQuery/dataTable/js/jquery.dataTables.js"></script>
<script type="text/javascript" language="javascript" src="../../../js/Venta/funciones.js"></script>
<script type="text/javascript" language="javascript" src="../../../js/Venta/init.js"></script>
</head>
<body id="dt_example">
<div class="demo_jui">
<table cellpadding="0" cellspacing="0" border="0" class="display"  id="Clientes">
      <thead>
      	<tr><th width="5%">ID</th><th>Nombre</th><th>Apellidos</th><th width="8%">Distrito</th><th>Direccion</th><th>DNI</th><th>RUC</th>
<th>Telefono</th>
<th>Celular</th>
</tr>
      </thead>
      <tbody>
<?php
$result =CMCliente::SPRCNSCliente();
if($result)
{
foreach($result as $fila)
{
echo "<tr>";
echo "<td>".$fila['id_cliente']."</td>";
echo "<td>".$fila['nombres']."</td>";
echo "<td>".$fila['apellidos']."</td>";
echo "<td>".$fila['Distrito']."</td>";
echo "<td>".$fila['direccion']."</td>";
echo "<td>".$fila['dni']."</td>";
echo "<td>".$fila['ruc']."</td>";
echo "<td>".$fila['telefono']."</td>";
echo "<td>".$fila['celular']."</td>";
echo "</tr>";
}
}
else
{
echo "No Hay Clientes";
}
?>
</tbody>
</table>
<center><input type="button" id="aceptarcliente" class="btn2" value="ACEPTAR"></center>
</div>
</body>
</html>