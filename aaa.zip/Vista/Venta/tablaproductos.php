<html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<title>DataTables example</title>
<style type="text/css">
@import "../../../jQuery/dataTable/smoothness/jquery-ui-1.8.4.custom.css";
			@import "../../../css/Venta/estilosInputs.css";
			@import "../../../jQuery/dataTable/css/demo_page.css";
			@import "../../../jQuery/dataTable/css/demo_table_jui.css";
			@import "../../../jQuery/dataTable/smoothness/jquery-ui-1.8.4.custom.css";
					</style>
<script type="text/javascript" src="../../../jQuery/jquery-1.7.2.js"></script>
<script type="text/javascript" src="../../../jQuery/numeric/numeric.js"></script>
<script type="text/javascript" src="../../../jQuery/dialog/ui/jquery-ui-1.8.7.custom.js"></script>
<script type="text/javascript" language="javascript" src="../../../jQuery/dataTable/js/jquery.dataTables.js"></script>
<script type="text/javascript" language="javascript" src="../../../js/Venta/funcionestb_Productos.js"></script>
<style type="text/css">
body{
font: 80%/1.45em "Lucida Grande", Verdana, Arial, Helvetica, sans-serif;
color: #333;
}
</style>
</head>
<body>
<div id="informacion" class="demo_jui">
<table cellpadding="0" cellspacing="0" border="0" class="display" id="example">
<thead>
<tr>
<th style="width:20" >ID</th>
<th >Categoria</th>
<th >Marca</th>
<th >Modelo</th>
<th >Color</th>
<th style="width:70">Talla</th>
<th >Unidad</th>
<th style="width:20">Precio</th>
<th style="width:20">Stock</th>
<th>Imagen</th>
</tr>
</thead>
<tbody>
<?php
$result=CMProducto::SPRCNSProducto(1,'');
if(count($result)>0)
{
foreach($result as $fila)
{
echo "<tr>";
echo "<td class='center'>".$fila['id_producto']."</td>";
echo "<td class='center'>".$fila['linea']."</td>";
echo "<td class='center'>".$fila['Marca']."</td>";
echo "<td class='center'>".$fila['Modelo']."</td>";
echo "<td class='center'>".$fila['Color']."</td>";
echo "<td class='center'>".$fila['Talla']."</td>";
echo "<td class='center'>".$fila['Unidad']."</td>";
echo "<td class='center'>".$fila['precio_venta']."</td>";
echo "<td class='center'>".$fila['stock']."</td>";
if($fila['ruta_imagen']=="")
{
echo "<td class='center'>Sin imagen</td>";
}
else
{
echo "<td class='foto' onClick=jQuery.fn.VistaPrevia()><img src='../../../images/zapatillas/".$fila['ruta_imagen']."' width=80 height=60 /></td>";
}
echo "</tr>";
}
}
?>
</div>
<table align="center"><tr><td>Cantidad : </td><td><input class="inp" type="text" id="cantidad"></td></tr></table>
<center><button id="addproducto" class="btn2" type="button">Agregar</button></center>
</div>
</body>
</html>
