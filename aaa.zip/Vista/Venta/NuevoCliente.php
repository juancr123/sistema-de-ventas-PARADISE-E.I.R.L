<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link href="../../../css/Venta/estilosNuevoCliente.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="../../../jQuery/validacion/css/validationEngine.jquery.css" type="text/css" />
<script type="text/javascript" src="../../../jQuery/jquery-1.7.2.js"></script>
<script type="text/javascript" src="../../../jQuery/numeric/numeric.js"></script>
<script type="text/javascript" src="../../../jQuery/validacion/js/jquery.validationEngine-es.js"></script>
<script type="text/javascript" src="../../../jQuery/validacion/js/jquery.validationEngine.js"></script>
<script type="text/javascript" src="../../../js/Venta/funcionesNuevoCliente.js"></script>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
</head>
<body>
<form id="nuevo_cliente" action="">
<table align="center">
<tr>
<td>Nombres : </td>
<td><input type="text" class="validate[required] text-input" id="nombres" data-prompt-position="bottomLeft:-20" /></td>
</tr>
<tr>
<td>Apellidos :</td>
<td><input type="text" class="validate[required] text-input" id="apellidos" data-prompt-position="bottomLeft:-20" /></td>
</tr>
<tr>
<td>Provincia :</td>
<td><select id="cmbProvincia">
<?php
	$result2=CMProvinciaDistrito::CNSProvincia();
	foreach($result2 as $fila)
	{
	if($fila['NOMBRE']=="HUAURA")
	{
	echo "<option value='".$fila['ID_PROVINCIA']."' selected='selected'>".$fila['NOMBRE']."</option>";
}
else
 {
 echo "<option value='".$fila['ID_PROVINCIA']."'>".$fila['NOMBRE']."</option>";
 }
	}
	
	?>

</select></td>
</tr>
<tr>
<td>Distrito :</td>
<td><select id="cmbDistrito" name="cmbDistrito">
<?php
$result2=CMProvinciaDistrito::CNSDistrito(187);
	foreach($result2 as $fila)
	{
	echo "<option value='".$fila['ID_DISTRITO']."' selected='selected'>".$fila['NOMBRE']."</option>";
	}
	?>
</select></td>
</tr>
<tr>
<td>Direccion :</td>
<td><input type="text" id="direccion" /></td>
</tr>
<tr>
<td>DNI :</td>
<td><input type="text" class="validate[required] text-input" id="dni" maxlength="8" data-prompt-position="bottomLeft:-20" /></td>
</tr>
<tr>
<td>RUC :</td>
<td><input type="text" id="ruc" /></td>
</tr>
<tr>
<td>Telefono :</td>
<td><input type="text" id="telefono" /></td>
</tr>
<tr>
<td>Celular :</td>
<td><input type="text" id="celular" /></td>
</tr>
<tr>
<td colspan="2" align="center"><button class="btn" type="button" id="btnGuardarCliente"><img  src="../../../images/save-icon.png" /> Guardar</button></td>
</tr>
</table>
</form>
</body>
</html>
