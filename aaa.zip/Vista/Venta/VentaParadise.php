<html>
<head>
<title>.:: VENTA-PARADISE::.</title>
<link type="text/css" rel="stylesheet" href="../../../css/Venta/demos.css" />
<link href="../../../css/Venta/estilos.css" type="text/css" rel="stylesheet"/> 
<link type="text/css" rel="stylesheet" href="../../../jQuery/dialog/themes/base/jquery.ui.all.css" />
<script type="text/javascript" language="javascript" src="../../../jQuery/jquery-1.4.4.js"></script>
<script type="text/javascript" language="javascript" src="../../../jQuery/dialog/ui/jquery-ui-1.8.7.custom.js"></script>
<script type="text/javascript" language="javascript" src="../../../js/Venta/init.js"></script>
<script type="text/javascript" language="javascript" src="../../../js/Venta/funciones.js"></script>
<link href="../../../jQuery/dataTable/css/demo_page.css" rel="stylesheet" type="text/css" />
<link href="../../../jQuery/dataTable/css/demo_table_jui.css" rel="stylesheet" type="text/css"  /> 
<link href="../../../css/Venta/estilosInputs.css" rel="stylesheet" type="text/css"/> 
<script type="text/javascript" language="javascript" src="../../../jQuery/dataTable/js/jquery.dataTables.js"></script>
<link href="../../../jQuery/alerts/css/jquery.alerts.css" rel="stylesheet" type="text/css" media="screen" />
<script src="../../../jQuery/alerts/js/jquery.alerts.js" type="text/javascript"></script>
<script type="text/javascript">
  $(document).ready(function()
    {
  $("#fVentab").datepicker({
	 dateFormat: 'yy-mm-dd'
	}
	);
	
  $("#fEntregab").datepicker({
	 dateFormat: 'yy-mm-dd'
	}
	);
	});
</script>
</head>
<body onLoad="LoadVentaParadise()">
<?php
session_start();
?>
<div id='datos' align='center'>
<table align='center'>
<tr>
<td>N&#186; BOLETA : </td><td><input type='text' id='numboleta' class="inp" size='24'><input type='hidden' id='id_personal' value="<?php echo $_SESSION["id_personal"]; ?>"</td>
</tr>
</table>
<table>
<tr>
<td>N&#186; Cliente :</td><td><input type='text' id='idb' class="inp"  readonly="true"/></td><td>RUC :</td><td><input class="inp" type='text' readonly="true" id='rucb' size='26' /></td><td><input type='button' id='nuevo' value='NUEVO' class="btn2"/></td>
</tr>
<tr>
<td>Nombres :</td><td colspan='3'><input type='text' readonly="true" id='nombresb' class="inp" size='60'/></td><td><input type='button' id='buscar' value='BUSCAR' class="btn2"></td>
</tr>
<tr>
<td>Direccion :</td><td colspan='3'><input type='text' readonly="true" id='direccionb' class="inp" size='60'/></td>
</tr>
<tr>
<td>DNI: </td><td><input type='text' id='dnib' readonly="true" class="inp"/></td><td>Telefono : </td><td>
<input type='text' readonly="true" id='telefonob' class="inp" size='26'></td>
</tr>
<tr>
<td>Fecha Pedido :</td><td><input type='text' id='fVentab' class="inp" readonly="true"/></td><td colspan='2'>Fecha Entrega : <input type='text' class="inp" id='fEntregab' readonly="true" size='21'/></td>
</tr>
</table>
</div>
<div id='AddDel'>
<table align="right">
<tr>
<td>
<button id="botonagregar" style="width:65;height:65;" disabled="disabled"><img src="../../../images/Add-icon.png" width="20" height="20"></button>
</td>
</tr>
<tr>
<td>
<button id="botoneliminar" style="width:65;height:65;" disabled="disabled"><img src="../../../images/Delete-icon (1).png" width="20" height="20"></button>
</td>
</tr>
</table>
</div>
<div id='detalle'>
<div class='demo_jui'>
 <table cellpadding='0' cellspacing='0' border='0' class='display' id='scrollTable1'>
      <thead>
      	<tr><th>ID</th><th width="70%">Descripcion</th><th>P.Unitario</th><th>Cantidad</th>
<th>Costo</th></tr>
      </thead>
	  <tbody>
	  </tbody>
</table>
</div>
</div>
<div id='descuentos'>
<table align='right'>
<tr>
<td>SUBTOTAL :</td><td>S/.<input type='text' class="inp" id='subtotal' disabled='disabled' /></td>
</tr>
<tr>
<td>IGV :</td><td>S/.<input type='text' class="inp" id='igv' disabled='disabled' /></td>
</tr>
<tr>
<td>TOTAL :</td><td>S/.<input type='text' class="inp" id='total' disabled='disabled' /></td>
</tr>
</table>
</div>
<div id='botones'>
<table align='center'>
<tr>
<td><input type='button' id='nuevoyguardar' value='NUEVO' class="btn" onClick='MandarRegistroBoleta()'></td>
</tr>
</table>
</div>
<div id='resultado' align='center'>
<?php
if(isset($_REQUEST['resultado'])) 
{
echo $_REQUEST['resultado'];
}
?>
</div>
</body>
</html>