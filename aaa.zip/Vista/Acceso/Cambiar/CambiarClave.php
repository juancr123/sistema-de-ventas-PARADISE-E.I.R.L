<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<link href="../../../css/Acceso/estilos.css" type="text/css" rel="stylesheet" />
</head>
<body>
<div id="datos">
<form action="p_cambiarclave.php" method="post">
<table align="center">
<tr>
<td>Clave antigua : </td>
<td><input type="password" name="clave_antigua" class="inp" /></td>
</tr>
<tr>
<td>Clave Nueva : </td>
<td><input type="password" name="clave_nueva" class="inp"  /></td>
</tr>
<tr>
<td>Repita Clave Nueva : </td>
<td><input type="password" name="clave_nueva2" class="inp"  /></td>
</tr>
<tr>
<td colspan="2" align="center"><br>
<button type="button" id="btnEnviar" class="btn"><img src="../../../images/actualizar.png" width="20" height="20" />  Cambiar</button>
</td>
</tr>
</table>
</form>
</div>
<!--<div id="resultado">
<?php 
/*if(isset($_REQUEST['resultado'])) 
{
echo $_REQUEST['resultado'];
}*/
?>
</div>-->
</body>
</html>
