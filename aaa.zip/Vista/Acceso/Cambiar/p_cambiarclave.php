<?php
require '../../../Modelo/Mantenimiento/Personal/CMPersonal.php';
session_start();
$clave_nueva=$_POST["clave_nueva"];
$result=CMPersonal::ABMPersonal
(2,$_SESSION["id_personal"],"","",1,"","M","sd",232,$clave_nueva,23,2);
if($result)
{
$_SESSION["clave"]=$clave_nueva;
header("Location: CambiarClave.php?resultado=Operacion Exitosa");
}
else
{
header("Location: CambiarClave.php?resultado=Operacion Fallida");
}
?>
